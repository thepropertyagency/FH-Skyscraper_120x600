(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:



(lib.IMG01jpgcopy = function() {
	this.initialize(img.IMG01jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG02jpgcopy = function() {
	this.initialize(img.IMG02jpgcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,556);


(lib.IMG03 = function() {
	this.initialize(img.IMG03);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,480,300);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Tween8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG03();
	this.instance.parent = this;
	this.instance.setTransform(-179,-111.85,0.7458,0.7458);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-179,-111.8,358,223.7);


(lib.Tween6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG02jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.IMG01jpgcopy();
	this.instance.parent = this;
	this.instance.setTransform(-250,-278);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-250,-278,500,556);


(lib.Symbol15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#2E2E2E").beginStroke().moveTo(12.6,40.5).lineTo(12.6,30.2).lineTo(14,30.2).lineTo(14,39.2).lineTo(18.2,39.2).lineTo(18.2,40.5).closePath().moveTo(2.4,40.5).lineTo(2.4,30.2).lineTo(3.8,30.2).lineTo(3.8,39.2).lineTo(8,39.2).lineTo(8,40.5).closePath().moveTo(-4.7,40.5).lineTo(-4.7,30.2).lineTo(-3.3,30.2).lineTo(-3.3,40.5).closePath().moveTo(-11.8,40.5).lineTo(-11.8,36.1).lineTo(-16.8,36.1).lineTo(-16.8,40.5).lineTo(-18.2,40.5).lineTo(-18.2,30.2).lineTo(-16.8,30.2).lineTo(-16.8,34.8).lineTo(-11.8,34.8).lineTo(-11.8,30.2).lineTo(-10.4,30.2).lineTo(-10.4,40.5).closePath().moveTo(-17.7,22.9).curveTo(-19.2,21.4,-19.2,19.2).curveTo(-19.2,17,-17.7,15.4).curveTo(-16.2,13.9,-14,13.9).curveTo(-12,13.9,-10.5,15.3).lineTo(-11.5,16.2).curveTo(-12.6,15.2,-14,15.2).curveTo(-15.6,15.2,-16.7,16.4).curveTo(-17.8,17.6,-17.8,19.2).curveTo(-17.8,20.9,-16.7,22).curveTo(-15.6,23.2,-14,23.2).curveTo(-12.6,23.2,-11.7,22.4).curveTo(-10.8,21.6,-10.7,20.4).lineTo(-13.6,20.4).lineTo(-13.6,19.2).lineTo(-9.1,19.2).curveTo(-9.1,21.8,-10.5,23.2).curveTo(-11.7,24.5,-14,24.5).curveTo(-16.2,24.5,-17.7,22.9).closePath().moveTo(30,24.3).lineTo(30,14).lineTo(36.2,14).lineTo(36.2,15.3).lineTo(31.4,15.3).lineTo(31.4,18.6).lineTo(35.6,18.6).lineTo(35.6,19.9).lineTo(31.4,19.9).lineTo(31.4,23).lineTo(36.3,23).lineTo(36.3,24.3).closePath().moveTo(18.8,24.3).lineTo(18.8,14).lineTo(24.9,14).lineTo(24.9,15.3).lineTo(20.2,15.3).lineTo(20.2,18.6).lineTo(24.3,18.6).lineTo(24.3,19.9).lineTo(20.2,19.9).lineTo(20.2,23).lineTo(25,23).lineTo(25,24.3).closePath().moveTo(11.9,24.3).lineTo(9.3,20.5).lineTo(8,20.5).lineTo(8,24.3).lineTo(6.5,24.3).lineTo(6.5,14).lineTo(10.5,14).curveTo(12,14,12.9,15).curveTo(13.6,15.9,13.6,17.3).curveTo(13.6,18.5,13,19.4).curveTo(12.2,20.3,10.9,20.4).lineTo(13.6,24.3).closePath().moveTo(8,19.2).lineTo(10.4,19.2).curveTo(12.1,19.2,12.1,17.3).curveTo(12.1,15.3,10.5,15.3).lineTo(8,15.3).closePath().moveTo(-2.6,24.3).lineTo(-2.6,15.3).lineTo(-5.7,15.3).lineTo(-5.7,14).lineTo(2,14).lineTo(2,15.3).lineTo(-1.2,15.3).lineTo(-1.2,24.3).closePath().moveTo(-25.7,24.3).lineTo(-25.7,14).lineTo(-24.3,14).lineTo(-24.3,24.3).closePath().moveTo(-36.3,24.3).lineTo(-36.3,14).lineTo(-30.3,14).lineTo(-30.3,15.3).lineTo(-34.9,15.3).lineTo(-34.9,18.6).lineTo(-31.2,18.6).lineTo(-31.2,19.9).lineTo(-34.9,19.9).lineTo(-34.9,24.3).closePath().moveTo(41.4,6.9).curveTo(33.7,3.6,18.5,1.4).lineTo(13.1,1.1).curveTo(-0.7,1.1,-15.3,2.4).curveTo(-31.9,3.8,-41.7,6.3).curveTo(-42.3,6.5,-42.5,5.8).lineTo(-42.5,5.4).curveTo(-42.3,5,-42,5).curveTo(-33.3,1.9,-24.4,0.2).curveTo(-14.3,-1.8,-4.1,-1.8).lineTo(-3.7,-2.6).curveTo(-3,-4.1,-2.9,-4.6).curveTo(-2.6,-6.3,-3,-7.9).curveTo(-3.4,-9.6,-4.5,-10.7).curveTo(-5.6,-11.8,-7.2,-12).curveTo(-8.9,-12.2,-12.3,-11.1).curveTo(-13.9,-10.5,-15,-10.3).curveTo(-17.3,-9.8,-19.2,-10.3).curveTo(-21.4,-10.9,-22.2,-12.8).lineTo(-22.3,-12.9).lineTo(-22.9,-12.9).curveTo(-25.6,-13,-26.3,-15).curveTo(-26.8,-16.3,-25.9,-17.4).curveTo(-25.5,-17.9,-24.4,-18.5).curveTo(-22.9,-19.4,-23.2,-20.8).lineTo(-23.6,-21.6).curveTo(-24.9,-23.9,-23.7,-24.8).curveTo(-22.9,-25.3,-21.7,-25.4).curveTo(-20.8,-25.5,-20.5,-25.7).curveTo(-19.7,-26.1,-19.3,-28.2).lineTo(-19.1,-28.9).curveTo(-18.7,-31.3,-17.5,-32.1).curveTo(-16.2,-32.9,-14,-31.9).lineTo(-13.3,-31.5).curveTo(-11.7,-31,-8.7,-31.6).curveTo(-8.8,-32.3,-8.7,-33).curveTo(-8.4,-34.3,-6.4,-36).lineTo(-5.5,-36.8).lineTo(-5.8,-37.3).lineTo(-6,-38.1).curveTo(-6.3,-39.2,-5.9,-39.9).curveTo(-5.5,-40.6,-4.6,-40.5).curveTo(-3.8,-40.4,-3.5,-39.8).curveTo(-2.8,-38.6,-3.5,-37.2).lineTo(-3.6,-36.9).curveTo(-2.2,-36.1,-0.5,-36.3).curveTo(0.6,-36.3,2.6,-37.2).lineTo(4.6,-38).curveTo(6.3,-38.6,7.3,-37.7).curveTo(8.4,-36.9,8.4,-34.1).lineTo(8.4,-33.4).curveTo(8.4,-31.4,8.6,-30.5).curveTo(8.9,-29,10.1,-28.4).curveTo(11.1,-27.8,12,-28.6).lineTo(12.6,-29.3).curveTo(13.6,-30.5,14.7,-30.8).curveTo(15.7,-31,16.3,-30.4).curveTo(17,-29.8,17,-28.6).curveTo(16.9,-26.4,17.6,-25.5).lineTo(18.2,-24.7).lineTo(18.4,-24.9).curveTo(19.6,-26,20.9,-25.6).curveTo(21.7,-25.5,21.9,-24.7).curveTo(22.2,-24,21.7,-23.3).curveTo(21.3,-22.9,20.6,-22.7).curveTo(19.9,-22.5,19.4,-22.6).lineTo(18.8,-22.7).curveTo(18.6,-22.1,19,-21.5).curveTo(19.8,-20.6,21.5,-20.5).curveTo(24.1,-20.4,25.3,-18.8).curveTo(26.4,-17.3,26.5,-15.2).curveTo(26.5,-13.9,26,-12.6).curveTo(25.4,-11.2,24.4,-10.5).curveTo(23.1,-9.7,21.6,-10.5).curveTo(20.8,-10.9,20.2,-11.5).curveTo(19.4,-12.2,19,-12.4).curveTo(18.6,-12.6,18.2,-12.5).curveTo(17.8,-12.3,17.3,-11.5).curveTo(15.1,-8.6,11.1,-9.1).curveTo(10.1,-9.2,7.8,-10.4).lineTo(7.4,-10.6).curveTo(5.8,-11.4,4.7,-11.7).curveTo(3.7,-11.8,3.1,-11.6).curveTo(2.3,-11.3,2,-10.5).curveTo(1.7,-9.8,1.9,-9).curveTo(2.6,-7.1,3,-6.8).curveTo(3.5,-6.4,3.2,-5.9).curveTo(3,-5.4,2.4,-5.6).lineTo(2.4,-5.6).curveTo(1.2,-6.1,0.7,-8).curveTo(0.2,-9.6,0.5,-10.7).curveTo(0.8,-12.1,1.9,-12.7).curveTo(3.1,-13.5,4.8,-13).lineTo(5,-12.9).curveTo(5.9,-12.8,8.3,-11.6).lineTo(8.4,-11.5).curveTo(10.2,-10.7,11.3,-10.5).curveTo(12.8,-10.2,14.2,-10.8).curveTo(14.8,-11,15.7,-12.1).lineTo(16.6,-13).curveTo(17.1,-13.6,17.9,-13.7).curveTo(18.5,-14,19.3,-13.7).lineTo(19.5,-13.6).curveTo(20.3,-13.3,20.8,-12.8).lineTo(21,-12.6).lineTo(22.3,-11.7).curveTo(22.8,-11.4,23.3,-11.6).curveTo(24.5,-12,24.9,-13.6).curveTo(25.3,-15,24.9,-16.6).curveTo(24.4,-18.3,23.1,-18.9).curveTo(22.7,-19.1,21.5,-19.1).curveTo(20.2,-19.1,19.4,-19.5).curveTo(17.7,-20.2,17.4,-21.9).curveTo(17.3,-22.7,17.5,-23.5).curveTo(17.1,-23.8,16.6,-24.4).curveTo(15.5,-25.9,15.5,-27.5).lineTo(15.6,-28.3).curveTo(15.7,-29.2,15.5,-29.4).lineTo(15.3,-29.5).curveTo(14.7,-29.5,14,-28.8).lineTo(13.7,-28.4).curveTo(12.4,-26.9,11.2,-26.8).curveTo(9.8,-26.6,8.8,-27.5).curveTo(7.1,-29,7,-32.1).lineTo(7,-32.9).curveTo(7,-36.2,6.3,-36.7).curveTo(5.9,-36.9,5.3,-36.7).lineTo(3.3,-36).curveTo(1.6,-35.3,0.7,-35).curveTo(-0.8,-34.7,-2.1,-34.9).curveTo(-3.4,-35.1,-4.5,-35.8).lineTo(-5.5,-34.9).curveTo(-7.5,-33.3,-7.3,-32).curveTo(-4.5,-32.6,-2.6,-32).curveTo(-0.7,-31.5,-0.1,-29.9).curveTo(0.5,-28.2,-0.7,-27.4).curveTo(-1.4,-26.8,-2.6,-27.1).curveTo(-3.1,-27.1,-4,-27.3).curveTo(-5.1,-27.6,-6.3,-28.5).curveTo(-7.6,-29.3,-8.2,-30.4).curveTo(-11.3,-29.6,-13.1,-30).lineTo(-14.5,-30.6).curveTo(-15.5,-31,-15.9,-31.1).curveTo(-16.5,-31.2,-16.9,-30.9).curveTo(-17.5,-30.3,-17.9,-28.2).lineTo(-18.2,-26.7).curveTo(-18.8,-25.1,-19.6,-24.5).curveTo(-20.2,-24.1,-21.5,-24).lineTo(-22.2,-23.9).curveTo(-22.8,-23.8,-22.8,-23.7).curveTo(-22.8,-23.6,-22.4,-22.5).lineTo(-21.9,-21.5).curveTo(-21.1,-18.8,-23.9,-17.2).curveTo(-24.9,-16.6,-25,-15.8).curveTo(-25.1,-15.3,-24.5,-14.8).curveTo(-23.9,-14.3,-22.5,-14.2).curveTo(-22.5,-14.6,-22.2,-15).curveTo(-21.9,-15.6,-21.1,-15.8).curveTo(-20.5,-15.9,-20,-15.4).curveTo(-19.3,-14.8,-19.5,-14.1).curveTo(-19.7,-13.5,-20.7,-13.2).lineTo(-20.9,-13.1).curveTo(-20.5,-12.3,-19.8,-12).curveTo(-18.7,-11.4,-16.8,-11.5).curveTo(-15.1,-11.6,-13.5,-12.2).lineTo(-13.2,-12.3).curveTo(-10,-13.3,-8.3,-13.4).curveTo(-5.4,-13.6,-3.5,-11.7).curveTo(-1.8,-10.1,-1.5,-7.6).curveTo(-1.2,-5.3,-1.9,-3.1).lineTo(-1.9,-3).lineTo(-2.4,-1.8).lineTo(0.6,-1.8).curveTo(9.3,-1.2,18.6,0.1).lineTo(29.9,0.5).lineTo(41.9,1).curveTo(42.5,1.1,42.5,1.7).curveTo(42.4,2.4,41.8,2.3).lineTo(29.8,1.8).lineTo(28.2,1.8).curveTo(37.1,3.6,41.9,5.7).curveTo(42.5,6,42.2,6.6).curveTo(42.1,7,41.6,7).closePath().moveTo(-24.2,1.5).lineTo(-29.4,2.6).curveTo(-13.9,0.4,5.1,-0.1).lineTo(-3.7,-0.5).curveTo(-14.3,-0.5,-24.2,1.5).closePath().moveTo(20,-24.2).lineTo(19.6,-24).curveTo(20.4,-23.9,20.6,-24.1).lineTo(20.6,-24.2).lineTo(20.4,-24.3).lineTo(20,-24.2).closePath().moveTo(-6.7,-30.7).curveTo(-6.4,-30.2,-5.6,-29.6).curveTo(-5,-29.2,-4.5,-29).lineTo(-4.4,-29).curveTo(-3.2,-28.5,-2.5,-28.3).lineTo(-1.6,-28.4).lineTo(-1.4,-28.8).curveTo(-1.2,-29.3,-1.6,-29.8).curveTo(-2.4,-30.9,-4.5,-30.9).curveTo(-5.5,-30.9,-6.7,-30.7).closePath().moveTo(-4.8,-38.6).lineTo(-4.7,-38).curveTo(-4.5,-38.5,-4.7,-38.9).lineTo(-4.7,-39).closePath();
	this.shape.setTransform(0.025,0.0375);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol15, new cjs.Rectangle(-42.5,-40.5,85.1,81.1), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,8).lineTo(-1.7,-8).lineTo(1.7,-8).lineTo(1.7,8).closePath();
	this.shape.setTransform(54.075,16.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,8).lineTo(-1.7,-8).lineTo(1.7,-8).lineTo(1.7,8).closePath();
	this.shape_1.setTransform(47.825,16.025);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,8.1).lineTo(-1.7,-2.8).lineTo(1.7,-2.8).lineTo(1.7,8.1).closePath().moveTo(-1.4,-4.8).curveTo(-2,-5.3,-1.9,-6.2).curveTo(-2,-7,-1.4,-7.5).curveTo(-0.8,-8.1,-0,-8.1).curveTo(0.8,-8.1,1.3,-7.5).curveTo(2,-7,2,-6.2).curveTo(2,-5.3,1.3,-4.8).curveTo(0.8,-4.2,-0,-4.2).curveTo(-0.8,-4.2,-1.4,-4.8).closePath();
	this.shape_2.setTransform(41.6,15.875);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#2E2E2E").beginStroke().moveTo(3.1,7.8).lineTo(3.1,1.6).lineTo(-3.1,1.6).lineTo(-3.1,7.8).lineTo(-6.6,7.8).lineTo(-6.6,-7.8).lineTo(-3.1,-7.8).lineTo(-3.1,-1.7).lineTo(3.1,-1.7).lineTo(3.1,-7.8).lineTo(6.6,-7.8).lineTo(6.6,7.8).closePath();
	this.shape_3.setTransform(30.2,16.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.7,4.2).curveTo(-5.4,2.6,-5.5,-0).curveTo(-5.5,-2.6,-3.8,-4.2).curveTo(-2.3,-5.8,0,-5.8).curveTo(2.5,-5.8,4,-4.3).curveTo(5.4,-2.8,5.4,-0.2).lineTo(5.4,0.9).lineTo(-2.2,0.9).curveTo(-2.1,1.7,-1.5,2.3).curveTo(-0.7,3,0.2,3).curveTo(2,3,2.5,1.5).lineTo(5.3,2.3).curveTo(4.8,3.8,3.6,4.8).curveTo(2.2,5.8,0.2,5.8).curveTo(-2.1,5.8,-3.7,4.2).closePath().moveTo(2.3,-1.4).curveTo(2.2,-2,1.7,-2.5).curveTo(1.1,-3.2,0,-3.2).curveTo(-1,-3.2,-1.6,-2.5).curveTo(-2.1,-2,-2.1,-1.4).lineTo(2.3,-1.4).lineTo(2.3,-1.4).closePath();
	this.shape_4.setTransform(10.4,18.55);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.7,4.2).curveTo(-5.4,2.6,-5.4,-0).curveTo(-5.4,-2.6,-3.8,-4.2).curveTo(-2.2,-5.8,-0,-5.8).curveTo(2.5,-5.8,4,-4.3).curveTo(5.4,-2.8,5.4,-0.2).lineTo(5.4,0.9).lineTo(-2.2,0.9).curveTo(-2.1,1.7,-1.5,2.3).curveTo(-0.7,3,0.2,3).curveTo(1.9,3,2.5,1.5).lineTo(5.3,2.3).curveTo(4.8,3.8,3.6,4.8).curveTo(2.2,5.8,0.2,5.8).curveTo(-2.2,5.8,-3.7,4.2).closePath().moveTo(2.2,-1.4).curveTo(2.2,-2,1.7,-2.5).curveTo(1.1,-3.2,0,-3.2).curveTo(-0.9,-3.2,-1.6,-2.5).curveTo(-2.1,-2,-2.1,-1.4).lineTo(2.2,-1.4).lineTo(2.2,-1.4).closePath();
	this.shape_5.setTransform(-1.85,18.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-3.5,5.5).lineTo(-3.5,-5.4).lineTo(-0.2,-5.4).lineTo(-0.2,-3.9).curveTo(0.5,-5.5,2.6,-5.5).lineTo(3.5,-5.4).lineTo(3.5,-2.1).lineTo(2.4,-2.2).curveTo(1.3,-2.2,0.7,-1.6).curveTo(-0.1,-0.8,-0.1,0.8).lineTo(-0.1,5.5).closePath();
	this.shape_6.setTransform(-11.925,18.475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-0.8,6.2).curveTo(-1.7,5.3,-1.7,3.7).lineTo(-1.7,-1).lineTo(-3.7,-1).lineTo(-3.7,-4).lineTo(-3.1,-4).curveTo(-1.4,-4,-1.4,-5.7).lineTo(-1.4,-7.2).lineTo(1.6,-7.2).lineTo(1.6,-4).lineTo(3.7,-4).lineTo(3.7,-1).lineTo(1.6,-1).lineTo(1.6,3.1).curveTo(1.6,4.2,2.8,4.2).lineTo(3.6,4.1).lineTo(3.6,6.9).curveTo(3,7.2,1.9,7.2).curveTo(0.2,7.2,-0.8,6.2).closePath();
	this.shape_7.setTransform(-21.325,17.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-4,6.6).curveTo(-5.4,5.5,-5.6,3.9).lineTo(-2.7,3.1).curveTo(-2.6,3.9,-1.9,4.4).curveTo(-1.3,4.9,-0.3,4.9).curveTo(2.4,4.9,2.4,2.1).lineTo(2.4,1.6).curveTo(1.5,2.9,-0.5,2.9).curveTo(-2.8,2.9,-4.2,1.3).curveTo(-5.6,-0.2,-5.6,-2.5).curveTo(-5.6,-4.7,-4.2,-6.2).curveTo(-2.8,-7.8,-0.5,-7.8).curveTo(1.7,-7.8,2.5,-6.4).lineTo(2.5,-7.6).lineTo(5.6,-7.6).lineTo(5.6,2).curveTo(5.6,4.5,4.3,6.1).curveTo(2.7,7.8,-0.2,7.8).curveTo(-2.4,7.8,-4,6.6).closePath().moveTo(-1.6,-4.2).curveTo(-2.3,-3.5,-2.3,-2.5).curveTo(-2.3,-1.4,-1.6,-0.7).curveTo(-1,-0,0,-0).curveTo(1.1,-0,1.7,-0.7).curveTo(2.4,-1.3,2.4,-2.5).curveTo(2.4,-3.5,1.7,-4.2).curveTo(1,-4.9,0,-4.9).curveTo(-1,-4.9,-1.6,-4.2).closePath();
	this.shape_8.setTransform(-32.25,20.675);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-1.7,8.1).lineTo(-1.7,-2.8).lineTo(1.6,-2.8).lineTo(1.6,8.1).closePath().moveTo(-1.4,-4.8).curveTo(-1.9,-5.3,-2,-6.2).curveTo(-1.9,-7,-1.4,-7.5).curveTo(-0.8,-8.1,0,-8.1).curveTo(0.8,-8.1,1.4,-7.5).curveTo(1.9,-7,1.9,-6.2).curveTo(1.9,-5.3,1.4,-4.8).curveTo(0.8,-4.2,0,-4.2).curveTo(-0.8,-4.2,-1.4,-4.8).closePath();
	this.shape_9.setTransform(-41.7,15.875);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#2E2E2E").beginStroke().moveTo(-5,7.8).lineTo(-5,-7.8).lineTo(5,-7.8).lineTo(5,-4.5).lineTo(-1.6,-4.5).lineTo(-1.6,-1.2).lineTo(4.2,-1.2).lineTo(4.2,2).lineTo(-1.5,2).lineTo(-1.5,7.8).closePath();
	this.shape_10.setTransform(-50.575,16.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.8,6.2).curveTo(-1.7,5.3,-1.7,3.7).lineTo(-1.7,-1).lineTo(-3.7,-1).lineTo(-3.7,-4).lineTo(-3.1,-4).curveTo(-1.4,-4,-1.4,-5.7).lineTo(-1.4,-7.2).lineTo(1.6,-7.2).lineTo(1.6,-4).lineTo(3.7,-4).lineTo(3.7,-1).lineTo(1.6,-1).lineTo(1.6,3.1).curveTo(1.6,4.2,2.8,4.2).lineTo(3.6,4.1).lineTo(3.6,6.9).curveTo(3,7.2,1.9,7.2).curveTo(0.2,7.2,-0.8,6.2).closePath();
	this.shape_11.setTransform(40.375,-8.825);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4,4.8).curveTo(-5,3.8,-5,2.5).curveTo(-5,1.1,-4.1,0.2).curveTo(-3.2,-0.6,-1.7,-0.8).lineTo(0.8,-1.2).curveTo(1.6,-1.4,1.6,-2).curveTo(1.6,-2.5,1.2,-2.8).curveTo(0.8,-3.2,-0,-3.2).curveTo(-0.8,-3.2,-1.4,-2.7).curveTo(-1.8,-2.2,-1.8,-1.6).lineTo(-4.8,-2.2).curveTo(-4.7,-3.5,-3.5,-4.6).curveTo(-2.2,-5.8,0.1,-5.8).curveTo(2.6,-5.8,3.8,-4.5).curveTo(4.9,-3.4,4.8,-1.6).lineTo(4.8,3.8).curveTo(4.9,4.8,5,5.5).lineTo(2,5.5).lineTo(1.9,4.2).curveTo(0.9,5.8,-1.2,5.8).curveTo(-3,5.8,-4,4.8).closePath().moveTo(-0.5,1).curveTo(-1.7,1.2,-1.7,2.2).curveTo(-1.7,3.4,-0.4,3.4).curveTo(1.6,3.4,1.6,1.2).lineTo(1.6,0.7).closePath();
	this.shape_12.setTransform(30.25,-7.325);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.8,4.2).curveTo(-5.5,2.6,-5.5,-0.1).curveTo(-5.5,-2.6,-3.8,-4.2).curveTo(-2.3,-5.8,0,-5.8).curveTo(2.6,-5.8,4,-4.3).curveTo(5.4,-2.8,5.4,-0.2).lineTo(5.4,0.8).lineTo(-2.2,0.8).curveTo(-2.2,1.8,-1.4,2.3).curveTo(-0.7,2.9,0.3,3).curveTo(1.9,3,2.5,1.5).lineTo(5.2,2.3).curveTo(4.9,3.8,3.6,4.8).curveTo(2.2,5.8,0.3,5.8).curveTo(-2.2,5.8,-3.8,4.2).closePath().moveTo(2.3,-1.3).curveTo(2.2,-2.1,1.7,-2.5).curveTo(1.1,-3.2,0,-3.2).curveTo(-0.9,-3.2,-1.5,-2.5).curveTo(-2.1,-2.1,-2.1,-1.3).lineTo(2.3,-1.3).lineTo(2.3,-1.3).closePath();
	this.shape_13.setTransform(12.95,-7.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,5.5).lineTo(-6,-5.5).lineTo(-2.4,-5.5).lineTo(0.2,1.3).lineTo(2.5,-5.5).lineTo(6,-5.5).lineTo(1.9,5.5).closePath();
	this.shape_14.setTransform(0.575,-7.325);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.7,8.1).lineTo(-1.7,-2.8).lineTo(1.6,-2.8).lineTo(1.6,8.1).closePath().moveTo(-1.4,-4.8).curveTo(-1.9,-5.3,-2,-6.2).curveTo(-1.9,-7,-1.4,-7.5).curveTo(-0.8,-8.1,0,-8.1).curveTo(0.8,-8.1,1.4,-7.5).curveTo(1.9,-7,1.9,-6.2).curveTo(1.9,-5.3,1.4,-4.8).curveTo(0.8,-4.2,0,-4.2).curveTo(-0.8,-4.2,-1.4,-4.8).closePath();
	this.shape_15.setTransform(-8.75,-9.975);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.7,8).lineTo(-1.7,-8).lineTo(1.7,-8).lineTo(1.7,8).closePath();
	this.shape_16.setTransform(-15.025,-9.825);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4.1,4.1).curveTo(-5.8,2.5,-5.8,-0.1).curveTo(-5.8,-2.6,-4.1,-4.2).curveTo(-2.5,-5.8,0,-5.8).curveTo(2.4,-5.8,4.1,-4.2).curveTo(5.8,-2.6,5.8,-0.1).curveTo(5.8,2.5,4.1,4.1).curveTo(2.4,5.8,0,5.8).curveTo(-2.4,5.8,-4.1,4.1).closePath().moveTo(-1.7,-2.1).curveTo(-2.5,-1.3,-2.5,-0.1).curveTo(-2.5,1.3,-1.7,2).curveTo(-1,2.7,0,2.7).curveTo(1,2.7,1.7,2.1).curveTo(2.4,1.3,2.5,-0.1).curveTo(2.4,-1.3,1.7,-2.1).curveTo(1,-2.7,0,-2.8).curveTo(-1.1,-2.7,-1.7,-2.1).closePath();
	this.shape_17.setTransform(-30,-7.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.8,6.2).curveTo(-1.7,5.3,-1.7,3.7).lineTo(-1.7,-1).lineTo(-3.7,-1).lineTo(-3.7,-4).lineTo(-3.1,-4).curveTo(-1.4,-4,-1.4,-5.7).lineTo(-1.4,-7.2).lineTo(1.6,-7.2).lineTo(1.6,-4).lineTo(3.7,-4).lineTo(3.7,-1).lineTo(1.6,-1).lineTo(1.6,3.1).curveTo(1.6,4.2,2.8,4.2).lineTo(3.6,4.1).lineTo(3.6,6.9).curveTo(3,7.2,1.9,7.2).curveTo(0.2,7.2,-0.8,6.2).closePath();
	this.shape_18.setTransform(-40.975,-8.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.8,6.2).curveTo(-1.7,5.3,-1.7,3.7).lineTo(-1.7,-1).lineTo(-3.7,-1).lineTo(-3.7,-4).lineTo(-3.1,-4).curveTo(-1.4,-4,-1.4,-5.7).lineTo(-1.4,-7.2).lineTo(1.6,-7.2).lineTo(1.6,-4).lineTo(3.7,-4).lineTo(3.7,-1).lineTo(1.6,-1).lineTo(1.6,3.1).curveTo(1.6,4.2,2.8,4.2).lineTo(3.6,4.1).lineTo(3.6,6.9).curveTo(3,7.2,1.9,7.2).curveTo(0.2,7.2,-0.8,6.2).closePath();
	this.shape_19.setTransform(51.475,-34.675);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.4,4.5).curveTo(-4.4,3.6,-4.5,2.4).lineTo(-1.7,1.8).curveTo(-1.6,2.5,-1.2,2.8).curveTo(-0.7,3.3,0,3.3).curveTo(1.4,3.3,1.4,2.4).curveTo(1.4,1.7,0.3,1.5).lineTo(-1,1.2).curveTo(-4.3,0.5,-4.3,-2.2).curveTo(-4.3,-3.7,-3,-4.7).curveTo(-1.8,-5.8,-0.1,-5.8).curveTo(2.1,-5.8,3.3,-4.7).curveTo(4.3,-3.8,4.4,-2.6).lineTo(1.6,-2).curveTo(1.4,-3.4,0,-3.4).curveTo(-0.5,-3.4,-0.9,-3.1).curveTo(-1.2,-2.9,-1.2,-2.5).curveTo(-1.2,-1.8,-0.3,-1.7).lineTo(1.1,-1.3).curveTo(2.8,-1,3.6,-0.1).curveTo(4.5,0.9,4.5,2.1).curveTo(4.5,3.6,3.4,4.6).curveTo(2.2,5.8,0.1,5.8).curveTo(-2.1,5.8,-3.4,4.5).closePath();
	this.shape_20.setTransform(42.35,-33.15);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,5.5).lineTo(-3.5,-5.4).lineTo(-0.2,-5.4).lineTo(-0.2,-3.9).curveTo(0.5,-5.5,2.6,-5.5).lineTo(3.5,-5.4).lineTo(3.5,-2.1).lineTo(2.4,-2.2).curveTo(1.3,-2.2,0.7,-1.6).curveTo(-0.1,-0.8,-0.1,0.8).lineTo(-0.1,5.5).closePath();
	this.shape_21.setTransform(33.375,-33.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.7,8.1).lineTo(-1.7,-2.8).lineTo(1.6,-2.8).lineTo(1.6,8.1).closePath().moveTo(-1.4,-4.8).curveTo(-1.9,-5.3,-2,-6.2).curveTo(-1.9,-7,-1.4,-7.5).curveTo(-0.8,-8.1,0,-8.1).curveTo(0.8,-8.1,1.4,-7.5).curveTo(1.9,-7,1.9,-6.2).curveTo(1.9,-5.3,1.4,-4.8).curveTo(0.8,-4.2,0,-4.2).curveTo(-0.8,-4.2,-1.4,-4.8).closePath();
	this.shape_22.setTransform(25.35,-35.825);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-2,8).lineTo(-2,-0.1).lineTo(-3.8,-0.1).lineTo(-3.8,-2.9).lineTo(-2,-2.9).lineTo(-2,-3.9).curveTo(-2,-5.7,-1,-6.9).curveTo(0.2,-8.1,2.2,-8.1).curveTo(3.2,-8.1,3.7,-7.8).lineTo(3.7,-5.1).lineTo(2.7,-5.2).curveTo(1.3,-5.2,1.4,-3.7).lineTo(1.4,-2.9).lineTo(3.7,-2.9).lineTo(3.7,-0.1).lineTo(1.4,-0.1).lineTo(1.4,8).closePath();
	this.shape_23.setTransform(18.25,-35.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,4.3).curveTo(-5.4,2.6,-5.5,-0.1).curveTo(-5.5,-2.6,-3.8,-4.3).curveTo(-2.3,-5.8,0,-5.8).curveTo(2.5,-5.8,4,-4.4).curveTo(5.4,-2.9,5.4,-0.2).lineTo(5.4,0.8).lineTo(-2.2,0.8).curveTo(-2.1,1.7,-1.5,2.4).curveTo(-0.7,2.9,0.2,2.9).curveTo(2,2.9,2.5,1.5).lineTo(5.3,2.3).curveTo(4.8,3.8,3.6,4.7).curveTo(2.2,5.8,0.2,5.8).curveTo(-2.1,5.8,-3.7,4.3).closePath().moveTo(2.3,-1.3).curveTo(2.2,-2,1.7,-2.6).curveTo(1.1,-3.2,0,-3.2).curveTo(-1,-3.2,-1.6,-2.6).curveTo(-2.1,-2,-2.1,-1.3).lineTo(2.3,-1.3).lineTo(2.3,-1.3).closePath();
	this.shape_24.setTransform(2.75,-33.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.8,8).lineTo(1.8,1.7).curveTo(1.8,-0.2,0,-0.2).curveTo(-0.8,-0.2,-1.2,0.3).curveTo(-1.8,0.8,-1.8,1.6).lineTo(-1.8,8).lineTo(-5.2,8).lineTo(-5.2,-8).lineTo(-1.8,-8).lineTo(-1.8,-2.3).curveTo(-0.8,-3.2,1,-3.2).curveTo(3,-3.2,4.2,-2).curveTo(5.1,-0.8,5.2,1.1).lineTo(5.2,8).closePath();
	this.shape_25.setTransform(-9.85,-35.675);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.8,6.2).curveTo(-1.7,5.3,-1.7,3.7).lineTo(-1.7,-1).lineTo(-3.7,-1).lineTo(-3.7,-4).lineTo(-3.1,-4).curveTo(-1.4,-4,-1.4,-5.7).lineTo(-1.4,-7.2).lineTo(1.6,-7.2).lineTo(1.6,-4).lineTo(3.7,-4).lineTo(3.7,-1).lineTo(1.6,-1).lineTo(1.6,3.1).curveTo(1.6,4.2,2.8,4.2).lineTo(3.6,4.1).lineTo(3.6,6.9).curveTo(3,7.2,1.9,7.2).curveTo(0.2,7.2,-0.8,6.2).closePath();
	this.shape_26.setTransform(-20.925,-34.675);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.8,4.3).curveTo(-5.4,2.6,-5.4,-0.1).curveTo(-5.4,-2.6,-3.8,-4.3).curveTo(-2.3,-5.8,-0,-5.8).curveTo(2.5,-5.8,4,-4.4).curveTo(5.5,-2.9,5.5,-0.2).lineTo(5.4,0.8).lineTo(-2.2,0.8).curveTo(-2.2,1.7,-1.5,2.4).curveTo(-0.7,2.9,0.3,2.9).curveTo(1.9,2.9,2.5,1.5).lineTo(5.2,2.3).curveTo(4.8,3.8,3.6,4.7).curveTo(2.2,5.8,0.3,5.8).curveTo(-2.1,5.8,-3.8,4.3).closePath().moveTo(2.2,-1.3).curveTo(2.2,-2,1.7,-2.6).curveTo(1.1,-3.2,0.1,-3.2).curveTo(-1,-3.2,-1.5,-2.6).curveTo(-2.1,-2,-2.2,-1.3).lineTo(2.2,-1.3).lineTo(2.2,-1.3).closePath();
	this.shape_27.setTransform(-36.35,-33.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-5.6,7.8).lineTo(-5.6,-7.8).lineTo(0.2,-7.8).curveTo(2.5,-7.8,3.8,-6.6).curveTo(5.1,-5.5,5.1,-3.6).curveTo(5.1,-2.5,4.4,-1.5).curveTo(3.8,-0.6,2.8,-0.3).curveTo(4,-0,4.7,0.9).curveTo(5.6,1.9,5.6,3.4).curveTo(5.6,5.3,4.3,6.5).curveTo(2.9,7.8,0.7,7.8).closePath().moveTo(-2.2,5).lineTo(-0,5).curveTo(1,4.9,1.6,4.4).curveTo(2.1,4,2.1,3.2).curveTo(2.1,2.3,1.6,1.8).curveTo(1,1.3,-0,1.3).lineTo(-2.2,1.3).closePath().moveTo(-2.2,-1.6).lineTo(-0.3,-1.6).curveTo(0.6,-1.5,1.2,-2).curveTo(1.7,-2.4,1.7,-3.3).curveTo(1.7,-4.9,-0.3,-4.9).lineTo(-2.2,-4.9).closePath();
	this.shape_28.setTransform(-48.775,-35.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-59.5,-51.6,119,83.5), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,5).lineTo(-3.1,-4.9).lineTo(-0.2,-4.9).lineTo(-0.2,-3.6).curveTo(0.5,-5,2.3,-5).lineTo(3.2,-4.9).lineTo(3.2,-1.9).lineTo(2.2,-2).curveTo(1.2,-2,0.6,-1.4).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,5).closePath();
	this.shape.setTransform(46.25,43.575);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,3.9).curveTo(-4.7,2.9,-4.7,1.2).lineTo(-4.7,-5.1).lineTo(-1.7,-5.1).lineTo(-1.7,0.6).curveTo(-1.7,1.3,-1.3,1.8).curveTo(-0.9,2.3,-0.1,2.3).curveTo(0.7,2.3,1.1,1.8).curveTo(1.6,1.3,1.6,0.6).lineTo(1.6,-5.1).lineTo(4.6,-5.1).lineTo(4.6,3.1).lineTo(4.7,4.9).lineTo(1.8,4.9).lineTo(1.7,3.9).curveTo(1,5.1,-1,5.1).curveTo(-2.7,5.1,-3.7,3.9).closePath();
	this.shape_1.setTransform(35.825,43.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,7.2).lineTo(1.6,1.6).curveTo(1.6,-0.2,-0,-0.2).curveTo(-0.7,-0.2,-1.2,0.2).curveTo(-1.6,0.7,-1.6,1.4).lineTo(-1.6,7.2).lineTo(-4.7,7.2).lineTo(-4.7,-7.2).lineTo(-1.6,-7.2).lineTo(-1.6,-2).curveTo(-0.7,-2.9,0.9,-2.9).curveTo(2.8,-2.9,3.8,-1.8).curveTo(4.7,-0.8,4.7,1).lineTo(4.7,7.2).closePath();
	this.shape_2.setTransform(23.975,41.35);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.7).curveTo(-1.6,4.8,-1.6,3.3).lineTo(-1.6,-1).lineTo(-3.4,-1).lineTo(-3.4,-3.6).lineTo(-2.8,-3.6).curveTo(-1.3,-3.6,-1.3,-5.2).lineTo(-1.3,-6.5).lineTo(1.5,-6.5).lineTo(1.5,-3.6).lineTo(3.4,-3.6).lineTo(3.4,-1).lineTo(1.5,-1).lineTo(1.5,2.8).curveTo(1.5,3.8,2.6,3.8).lineTo(3.4,3.7).lineTo(3.4,6.2).curveTo(2.7,6.5,1.8,6.5).curveTo(0.2,6.5,-0.7,5.7).closePath();
	this.shape_3.setTransform(13.9,42.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,5).lineTo(-3.1,-4.9).lineTo(-0.2,-4.9).lineTo(-0.2,-3.6).curveTo(0.4,-5,2.4,-5).lineTo(3.2,-4.9).lineTo(3.2,-1.9).lineTo(2.2,-2).curveTo(1.2,-2,0.6,-1.4).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,5).closePath();
	this.shape_4.setTransform(6.8,43.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.3).curveTo(-4.5,3.5,-4.5,2.2).curveTo(-4.5,1,-3.7,0.2).curveTo(-2.9,-0.6,-1.6,-0.8).lineTo(0.7,-1.1).curveTo(1.5,-1.2,1.5,-1.8).curveTo(1.5,-2.3,1.1,-2.6).curveTo(0.7,-2.9,0,-2.9).curveTo(-0.7,-2.9,-1.2,-2.4).curveTo(-1.6,-2,-1.7,-1.4).lineTo(-4.3,-2).curveTo(-4.2,-3.2,-3.2,-4.1).curveTo(-2,-5.3,0,-5.3).curveTo(2.3,-5.3,3.4,-4.1).curveTo(4.4,-3.1,4.4,-1.4).lineTo(4.4,3.4).lineTo(4.5,5).lineTo(1.8,5).lineTo(1.7,3.9).curveTo(0.8,5.3,-1.1,5.3).curveTo(-2.7,5.3,-3.6,4.3).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,2).curveTo(-1.5,3.1,-0.4,3.1).curveTo(1.5,3.1,1.5,1.1).lineTo(1.5,0.6).closePath();
	this.shape_5.setTransform(-3.325,43.625);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.5,3.8).curveTo(-5,2.3,-5,0).curveTo(-5,-2.3,-3.5,-3.8).curveTo(-2,-5.3,0.2,-5.3).curveTo(2.1,-5.3,3.4,-4.2).curveTo(4.7,-3.3,5,-1.8).lineTo(2.3,-1).curveTo(1.8,-2.5,0.3,-2.5).curveTo(-0.7,-2.5,-1.3,-1.8).curveTo(-2,-1.1,-2,0).curveTo(-2,1.2,-1.3,1.8).curveTo(-0.7,2.5,0.3,2.5).curveTo(2,2.5,2.4,1).lineTo(5.1,1.8).curveTo(4.7,3.2,3.5,4.2).curveTo(2.2,5.3,0.3,5.3).curveTo(-1.9,5.3,-3.5,3.8).closePath();
	this.shape_6.setTransform(-14.15,43.625);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.3).curveTo(-4.5,3.5,-4.5,2.2).curveTo(-4.5,1,-3.7,0.2).curveTo(-2.9,-0.6,-1.6,-0.8).lineTo(0.7,-1.1).curveTo(1.5,-1.2,1.5,-1.8).curveTo(1.5,-2.3,1.1,-2.6).curveTo(0.7,-2.9,0,-2.9).curveTo(-0.7,-2.9,-1.2,-2.4).curveTo(-1.6,-2,-1.7,-1.4).lineTo(-4.3,-2).curveTo(-4.2,-3.2,-3.2,-4.1).curveTo(-2,-5.3,0,-5.3).curveTo(2.3,-5.3,3.4,-4.1).curveTo(4.4,-3.1,4.4,-1.4).lineTo(4.4,3.4).lineTo(4.5,5).lineTo(1.8,5).lineTo(1.7,3.9).curveTo(0.8,5.3,-1.1,5.3).curveTo(-2.7,5.3,-3.6,4.3).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,2).curveTo(-1.5,3.1,-0.4,3.1).curveTo(1.5,3.1,1.5,1.1).lineTo(1.5,0.6).closePath();
	this.shape_7.setTransform(-25.425,43.625);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.9,7.1).lineTo(4.9,-2.3).lineTo(1.2,7.1).lineTo(-1.3,7.1).lineTo(-5,-2.2).lineTo(-5,7.1).lineTo(-8,7.1).lineTo(-8,-7.1).lineTo(-3.9,-7.1).lineTo(-0,2.5).lineTo(3.7,-7.1).lineTo(8,-7.1).lineTo(8,7.1).closePath();
	this.shape_8.setTransform(-40.225,41.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.4,3.9).curveTo(-5,2.4,-5,-0).curveTo(-5,-2.3,-3.4,-3.8).curveTo(-2,-5.3,0,-5.3).curveTo(2.3,-5.3,3.7,-3.9).curveTo(5,-2.6,5,-0.2).lineTo(4.9,0.8).lineTo(-2,0.8).curveTo(-2,1.6,-1.3,2.2).curveTo(-0.6,2.7,0.3,2.7).curveTo(1.8,2.7,2.3,1.4).lineTo(4.8,2.1).curveTo(4.4,3.5,3.3,4.3).curveTo(2,5.3,0.2,5.3).curveTo(-1.9,5.3,-3.4,3.9).closePath().moveTo(2,-1.2).curveTo(2,-1.9,1.6,-2.3).curveTo(1,-2.9,0,-2.9).curveTo(-0.8,-2.9,-1.4,-2.3).curveTo(-1.9,-1.8,-1.9,-1.2).lineTo(2,-1.2).lineTo(2,-1.2).closePath();
	this.shape_9.setTransform(20.975,21.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,7.2).lineTo(1.6,1.6).curveTo(1.6,-0.2,-0,-0.2).curveTo(-0.7,-0.2,-1.2,0.2).curveTo(-1.6,0.7,-1.6,1.4).lineTo(-1.6,7.2).lineTo(-4.7,7.2).lineTo(-4.7,-7.3).lineTo(-1.6,-7.3).lineTo(-1.6,-2).curveTo(-0.7,-3,0.9,-2.9).curveTo(2.8,-2.9,3.8,-1.8).curveTo(4.7,-0.8,4.7,1).lineTo(4.7,7.2).closePath();
	this.shape_10.setTransform(9.525,19.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.7).curveTo(-1.6,4.8,-1.5,3.3).lineTo(-1.5,-1).lineTo(-3.3,-1).lineTo(-3.3,-3.6).lineTo(-2.9,-3.6).curveTo(-1.3,-3.6,-1.3,-5.2).lineTo(-1.3,-6.5).lineTo(1.4,-6.5).lineTo(1.4,-3.6).lineTo(3.3,-3.6).lineTo(3.3,-1).lineTo(1.4,-1).lineTo(1.4,2.8).curveTo(1.4,3.8,2.5,3.8).lineTo(3.3,3.7).lineTo(3.3,6.2).curveTo(2.8,6.5,1.7,6.5).curveTo(0.2,6.5,-0.7,5.7).closePath();
	this.shape_11.setTransform(-0.55,19.975);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,5.1).lineTo(1.6,-0.6).curveTo(1.6,-2.3,-0,-2.4).curveTo(-0.7,-2.3,-1.2,-1.8).curveTo(-1.6,-1.4,-1.6,-0.6).lineTo(-1.6,5.1).lineTo(-4.7,5.1).lineTo(-4.7,-4.8).lineTo(-1.7,-4.8).lineTo(-1.7,-3.7).curveTo(-1.4,-4.3,-0.5,-4.7).curveTo(0.2,-5.1,1,-5.1).curveTo(2.8,-5.1,3.8,-3.9).curveTo(4.7,-2.9,4.7,-1.1).lineTo(4.7,5.1).closePath();
	this.shape_12.setTransform(-14.875,21.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7.4).lineTo(-1.5,-2.6).lineTo(1.5,-2.6).lineTo(1.5,7.4).closePath().moveTo(-1.3,-4.3).curveTo(-1.8,-4.9,-1.8,-5.6).curveTo(-1.8,-6.3,-1.3,-6.9).curveTo(-0.8,-7.4,-0,-7.4).curveTo(0.7,-7.4,1.2,-6.9).curveTo(1.8,-6.3,1.8,-5.6).curveTo(1.8,-4.9,1.2,-4.3).curveTo(0.7,-3.8,-0,-3.8).curveTo(-0.8,-3.8,-1.3,-4.3).closePath();
	this.shape_13.setTransform(-23.725,18.925);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,6.9).lineTo(-1.4,1.7).lineTo(-5.6,-6.9).lineTo(-2.2,-6.9).lineTo(0.2,-1.5).lineTo(2.4,-6.9).lineTo(5.6,-6.9).lineTo(-0.5,6.9).closePath();
	this.shape_14.setTransform(47.975,0.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,5.7).curveTo(-1.6,4.8,-1.6,3.3).lineTo(-1.6,-1).lineTo(-3.4,-1).lineTo(-3.4,-3.6).lineTo(-2.8,-3.6).curveTo(-1.3,-3.6,-1.3,-5.2).lineTo(-1.3,-6.5).lineTo(1.5,-6.5).lineTo(1.5,-3.6).lineTo(3.4,-3.6).lineTo(3.4,-1).lineTo(1.5,-1).lineTo(1.5,2.8).curveTo(1.5,3.8,2.6,3.8).lineTo(3.4,3.7).lineTo(3.4,6.2).curveTo(2.7,6.5,1.8,6.5).curveTo(0.2,6.5,-0.7,5.7).closePath();
	this.shape_15.setTransform(38.2,-2.325);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7.4).lineTo(-1.5,-2.6).lineTo(1.5,-2.6).lineTo(1.5,7.4).closePath().moveTo(-1.3,-4.3).curveTo(-1.8,-4.9,-1.8,-5.6).curveTo(-1.8,-6.3,-1.3,-6.9).curveTo(-0.8,-7.4,-0,-7.4).curveTo(0.7,-7.4,1.2,-6.9).curveTo(1.8,-6.3,1.8,-5.6).curveTo(1.8,-4.9,1.2,-4.3).curveTo(0.7,-3.8,-0,-3.8).curveTo(-0.8,-3.8,-1.3,-4.3).closePath();
	this.shape_16.setTransform(31.825,-3.375);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,5.1).lineTo(1.6,-0.6).curveTo(1.6,-2.3,-0,-2.3).curveTo(-0.7,-2.3,-1.2,-1.9).curveTo(-1.6,-1.3,-1.6,-0.6).lineTo(-1.6,5.1).lineTo(-4.7,5.1).lineTo(-4.7,-4.8).lineTo(-1.7,-4.8).lineTo(-1.7,-3.7).curveTo(-1.4,-4.4,-0.5,-4.8).curveTo(0.2,-5.1,1,-5.1).curveTo(2.8,-5.1,3.8,-3.9).curveTo(4.7,-2.9,4.7,-1.2).lineTo(4.7,5.1).closePath();
	this.shape_17.setTransform(23.075,-1.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,3.9).curveTo(-4.7,2.9,-4.7,1.2).lineTo(-4.7,-5.1).lineTo(-1.7,-5.1).lineTo(-1.7,0.6).curveTo(-1.7,1.3,-1.3,1.8).curveTo(-0.9,2.3,-0.1,2.3).curveTo(0.7,2.3,1.1,1.8).curveTo(1.6,1.3,1.6,0.6).lineTo(1.6,-5.1).lineTo(4.6,-5.1).lineTo(4.6,3.1).lineTo(4.7,4.9).lineTo(1.8,4.9).lineTo(1.7,3.9).curveTo(1,5.1,-1,5.1).curveTo(-2.7,5.1,-3.7,3.9).closePath();
	this.shape_18.setTransform(11.125,-0.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.8,5.1).lineTo(4.8,-0.6).curveTo(4.8,-2.3,3.2,-2.3).curveTo(2.4,-2.3,2,-1.8).curveTo(1.5,-1.3,1.5,-0.6).lineTo(1.5,5.1).lineTo(-1.5,5.1).lineTo(-1.5,-0.6).curveTo(-1.5,-2.3,-3.1,-2.3).curveTo(-3.8,-2.3,-4.3,-1.8).curveTo(-4.7,-1.3,-4.7,-0.6).lineTo(-4.7,5.1).lineTo(-7.7,5.1).lineTo(-7.7,-4.8).lineTo(-4.8,-4.8).lineTo(-4.8,-3.7).curveTo(-4.5,-4.3,-3.6,-4.7).curveTo(-2.8,-5.1,-2,-5.1).curveTo(0.2,-5.1,1,-3.6).curveTo(2,-5.1,4,-5.1).curveTo(5.6,-5.1,6.6,-4.2).curveTo(7.7,-3.2,7.7,-1.3).lineTo(7.7,5.1).closePath();
	this.shape_19.setTransform(-3.775,-1.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(4.8,5.1).lineTo(4.8,-0.6).curveTo(4.8,-2.3,3.2,-2.3).curveTo(2.4,-2.3,2,-1.8).curveTo(1.5,-1.3,1.5,-0.6).lineTo(1.5,5.1).lineTo(-1.5,5.1).lineTo(-1.5,-0.6).curveTo(-1.5,-2.3,-3.1,-2.3).curveTo(-3.8,-2.3,-4.3,-1.8).curveTo(-4.7,-1.3,-4.7,-0.6).lineTo(-4.7,5.1).lineTo(-7.7,5.1).lineTo(-7.7,-4.8).lineTo(-4.8,-4.8).lineTo(-4.8,-3.7).curveTo(-4.5,-4.3,-3.6,-4.7).curveTo(-2.8,-5.1,-2,-5.1).curveTo(0.2,-5.1,1,-3.6).curveTo(2,-5.1,4,-5.1).curveTo(5.6,-5.1,6.6,-4.2).curveTo(7.7,-3.2,7.7,-1.3).lineTo(7.7,5.1).closePath();
	this.shape_20.setTransform(-21.775,-1.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,3.8).curveTo(-5.3,2.3,-5.3,-0).curveTo(-5.3,-2.3,-3.7,-3.8).curveTo(-2.2,-5.3,-0,-5.3).curveTo(2.3,-5.3,3.8,-3.8).curveTo(5.3,-2.3,5.3,-0).curveTo(5.3,2.3,3.8,3.8).curveTo(2.3,5.3,-0,5.3).curveTo(-2.2,5.3,-3.7,3.8).closePath().moveTo(-1.6,-1.9).curveTo(-2.3,-1.2,-2.3,-0).curveTo(-2.3,1.2,-1.6,1.9).curveTo(-0.9,2.5,-0,2.5).curveTo(1,2.5,1.5,1.9).curveTo(2.3,1.2,2.2,-0).curveTo(2.3,-1.2,1.5,-1.9).curveTo(1,-2.5,-0,-2.5).curveTo(-0.9,-2.5,-1.6,-1.9).closePath();
	this.shape_21.setTransform(-36.7,-0.975);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.4,3.8).curveTo(-5.1,2.3,-5,0).curveTo(-5,-2.3,-3.5,-3.8).curveTo(-2,-5.3,0.2,-5.3).curveTo(2.2,-5.3,3.4,-4.2).curveTo(4.6,-3.3,5,-1.8).lineTo(2.2,-1).curveTo(1.9,-2.5,0.3,-2.5).curveTo(-0.7,-2.5,-1.4,-1.8).curveTo(-2,-1.1,-2,0).curveTo(-2,1.2,-1.3,1.8).curveTo(-0.7,2.5,0.3,2.5).curveTo(2,2.5,2.3,1).lineTo(5,1.8).curveTo(4.7,3.2,3.5,4.2).curveTo(2.2,5.3,0.3,5.3).curveTo(-1.9,5.3,-3.4,3.8).closePath();
	this.shape_22.setTransform(-48.15,-0.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-5.2,7).lineTo(-5.2,-6.8).lineTo(-2.3,-6.8).lineTo(-2.3,-5.7).curveTo(-2,-6.3,-1.2,-6.6).curveTo(-0.4,-7,0.6,-7).curveTo(2.7,-7,4,-5.5).curveTo(5.2,-4.1,5.2,-1.8).curveTo(5.2,0.5,3.9,2).curveTo(2.6,3.4,0.5,3.4).curveTo(-1.4,3.4,-2.2,2.4).lineTo(-2.2,7).closePath().moveTo(-1.6,-3.6).curveTo(-2.2,-3,-2.2,-1.8).curveTo(-2.2,-0.6,-1.6,0.1).curveTo(-0.9,0.7,0,0.7).curveTo(1,0.7,1.6,0.1).curveTo(2.3,-0.6,2.3,-1.8).curveTo(2.3,-3,1.6,-3.6).curveTo(1,-4.3,0,-4.2).curveTo(-0.9,-4.3,-1.6,-3.6).closePath();
	this.shape_23.setTransform(31.775,-21.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7.4).lineTo(-1.5,-2.6).lineTo(1.5,-2.6).lineTo(1.5,7.4).closePath().moveTo(-1.3,-4.3).curveTo(-1.8,-4.9,-1.8,-5.6).curveTo(-1.8,-6.3,-1.3,-6.9).curveTo(-0.8,-7.4,-0,-7.4).curveTo(0.7,-7.4,1.2,-6.9).curveTo(1.8,-6.3,1.8,-5.6).curveTo(1.8,-4.9,1.2,-4.3).curveTo(0.7,-3.8,-0,-3.8).curveTo(-0.8,-3.8,-1.3,-4.3).closePath();
	this.shape_24.setTransform(22.375,-25.675);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,7.3).lineTo(1.6,1.5).curveTo(1.6,-0.2,-0,-0.2).curveTo(-0.7,-0.2,-1.2,0.3).curveTo(-1.6,0.7,-1.6,1.4).lineTo(-1.6,7.3).lineTo(-4.7,7.3).lineTo(-4.7,-7.2).lineTo(-1.6,-7.2).lineTo(-1.6,-2.1).curveTo(-0.7,-2.9,0.9,-3).curveTo(2.8,-3,3.8,-1.8).curveTo(4.7,-0.7,4.7,1).lineTo(4.7,7.3).closePath();
	this.shape_25.setTransform(13.625,-25.55);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.1,4.1).curveTo(-4,3.3,-4.1,2.2).lineTo(-1.5,1.7).curveTo(-1.4,2.3,-1.1,2.6).curveTo(-0.7,3,0.1,3).curveTo(1.2,3,1.2,2.2).curveTo(1.2,1.6,0.2,1.4).lineTo(-0.9,1.1).curveTo(-3.9,0.5,-3.9,-2).curveTo(-3.9,-3.3,-2.8,-4.3).curveTo(-1.7,-5.3,-0,-5.3).curveTo(1.9,-5.3,3,-4.2).curveTo(3.8,-3.4,3.9,-2.3).lineTo(1.4,-1.8).curveTo(1.3,-3.1,-0,-3.1).curveTo(-0.4,-3.1,-0.7,-2.8).curveTo(-1.1,-2.6,-1.1,-2.2).curveTo(-1.1,-1.6,-0.3,-1.5).lineTo(1,-1.2).curveTo(2.5,-0.9,3.3,-0).curveTo(4.1,0.8,4.1,1.9).curveTo(4.1,3.3,3.1,4.2).curveTo(2,5.3,0.1,5.3).curveTo(-1.9,5.3,-3.1,4.1).closePath();
	this.shape_26.setTransform(2.9,-23.275);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,6).curveTo(-4.9,5,-5.1,3.6).lineTo(-2.5,2.8).curveTo(-2.3,3.5,-1.7,4).curveTo(-1.2,4.4,-0.3,4.5).curveTo(2.1,4.4,2.1,1.9).lineTo(2.1,1.4).curveTo(1.4,2.6,-0.5,2.6).curveTo(-2.5,2.6,-3.8,1.2).curveTo(-5.1,-0.2,-5.1,-2.3).curveTo(-5.1,-4.2,-3.8,-5.6).curveTo(-2.5,-7.1,-0.5,-7.1).curveTo(1.6,-7.1,2.2,-5.9).lineTo(2.2,-7).lineTo(5.1,-7).lineTo(5.1,1.8).curveTo(5.1,4,3.9,5.5).curveTo(2.5,7.1,-0.2,7.1).curveTo(-2.2,7.1,-3.6,6).closePath().moveTo(-1.4,-3.8).curveTo(-2.1,-3.2,-2.1,-2.3).curveTo(-2.1,-1.2,-1.5,-0.7).curveTo(-0.9,-0,0,-0).curveTo(1,-0,1.6,-0.7).curveTo(2.2,-1.2,2.2,-2.3).curveTo(2.2,-3.2,1.5,-3.8).curveTo(0.9,-4.5,0,-4.4).curveTo(-0.8,-4.5,-1.4,-3.8).closePath();
	this.shape_27.setTransform(-8.025,-21.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.3).curveTo(-4.5,3.5,-4.5,2.2).curveTo(-4.5,1,-3.7,0.2).curveTo(-2.9,-0.6,-1.6,-0.8).lineTo(0.7,-1.1).curveTo(1.5,-1.2,1.5,-1.8).curveTo(1.5,-2.3,1.1,-2.6).curveTo(0.7,-2.9,0,-2.9).curveTo(-0.7,-2.9,-1.2,-2.4).curveTo(-1.6,-2,-1.7,-1.4).lineTo(-4.3,-2).curveTo(-4.2,-3.2,-3.2,-4.1).curveTo(-2,-5.3,0,-5.3).curveTo(2.3,-5.3,3.4,-4.1).curveTo(4.4,-3.1,4.4,-1.4).lineTo(4.4,3.4).lineTo(4.5,5).lineTo(1.8,5).lineTo(1.7,3.9).curveTo(0.8,5.3,-1.1,5.3).curveTo(-2.7,5.3,-3.6,4.3).closePath().moveTo(-0.4,0.9).curveTo(-1.5,1.1,-1.5,2).curveTo(-1.5,3.1,-0.4,3.1).curveTo(1.5,3.1,1.5,1.1).lineTo(1.5,0.6).closePath();
	this.shape_28.setTransform(-19.425,-23.275);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.5,7.3).lineTo(-1.5,-7.2).lineTo(1.5,-7.2).lineTo(1.5,7.3).closePath();
	this.shape_29.setTransform(-27.525,-25.55);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.8,7.3).lineTo(-1.8,-0.1).lineTo(-3.4,-0.1).lineTo(-3.4,-2.6).lineTo(-1.8,-2.6).lineTo(-1.8,-3.5).curveTo(-1.8,-5.2,-0.8,-6.2).curveTo(0.2,-7.3,2,-7.3).curveTo(3,-7.3,3.4,-7.1).lineTo(3.4,-4.6).lineTo(2.5,-4.7).curveTo(1.2,-4.7,1.2,-3.4).lineTo(1.2,-2.6).lineTo(3.4,-2.6).lineTo(3.4,-0.1).lineTo(1.2,-0.1).lineTo(1.2,7.3).closePath();
	this.shape_30.setTransform(-34.025,-25.625);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginFill("#FFFFFF").beginStroke().moveTo(2.2,5).lineTo(0,-1.4).lineTo(-2.1,5).lineTo(-5.2,5).lineTo(-8.3,-5).lineTo(-5.1,-5).lineTo(-3.5,0.9).lineTo(-1.5,-5).lineTo(1.7,-5).lineTo(3.6,0.9).lineTo(5.3,-5).lineTo(8.3,-5).lineTo(5.2,5).closePath();
	this.shape_31.setTransform(21.3,-45.575);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.4,3.9).curveTo(-5,2.4,-5,-0).curveTo(-5,-2.3,-3.4,-3.8).curveTo(-2,-5.3,0,-5.3).curveTo(2.3,-5.3,3.7,-3.9).curveTo(5,-2.6,5,-0.2).lineTo(4.9,0.8).lineTo(-2,0.8).curveTo(-2,1.6,-1.3,2.2).curveTo(-0.6,2.7,0.3,2.7).curveTo(1.8,2.7,2.3,1.4).lineTo(4.8,2.1).curveTo(4.4,3.5,3.3,4.3).curveTo(2,5.3,0.2,5.3).curveTo(-1.9,5.3,-3.4,3.9).closePath().moveTo(2,-1.2).curveTo(2,-1.9,1.6,-2.3).curveTo(1,-2.9,0,-2.9).curveTo(-0.8,-2.9,-1.4,-2.3).curveTo(-1.9,-1.8,-1.9,-1.2).lineTo(2,-1.2).lineTo(2,-1.2).closePath();
	this.shape_32.setTransform(7.225,-45.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.6,5.1).lineTo(1.6,-0.6).curveTo(1.6,-2.4,-0,-2.4).curveTo(-0.7,-2.4,-1.2,-1.8).curveTo(-1.6,-1.4,-1.6,-0.6).lineTo(-1.6,5.1).lineTo(-4.7,5.1).lineTo(-4.7,-4.9).lineTo(-1.7,-4.9).lineTo(-1.7,-3.7).curveTo(-1.4,-4.3,-0.5,-4.8).curveTo(0.2,-5.1,1,-5.1).curveTo(2.8,-5.1,3.8,-4).curveTo(4.7,-2.9,4.7,-1.2).lineTo(4.7,5.1).closePath();
	this.shape_33.setTransform(-4.225,-45.7);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginFill("#FFFFFF").beginStroke().moveTo(3.7,7.1).lineTo(2.6,4.2).lineTo(-2.8,4.2).lineTo(-3.8,7.1).lineTo(-7.2,7.1).lineTo(-1.8,-7.1).lineTo(1.8,-7.1).lineTo(7.1,7.1).closePath().moveTo(1.7,1.3).lineTo(-0.1,-3.5).lineTo(-1.8,1.3).lineTo(1.7,1.3).closePath();
	this.shape_34.setTransform(-22.45,-47.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-66.5,-62.5,133,118.5), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.9,7.2).lineTo(-1.5,1.8).lineTo(-5.9,-7.2).lineTo(-2.3,-7.2).lineTo(0.2,-1.6).lineTo(2.5,-7.2).lineTo(5.9,-7.2).lineTo(-0.5,7.2).closePath();
	this.shape.setTransform(38.125,24.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.6,7.6).lineTo(-1.6,-7.6).lineTo(1.6,-7.6).lineTo(1.6,7.6).closePath();
	this.shape_1.setTransform(29.1,19.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.6,7.6).lineTo(-1.6,-7.6).lineTo(1.6,-7.6).lineTo(1.6,7.6).closePath();
	this.shape_2.setTransform(23.1,19.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.9,4.6).curveTo(-4.8,3.7,-4.8,2.3).curveTo(-4.7,1,-3.9,0.2).curveTo(-3,-0.6,-1.7,-0.8).lineTo(0.7,-1.2).curveTo(1.6,-1.3,1.6,-1.9).curveTo(1.6,-2.4,1.2,-2.7).curveTo(0.7,-3,0,-3).curveTo(-0.8,-3,-1.3,-2.6).curveTo(-1.7,-2.1,-1.8,-1.5).lineTo(-4.6,-2.1).curveTo(-4.5,-3.4,-3.4,-4.4).curveTo(-2.1,-5.5,0,-5.5).curveTo(2.4,-5.5,3.6,-4.3).curveTo(4.7,-3.3,4.6,-1.5).lineTo(4.6,3.6).lineTo(4.8,5.2).lineTo(1.9,5.2).lineTo(1.8,4).curveTo(0.8,5.5,-1.1,5.5).curveTo(-2.8,5.5,-3.9,4.6).closePath().moveTo(-0.4,1).curveTo(-1.6,1.2,-1.6,2.1).curveTo(-1.6,3.2,-0.4,3.2).curveTo(1.6,3.2,1.6,1.1).lineTo(1.6,0.7).closePath();
	this.shape_3.setTransform(14.2,22.075);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,5.3).lineTo(-3.3,-5.2).lineTo(-0.2,-5.2).lineTo(-0.2,-3.8).curveTo(0.5,-5.3,2.5,-5.3).lineTo(3.3,-5.2).lineTo(3.3,-2).lineTo(2.3,-2.1).curveTo(1.3,-2.1,0.6,-1.5).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,5.3).closePath();
	this.shape_4.setTransform(4.925,22.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.9,4.2).curveTo(-4.9,3,-4.9,1.3).lineTo(-4.9,-5.4).lineTo(-1.8,-5.4).lineTo(-1.8,0.6).curveTo(-1.8,1.4,-1.3,1.8).curveTo(-0.9,2.4,-0.1,2.4).curveTo(0.7,2.4,1.2,1.9).curveTo(1.6,1.4,1.6,0.6).lineTo(1.6,-5.4).lineTo(4.9,-5.4).lineTo(4.9,3.3).lineTo(5,5.1).lineTo(1.9,5.1).lineTo(1.8,4.1).curveTo(1,5.4,-1,5.3).curveTo(-2.9,5.4,-3.9,4.2).closePath();
	this.shape_5.setTransform(-6.05,22.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,6).curveTo(-1.7,5,-1.6,3.5).lineTo(-1.6,-1).lineTo(-3.5,-1).lineTo(-3.5,-3.8).lineTo(-3,-3.8).curveTo(-1.4,-3.8,-1.4,-5.5).lineTo(-1.4,-6.9).lineTo(1.5,-6.9).lineTo(1.5,-3.8).lineTo(3.5,-3.8).lineTo(3.5,-1).lineTo(1.5,-1).lineTo(1.5,2.9).curveTo(1.5,4,2.7,4).lineTo(3.5,3.9).lineTo(3.5,6.5).curveTo(2.9,6.8,1.8,6.9).curveTo(0.2,6.8,-0.7,6).closePath();
	this.shape_6.setTransform(-16.55,20.65);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.9,4.6).curveTo(-4.8,3.7,-4.8,2.3).curveTo(-4.8,1,-3.9,0.2).curveTo(-3.1,-0.6,-1.7,-0.8).lineTo(0.7,-1.2).curveTo(1.6,-1.3,1.5,-1.9).curveTo(1.5,-2.4,1.2,-2.7).curveTo(0.7,-3,0,-3).curveTo(-0.8,-3,-1.3,-2.6).curveTo(-1.7,-2.1,-1.8,-1.5).lineTo(-4.6,-2.1).curveTo(-4.5,-3.4,-3.4,-4.4).curveTo(-2.1,-5.5,0,-5.5).curveTo(2.4,-5.5,3.6,-4.3).curveTo(4.7,-3.3,4.7,-1.5).lineTo(4.7,3.6).lineTo(4.8,5.2).lineTo(1.9,5.2).lineTo(1.8,4).curveTo(0.9,5.5,-1.2,5.5).curveTo(-2.8,5.5,-3.9,4.6).closePath().moveTo(-0.4,1).curveTo(-1.6,1.2,-1.6,2.1).curveTo(-1.6,3.2,-0.4,3.2).curveTo(1.6,3.2,1.5,1.1).lineTo(1.5,0.7).closePath();
	this.shape_7.setTransform(-26.2,22.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.7,5.3).lineTo(1.7,-0.6).curveTo(1.7,-2.5,0,-2.4).curveTo(-0.8,-2.4,-1.3,-2).curveTo(-1.7,-1.4,-1.7,-0.6).lineTo(-1.7,5.3).lineTo(-4.9,5.3).lineTo(-4.9,-5.1).lineTo(-1.8,-5.1).lineTo(-1.8,-3.9).curveTo(-1.4,-4.6,-0.5,-5).curveTo(0.2,-5.4,1.1,-5.4).curveTo(3,-5.4,4,-4.1).curveTo(4.9,-3,4.9,-1.2).lineTo(4.9,5.3).closePath();
	this.shape_8.setTransform(-37.9,21.95);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,4.3).curveTo(-4.2,3.4,-4.3,2.3).lineTo(-1.6,1.8).curveTo(-1.5,2.4,-1.1,2.8).curveTo(-0.7,3.2,0.1,3.2).curveTo(1.3,3.2,1.3,2.3).curveTo(1.3,1.6,0.3,1.4).lineTo(-0.9,1.2).curveTo(-4,0.5,-4,-2.1).curveTo(-4,-3.5,-2.9,-4.5).curveTo(-1.8,-5.5,-0,-5.5).curveTo(2,-5.5,3.1,-4.4).curveTo(4,-3.6,4.1,-2.4).lineTo(1.5,-1.9).curveTo(1.3,-3.2,0,-3.2).curveTo(-0.5,-3.2,-0.8,-3).curveTo(-1.1,-2.7,-1.1,-2.3).curveTo(-1.1,-1.7,-0.3,-1.5).lineTo(1.1,-1.3).curveTo(2.7,-0.9,3.5,-0).curveTo(4.3,0.8,4.3,2).curveTo(4.3,3.5,3.3,4.4).curveTo(2.1,5.5,0.1,5.5).curveTo(-2.1,5.5,-3.3,4.3).closePath();
	this.shape_9.setTransform(27.275,-2.525);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.1).curveTo(-5.2,2.5,-5.2,-0).curveTo(-5.2,-2.5,-3.6,-4).curveTo(-2.1,-5.5,-0,-5.5).curveTo(2.4,-5.5,3.8,-4.1).curveTo(5.2,-2.7,5.2,-0.2).lineTo(5.1,0.8).lineTo(-2.1,0.8).curveTo(-2.1,1.7,-1.4,2.3).curveTo(-0.7,2.8,0.3,2.8).curveTo(1.9,2.8,2.4,1.5).lineTo(5,2.2).curveTo(4.6,3.7,3.4,4.6).curveTo(2.1,5.5,0.2,5.5).curveTo(-2,5.5,-3.6,4.1).closePath().moveTo(2.1,-1.2).curveTo(2.1,-2,1.6,-2.4).curveTo(1.1,-3,0,-3).curveTo(-0.9,-3,-1.5,-2.4).curveTo(-2,-1.9,-2.1,-1.2).lineTo(2.1,-1.2).lineTo(2.1,-1.2).closePath();
	this.shape_10.setTransform(16.625,-2.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill("#FFFFFF").beginStroke().moveTo(5,5.4).lineTo(5,-0.7).curveTo(5,-2.4,3.4,-2.4).curveTo(2.6,-2.4,2.1,-1.9).curveTo(1.6,-1.4,1.6,-0.7).lineTo(1.6,5.4).lineTo(-1.5,5.4).lineTo(-1.5,-0.7).curveTo(-1.5,-2.4,-3.2,-2.4).curveTo(-4,-2.4,-4.5,-1.9).curveTo(-4.9,-1.4,-4.9,-0.6).lineTo(-4.9,5.4).lineTo(-8.1,5.4).lineTo(-8.1,-5.1).lineTo(-5.1,-5.1).lineTo(-5.1,-3.9).curveTo(-4.7,-4.5,-3.8,-5).curveTo(-3,-5.4,-2.1,-5.4).curveTo(0.2,-5.4,1,-3.7).curveTo(2.2,-5.4,4.2,-5.4).curveTo(5.9,-5.4,6.9,-4.4).curveTo(8.1,-3.4,8.1,-1.4).lineTo(8.1,5.4).closePath();
	this.shape_11.setTransform(1.375,-2.675);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-4,4).curveTo(-5.6,2.4,-5.6,-0).curveTo(-5.6,-2.4,-4,-4).curveTo(-2.4,-5.5,-0,-5.5).curveTo(2.4,-5.5,3.9,-4).curveTo(5.5,-2.4,5.6,-0).curveTo(5.5,2.4,3.9,4).curveTo(2.4,5.5,-0,5.5).curveTo(-2.4,5.5,-4,4).closePath().moveTo(-1.6,-2).curveTo(-2.4,-1.3,-2.4,-0).curveTo(-2.4,1.2,-1.6,2).curveTo(-1,2.6,-0,2.6).curveTo(1,2.6,1.6,2).curveTo(2.3,1.2,2.3,-0).curveTo(2.3,-1.3,1.6,-2).curveTo(1,-2.6,-0,-2.6).curveTo(-1,-2.6,-1.6,-2).closePath();
	this.shape_12.setTransform(-14.3,-2.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.7,4).curveTo(-5.3,2.4,-5.3,0).curveTo(-5.3,-2.4,-3.7,-4).curveTo(-2.2,-5.5,0.2,-5.5).curveTo(2.3,-5.5,3.6,-4.4).curveTo(4.9,-3.4,5.2,-1.9).lineTo(2.4,-1).curveTo(1.9,-2.6,0.3,-2.6).curveTo(-0.8,-2.6,-1.4,-1.9).curveTo(-2.2,-1.2,-2.1,0).curveTo(-2.1,1.2,-1.4,1.9).curveTo(-0.7,2.6,0.3,2.6).curveTo(2,2.6,2.4,1).lineTo(5.3,1.9).curveTo(4.9,3.4,3.6,4.4).curveTo(2.3,5.5,0.3,5.5).curveTo(-2.1,5.5,-3.7,4).closePath();
	this.shape_13.setTransform(-26.3,-2.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.1).curveTo(-5.2,2.5,-5.2,-0).curveTo(-5.2,-2.5,-3.6,-4).curveTo(-2.1,-5.5,-0,-5.5).curveTo(2.4,-5.5,3.8,-4.1).curveTo(5.2,-2.7,5.2,-0.2).lineTo(5.1,0.8).lineTo(-2.1,0.8).curveTo(-2.1,1.7,-1.4,2.3).curveTo(-0.7,2.8,0.3,2.8).curveTo(1.9,2.8,2.4,1.5).lineTo(5,2.2).curveTo(4.6,3.7,3.4,4.6).curveTo(2.1,5.5,0.2,5.5).curveTo(-2,5.5,-3.6,4.1).closePath().moveTo(2.1,-1.2).curveTo(2.1,-2,1.6,-2.4).curveTo(1.1,-3,0,-3).curveTo(-0.9,-3,-1.5,-2.4).curveTo(-2,-1.9,-2.1,-1.2).lineTo(2.1,-1.2).lineTo(2.1,-1.2).closePath();
	this.shape_14.setTransform(45.425,-27.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.9,7.7).lineTo(-1.9,-0.1).lineTo(-3.6,-0.1).lineTo(-3.6,-2.8).lineTo(-1.9,-2.8).lineTo(-1.9,-3.7).curveTo(-1.9,-5.5,-0.9,-6.6).curveTo(0.2,-7.7,2.1,-7.7).curveTo(3.1,-7.7,3.6,-7.5).lineTo(3.6,-4.9).lineTo(2.6,-5).curveTo(1.3,-5,1.3,-3.6).lineTo(1.3,-2.8).lineTo(3.5,-2.8).lineTo(3.5,-0.1).lineTo(1.3,-0.1).lineTo(1.3,7.7).closePath();
	this.shape_15.setTransform(35.775,-29.575);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.6,7.8).lineTo(-1.6,-2.7).lineTo(1.6,-2.7).lineTo(1.6,7.8).closePath().moveTo(-1.3,-4.6).curveTo(-1.9,-5.1,-1.8,-5.9).curveTo(-1.9,-6.7,-1.3,-7.2).curveTo(-0.7,-7.8,-0,-7.8).curveTo(0.7,-7.8,1.3,-7.2).curveTo(1.8,-6.7,1.9,-5.9).curveTo(1.8,-5.1,1.3,-4.6).curveTo(0.7,-4,-0,-4).curveTo(-0.7,-4,-1.3,-4.6).closePath();
	this.shape_16.setTransform(29,-29.65);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-1.6,7.6).lineTo(-1.6,-7.6).lineTo(1.6,-7.6).lineTo(1.6,7.6).closePath();
	this.shape_17.setTransform(23,-29.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.1).curveTo(-5.2,2.5,-5.2,-0).curveTo(-5.2,-2.5,-3.6,-4).curveTo(-2.1,-5.5,-0,-5.5).curveTo(2.4,-5.5,3.8,-4.1).curveTo(5.2,-2.7,5.2,-0.2).lineTo(5.1,0.8).lineTo(-2.1,0.8).curveTo(-2.1,1.7,-1.4,2.3).curveTo(-0.7,2.8,0.3,2.8).curveTo(1.9,2.8,2.4,1.5).lineTo(5,2.2).curveTo(4.6,3.7,3.4,4.6).curveTo(2.1,5.5,0.2,5.5).curveTo(-2,5.5,-3.6,4.1).closePath().moveTo(2.1,-1.2).curveTo(2.1,-2,1.6,-2.4).curveTo(1.1,-3,0,-3).curveTo(-0.9,-3,-1.5,-2.4).curveTo(-2,-1.9,-2.1,-1.2).lineTo(2.1,-1.2).lineTo(2.1,-1.2).closePath();
	this.shape_18.setTransform(9.025,-27.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.3,5.3).lineTo(-3.3,-5.2).lineTo(-0.2,-5.2).lineTo(-0.2,-3.8).curveTo(0.5,-5.3,2.5,-5.3).lineTo(3.3,-5.2).lineTo(3.3,-2).lineTo(2.3,-2.1).curveTo(1.3,-2.1,0.6,-1.5).curveTo(-0.1,-0.7,-0.1,0.7).lineTo(-0.1,5.3).closePath();
	this.shape_19.setTransform(-0.575,-27.175);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-3.6,4.1).curveTo(-5.2,2.5,-5.2,-0).curveTo(-5.2,-2.5,-3.6,-4).curveTo(-2.1,-5.5,-0,-5.5).curveTo(2.4,-5.5,3.8,-4.1).curveTo(5.2,-2.7,5.2,-0.2).lineTo(5.1,0.8).lineTo(-2.1,0.8).curveTo(-2.1,1.7,-1.4,2.3).curveTo(-0.7,2.8,0.3,2.8).curveTo(1.9,2.8,2.4,1.5).lineTo(5,2.2).curveTo(4.6,3.7,3.4,4.6).curveTo(2.1,5.5,0.2,5.5).curveTo(-2,5.5,-3.6,4.1).closePath().moveTo(2.1,-1.2).curveTo(2.1,-2,1.6,-2.4).curveTo(1.1,-3,0,-3).curveTo(-0.9,-3,-1.5,-2.4).curveTo(-2,-1.9,-2.1,-1.2).lineTo(2.1,-1.2).lineTo(2.1,-1.2).closePath();
	this.shape_20.setTransform(-11.125,-27.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1.7,7.6).lineTo(1.7,1.6).curveTo(1.7,-0.2,0,-0.2).curveTo(-0.7,-0.2,-1.2,0.2).curveTo(-1.6,0.7,-1.7,1.4).lineTo(-1.7,7.6).lineTo(-4.9,7.6).lineTo(-4.9,-7.6).lineTo(-1.7,-7.6).lineTo(-1.7,-2.2).curveTo(-0.7,-3.1,0.9,-3.1).curveTo(2.9,-3.1,4,-1.9).curveTo(4.9,-0.8,4.9,1.1).lineTo(4.9,7.6).closePath();
	this.shape_21.setTransform(-23.15,-29.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill("#FFFFFF").beginStroke().moveTo(3.2,7.5).lineTo(0,-2.4).lineTo(-3.2,7.5).lineTo(-6.6,7.5).lineTo(-10.7,-7.5).lineTo(-7.2,-7.5).lineTo(-4.7,2.1).lineTo(-1.6,-7.5).lineTo(1.8,-7.5).lineTo(4.9,2.1).lineTo(7.3,-7.5).lineTo(10.7,-7.5).lineTo(6.6,7.5).closePath();
	this.shape_22.setTransform(-40.325,-29.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-66.5,-44.8,133,79.8), null);


(lib.planebyitself = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFFF").setStrokeStyle(5).moveTo(-82.5,43.8).curveTo(-82.4,43.1,-82.2,42.2).lineTo(-82.1,39.2).curveTo(-81.5,33,-80.3,28.8).curveTo(-78.5,22.5,-73.4,20.7).curveTo(-59.3,15.7,-46.7,11).curveTo(-37,7.4,-6,-4.8).curveTo(7.1,-10,30.6,-19.8).curveTo(58.2,-31.3,71.9,-37.3).curveTo(78.9,-40.4,107.9,-51.8).curveTo(137.5,-63.5,143.9,-66.3).curveTo(143.8,-65.6,143.3,-64.9).curveTo(143.1,-64.8,142.2,-63.8).curveTo(136.1,-57.7,132.8,-54.3).curveTo(126.9,-48.4,123.2,-45.2).curveTo(117.2,-40.1,100.2,-25.9).curveTo(85.1,-13.3,76.8,-6.6).lineTo(49.3,15.6).curveTo(24.4,35.6,11.9,45.5).curveTo(4,51.8,-0,54.8).curveTo(-6.7,59.9,-12.4,63.6).curveTo(-16.3,66.2,-19.3,67.3).curveTo(-24.4,69.2,-27.8,65.4).curveTo(-38.4,53.4,-43.1,48.2).curveTo(-50.9,39.5,-52.3,38.1).curveTo(-57.4,32.6,-62.2,28.6).curveTo(-63.7,27.4,-65.5,26.4).curveTo(-67.8,25.1,-69.8,25.2).curveTo(-72.1,25.3,-73.2,27.4).curveTo(-73.9,29.1,-76,32.3).curveTo(-78,35.2,-78.4,36.6).curveTo(-79,38,-80.5,40.4).curveTo(-81.9,42.4,-82.5,43.8).closePath().moveTo(-104.1,-6.8).lineTo(-117.5,-14.9).curveTo(-133.3,-24.6,-140.9,-30).curveTo(-143.7,-32,-144.2,-34).curveTo(-143.3,-34.7,-143.1,-34.9).curveTo(-142.4,-35.3,-141.7,-35.3).curveTo(-121,-36.6,-95.5,-38.8).curveTo(-44.5,-43,-20.9,-46.6).curveTo(-0.3,-49.8,122,-64.7).curveTo(126.5,-65.2,126.6,-65.2).curveTo(129.1,-65.1,130.8,-63.3).curveTo(124.5,-61.2,104.3,-56.4).curveTo(80.4,-50.6,77.8,-49.9).lineTo(-26.2,-22).curveTo(-48.1,-16.2,-52.8,-14.9).curveTo(-62.6,-12.2,-67.5,-10.8).curveTo(-76.1,-8.3,-82.1,-6.2).curveTo(-86.1,-5,-88.1,-4.1).curveTo(-91.7,-2.3,-92.7,1).curveTo(-93.6,4.2,-90,23.1).curveTo(-88.1,32.6,-86.1,41.4).curveTo(-85.4,43.8,-83.5,44.8).curveTo(-83,44.9,-82.7,44.2).curveTo(-82.6,44,-82.5,43.8);
	this.shape.setTransform(0.1459,-0.8005);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.planebyitself, new cjs.Rectangle(-146.9,-70.9,294.1,148.4), null);


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.moveTo(-35.5,25.5).lineTo(-35.5,-25.5).lineTo(35.5,-25.5).lineTo(35.5,25.5).closePath();
	mask.setTransform(35.55,25.5);

	// Layer_3
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,0.5).lineTo(-0.7,0.4).curveTo(-0.7,-0.4,0,-0.4).curveTo(0.7,-0.4,0.7,0.4).lineTo(0.7,0.5).closePath();
	this.shape.setTransform(17.625,25.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill("#FFFFFF").beginStroke().moveTo(0.2,17.2).lineTo(-31.2,-7.1).curveTo(-30.9,-6.9,-30.4,-6.8).curveTo(-29.3,-6.6,-28.6,-7.4).lineTo(-18.7,-17.6).curveTo(-17.3,-18.8,-15.6,-18.6).lineTo(31.2,-12.2).curveTo(29.9,-12.3,29.2,-11.2).lineTo(10.6,15.6).lineTo(10.4,15.9).curveTo(8.5,18.3,5.6,18.6).lineTo(4.5,18.7).curveTo(2.2,18.7,0.2,17.2).closePath().moveTo(14.8,-7.6).curveTo(14.3,-7,14.3,-6).lineTo(14.3,-4.9).curveTo(14.3,-3.9,14.9,-3.3).curveTo(15.5,-2.8,16.4,-2.8).curveTo(17.5,-2.8,18.2,-3.3).lineTo(17.9,-4.4).curveTo(17.2,-4,16.6,-4).curveTo(15.6,-4,15.6,-5).lineTo(15.6,-5.1).lineTo(18.4,-5.1).lineTo(18.4,-6.1).curveTo(18.4,-7,17.9,-7.6).curveTo(17.3,-8.2,16.3,-8.2).curveTo(15.4,-8.2,14.8,-7.6).closePath().moveTo(9.8,-3.3).curveTo(10.5,-2.8,11.7,-2.8).curveTo(12.6,-2.8,13.1,-3.3).curveTo(13.7,-3.8,13.7,-4.5).curveTo(13.7,-5.6,12.4,-6).lineTo(11.7,-6.3).curveTo(11.3,-6.4,11.3,-6.7).curveTo(11.3,-7,11.9,-7).curveTo(12.4,-7,13.1,-6.7).lineTo(13.7,-7.7).curveTo(12.9,-8.2,11.9,-8.2).curveTo(11,-8.2,10.4,-7.7).curveTo(9.9,-7.3,9.9,-6.6).curveTo(9.9,-5.4,11.2,-5).lineTo(11.8,-4.8).curveTo(12.3,-4.6,12.3,-4.4).curveTo(12.3,-4,11.7,-4).curveTo(10.9,-4,10.3,-4.4).closePath().moveTo(5.5,-5.6).curveTo(5.1,-5.2,5.1,-4.5).curveTo(5.1,-2.8,7.2,-2.8).curveTo(8,-2.8,9.2,-3.3).lineTo(9.2,-6.5).curveTo(9.2,-8.2,7.3,-8.2).curveTo(6.3,-8.2,5.4,-7.8).lineTo(5.5,-6.5).curveTo(6.2,-6.9,7,-6.9).curveTo(7.8,-6.9,7.8,-6.3).lineTo(7.8,-6.1).lineTo(6.9,-6.1).curveTo(6,-6.1,5.5,-5.6).closePath().moveTo(1,-7.6).curveTo(0.5,-7,0.5,-6).lineTo(0.5,-4.9).curveTo(0.5,-3.9,1.1,-3.3).curveTo(1.7,-2.8,2.6,-2.8).curveTo(3.7,-2.8,4.5,-3.3).lineTo(4.1,-4.4).curveTo(3.5,-4,2.8,-4).curveTo(1.9,-4,1.9,-5).lineTo(1.9,-5.1).lineTo(4.6,-5.1).lineTo(4.6,-6.1).curveTo(4.6,-7,4.1,-7.6).curveTo(3.5,-8.2,2.6,-8.2).curveTo(1.6,-8.2,1,-7.6).closePath().moveTo(-2.1,-4.1).curveTo(-2.1,-2.8,-0.8,-2.8).curveTo(-0.4,-2.8,0.2,-3).lineTo(0.1,-4.1).lineTo(-0.4,-4).curveTo(-0.8,-4,-0.8,-4.5).lineTo(-0.8,-10).lineTo(-2.1,-10).closePath().moveTo(-6.7,-7.7).curveTo(-7.2,-7.2,-7.2,-6.4).lineTo(-7.2,-4.7).curveTo(-7.2,-3.9,-6.7,-3.4).curveTo(-6.1,-2.8,-5.1,-2.8).curveTo(-4.3,-2.8,-3,-3.3).lineTo(-3,-10).lineTo(-4.4,-10).lineTo(-4.4,-8).lineTo(-5.3,-8.2).curveTo(-6.2,-8.2,-6.7,-7.7).closePath().moveTo(-16.4,-7.6).curveTo(-17,-7,-17,-6).lineTo(-17,-4.9).curveTo(-17,-3.9,-16.3,-3.3).curveTo(-15.7,-2.8,-14.8,-2.8).curveTo(-13.8,-2.8,-13,-3.3).lineTo(-13.4,-4.4).curveTo(-14,-4,-14.7,-4).curveTo(-15.6,-4,-15.6,-5).lineTo(-15.6,-5.1).lineTo(-12.9,-5.1).lineTo(-12.9,-6.1).curveTo(-12.9,-7,-13.4,-7.6).curveTo(-13.9,-8.2,-14.9,-8.2).curveTo(-15.9,-8.2,-16.4,-7.6).closePath().moveTo(-19.6,-4.1).curveTo(-19.6,-2.8,-18.3,-2.8).curveTo(-17.8,-2.8,-17.2,-3).lineTo(-17.4,-4.1).lineTo(-17.8,-4).curveTo(-18.2,-4,-18.2,-4.5).lineTo(-18.2,-10).lineTo(-19.6,-10).closePath().moveTo(-9.4,-6.1).lineTo(-9.4,-2.9).lineTo(-8,-2.9).lineTo(-8,-6.5).curveTo(-8,-8.2,-10,-8.2).curveTo(-10.9,-8.2,-12.2,-7.7).lineTo(-12.2,-2.9).lineTo(-10.8,-2.9).lineTo(-10.8,-6.8).curveTo(-10.5,-7,-10.2,-7).curveTo(-9.4,-7,-9.4,-6.1).closePath();
	this.shape_1.setTransform(32.5125,32.3468);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,0.5).lineTo(-0.7,0.4).curveTo(-0.7,-0.4,0,-0.4).curveTo(0.7,-0.4,0.7,0.4).lineTo(0.7,0.5).closePath();
	this.shape_2.setTransform(48.85,25.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,0).curveTo(-0.7,-0.6,-0,-0.5).lineTo(0.7,-0.5).lineTo(0.7,0.5).lineTo(0.1,0.6).curveTo(-0.7,0.5,-0.7,0).closePath();
	this.shape_3.setTransform(39.675,27.8);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,0.5).lineTo(-0.7,0.4).curveTo(-0.7,-0.4,0,-0.4).curveTo(0.7,-0.4,0.7,0.4).lineTo(0.7,0.5).closePath();
	this.shape_4.setTransform(35.075,25.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-0.7,0.6).lineTo(-0.7,-0.6).curveTo(-0.7,-1.5,0.1,-1.5).lineTo(0.7,-1.3).lineTo(0.7,1.4).lineTo(0.2,1.5).curveTo(-0.7,1.5,-0.7,0.6).closePath();
	this.shape_5.setTransform(27.425,26.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-12.1,12.4).curveTo(-13,12.3,-13.5,11.6).curveTo(-14.1,10.8,-13.9,10).lineTo(-10.8,-10.4).curveTo(-10.6,-11.6,-11.3,-12.5).lineTo(14,2.1).lineTo(2.7,0.6).curveTo(0.9,0.3,-0.4,1.6).lineTo(-10.3,11.8).curveTo(-10.9,12.5,-11.8,12.5).lineTo(-12.1,12.4).closePath();
	this.shape_6.setTransform(13.9839,12.4618);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill("#FFFFFF").beginStroke().moveTo(-12.1,12.4).curveTo(-13,12.3,-13.5,11.6).curveTo(-14.1,10.8,-13.9,10).lineTo(-10.8,-10.4).curveTo(-10.6,-11.6,-11.3,-12.5).lineTo(14,2.1).lineTo(2.7,0.6).curveTo(0.9,0.3,-0.4,1.6).lineTo(-10.3,11.8).curveTo(-10.9,12.5,-11.8,12.5).lineTo(-12.1,12.4).closePath();
	this.shape_7.setTransform(13.9839,12.4618);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1,-7.5).curveTo(1.6,-8.2,2.4,-8.3).curveTo(3.3,-8.5,4,-8).curveTo(4.5,-7.7,4.8,-7.1).lineTo(8.5,1.5).curveTo(8.9,2.5,9.9,3).lineTo(-9.9,8.3).closePath();
	this.shape_8.setTransform(61.225,28.9077);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill("#FFFFFF").beginStroke().moveTo(1,-7.5).curveTo(1.6,-8.2,2.4,-8.3).curveTo(3.3,-8.5,4,-8).curveTo(4.5,-7.7,4.8,-7.1).lineTo(8.5,1.5).curveTo(8.9,2.5,9.9,3).lineTo(-9.9,8.3).closePath();
	this.shape_9.setTransform(61.225,28.9077);

	var maskedShapeInstanceList = [this.shape,this.shape_1,this.shape_2,this.shape_3,this.shape_4,this.shape_5,this.shape_6,this.shape_7,this.shape_8,this.shape_9];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.ClipGroup, new cjs.Rectangle(0,0,71.1,51), null);


(lib.Plane = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_17
	this.instance = new lib.planebyitself();
	this.instance.parent = this;
	this.instance.setTransform(-409.6,214.85,1,1,0,0,0,0.1,3.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Plane, new cjs.Rectangle(-556.6,140.8,294.1,148.3), null);


(lib.LEndlease = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(0.05,0.15,1.4501,1.4501,0,0,0,35.6,25.6);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.LEndlease, new cjs.Rectangle(-51.5,-36.9,103.1,73.9), null);


// stage content:
(lib.FHSkyscraper120x600 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{lineout:72,"lineout":170,"lineout":268});

	// trace_idn
	this.shape = new cjs.Shape();
	this.shape.graphics.beginFill().beginStroke("#FFFFFF").moveTo(20.3,-3.5).curveTo(19.9,-3.4,19.3,-3.3).curveTo(18.8,-3.2,18.1,-3.1).curveTo(17.8,-3,17.5,-3).curveTo(14.9,-2.5,13.7,-2.3).curveTo(10.1,-1.6,8.3,-1.3).curveTo(4.1,-0.6,1.9,-0.3).curveTo(-1.9,0.4,-3.7,0.7).curveTo(-7.7,1.3,-9.6,1.6).curveTo(-13.5,2.3,-15.4,2.7).curveTo(-17.2,2.9,-20.8,3.5);
	this.shape.setTransform(-20.0917,144.4215);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.beginFill().beginStroke("#FFFFFF").moveTo(21.6,-3.7).curveTo(21.4,-3.7,21.2,-3.7).curveTo(19.7,-3.3,16.8,-2.8).curveTo(16.6,-2.8,16.3,-2.7).curveTo(13.6,-2.2,12.5,-2).curveTo(8.8,-1.4,7.1,-1).curveTo(2.8,-0.4,0.7,-0).curveTo(-3.2,0.7,-5,0.9).curveTo(-8.9,1.5,-10.8,1.9).curveTo(-14.8,2.6,-16.7,2.9).curveTo(-18.5,3.1,-22,3.7);
	this.shape_1.setTransform(-18.8417,144.1715);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.beginFill().beginStroke("#FFFFFF").moveTo(23.5,-4.1).curveTo(21.4,-3.7,19.4,-3.3).curveTo(17.8,-3,15,-2.5).curveTo(14.7,-2.4,14.4,-2.4).curveTo(11.8,-1.9,10.6,-1.7).curveTo(7,-1,5.2,-0.7).curveTo(1,-0,-1.2,0.3).curveTo(-5,1,-6.8,1.3).curveTo(-10.8,1.9,-12.7,2.2).curveTo(-16.6,2.9,-18.5,3.3).curveTo(-20.3,3.5,-23.9,4.1);
	this.shape_2.setTransform(-16.9667,143.8259);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.beginFill().beginStroke("#FFFFFF").moveTo(25.2,-4.4).curveTo(21.4,-3.6,17.6,-3).curveTo(16.1,-2.6,13.2,-2.1).curveTo(13,-2.1,12.7,-2).curveTo(10,-1.5,8.9,-1.3).curveTo(5.2,-0.7,3.5,-0.3).curveTo(-0.8,0.3,-2.9,0.7).curveTo(-6.8,1.4,-8.6,1.6).curveTo(-12.5,2.2,-14.4,2.6).curveTo(-18.4,3.3,-20.3,3.6).curveTo(-22.1,3.8,-25.6,4.4);
	this.shape_3.setTransform(-15.2167,143.4766);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.beginFill().beginStroke("#FFFFFF").moveTo(27.1,-4.8).curveTo(26,-4.6,24.8,-4.3).curveTo(20.3,-3.4,15.7,-2.6).curveTo(14.2,-2.2,11.3,-1.7).curveTo(11.1,-1.7,10.8,-1.6).curveTo(8.1,-1.1,7,-0.9).curveTo(3.3,-0.3,1.6,0.1).curveTo(-2.7,0.7,-4.8,1.1).curveTo(-8.7,1.8,-10.5,2).curveTo(-14.4,2.6,-16.3,3).curveTo(-20.3,3.7,-22.2,4).curveTo(-24,4.2,-27.5,4.8);
	this.shape_4.setTransform(-13.3417,143.0965);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.beginFill().beginStroke("#FFFFFF").moveTo(29.2,-5.2).curveTo(26.2,-4.6,22.6,-3.9).curveTo(18.1,-3,13.6,-2.2).curveTo(12,-1.8,9.2,-1.3).curveTo(8.9,-1.3,8.6,-1.2).curveTo(6,-0.7,4.8,-0.5).curveTo(1.2,0.1,-0.6,0.5).curveTo(-4.8,1.1,-7,1.5).curveTo(-10.8,2.2,-12.6,2.4).curveTo(-16.6,3,-18.5,3.4).curveTo(-22.4,4.1,-24.3,4.4).curveTo(-26.1,4.6,-29.7,5.2);
	this.shape_5.setTransform(-11.1917,142.6715);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.beginFill().beginStroke("#FFFFFF").moveTo(31,-5.6).curveTo(26.5,-4.6,20.9,-3.5).curveTo(16.4,-2.6,11.8,-1.8).curveTo(10.3,-1.4,7.4,-0.9).curveTo(7.2,-0.9,6.9,-0.8).curveTo(4.2,-0.3,3.1,-0.1).curveTo(-0.6,0.5,-2.3,0.9).curveTo(-6.6,1.5,-8.7,1.9).curveTo(-12.6,2.6,-14.4,2.8).curveTo(-18.3,3.4,-20.2,3.8).curveTo(-24.2,4.5,-26.1,4.8).curveTo(-27.9,5,-31.4,5.6);
	this.shape_6.setTransform(-9.4167,142.2965);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.beginFill().beginStroke("#FFFFFF").moveTo(32.8,-6).curveTo(27.1,-4.7,19.4,-3.1).curveTo(14.9,-2.2,10.4,-1.4).curveTo(8.8,-1,6,-0.5).curveTo(5.7,-0.5,5.4,-0.4).curveTo(2.8,0.1,1.6,0.3).curveTo(-2,0.9,-3.8,1.3).curveTo(-8,1.9,-10.2,2.3).curveTo(-14,3,-15.8,3.2).curveTo(-19.8,3.8,-21.7,4.2).curveTo(-25.6,4.9,-27.5,5.2).curveTo(-29.3,5.4,-32.9,6);
	this.shape_7.setTransform(-7.9861,141.8965);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.beginFill().beginStroke("#FFFFFF").moveTo(34.8,-6.5).curveTo(33.9,-6.3,33,-6.1).curveTo(26.7,-4.6,17.1,-2.7).curveTo(12.6,-1.7,8.1,-0.9).curveTo(6.5,-0.6,3.7,-0.1).curveTo(3.4,-0,3.1,0).curveTo(0.5,0.5,-0.7,0.7).curveTo(-4.3,1.4,-6.1,1.7).curveTo(-10.3,2.4,-12.5,2.7).curveTo(-16.3,3.4,-18.1,3.7).curveTo(-22.1,4.3,-24,4.6).curveTo(-27.9,5.3,-29.8,5.7).curveTo(-31.6,5.9,-35.2,6.5);
	this.shape_8.setTransform(-5.6667,141.4067);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.beginFill().beginStroke("#FFFFFF").moveTo(36.8,-7).curveTo(34,-6.3,31,-5.5).curveTo(24.6,-4,15.1,-2.1).curveTo(10.6,-1.2,6,-0.4).curveTo(4.5,-0,1.6,0.5).curveTo(1.4,0.5,1.1,0.6).curveTo(-1.6,1.1,-2.7,1.3).curveTo(-6.4,1.9,-8.1,2.3).curveTo(-12.4,2.9,-14.5,3.3).curveTo(-18.4,4,-20.2,4.2).curveTo(-24.1,4.8,-26,5.2).curveTo(-30,5.9,-31.9,6.2).curveTo(-33.7,6.4,-37.2,7);
	this.shape_9.setTransform(-3.6167,140.8715);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.beginFill().beginStroke("#FFFFFF").moveTo(38.4,-7.4).curveTo(34.3,-6.3,29.4,-5.1).curveTo(23,-3.6,13.5,-1.7).curveTo(9,-0.7,4.4,0.1).curveTo(2.9,0.4,0,0.9).curveTo(-0.2,1,-0.5,1).curveTo(-3.2,1.5,-4.3,1.7).curveTo(-8,2.4,-9.7,2.7).curveTo(-14,3.4,-16.1,3.7).curveTo(-20,4.4,-21.8,4.7).curveTo(-25.7,5.3,-27.6,5.6).curveTo(-31.6,6.3,-33.5,6.7).curveTo(-35.3,6.9,-38.8,7.5);
	this.shape_10.setTransform(-2.0167,140.4465);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.beginFill().beginStroke("#FFFFFF").moveTo(42.1,-8.5).curveTo(40.7,-8.1,39.2,-7.6).curveTo(33.3,-5.8,25.7,-4).curveTo(19.3,-2.5,9.8,-0.6).curveTo(5.3,0.4,0.7,1.2).curveTo(-0.8,1.5,-3.7,2).curveTo(-3.9,2.1,-4.2,2.1).curveTo(-6.9,2.6,-8,2.8).curveTo(-11.7,3.5,-13.4,3.8).curveTo(-17.7,4.5,-19.8,4.8).curveTo(-23.7,5.5,-25.5,5.8).curveTo(-29.4,6.4,-31.3,6.7).curveTo(-35.3,7.4,-37.2,7.8).curveTo(-39,8,-42.5,8.6);
	this.shape_11.setTransform(1.6833,139.3465);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.beginFill().beginStroke("#FFFFFF").moveTo(44.3,-9.4).curveTo(41.2,-8.1,37,-6.8).curveTo(31.1,-5,23.4,-3.2).curveTo(17.1,-1.7,7.5,0.2).curveTo(3,1.2,-1.5,2).curveTo(-3.1,2.3,-5.9,2.8).curveTo(-6.2,2.9,-6.5,2.9).curveTo(-9.1,3.4,-10.3,3.6).curveTo(-13.9,4.3,-15.7,4.6).curveTo(-19.9,5.3,-22.1,5.6).curveTo(-25.9,6.3,-27.7,6.6).curveTo(-31.7,7.2,-33.6,7.5).curveTo(-37.5,8.2,-39.4,8.6).curveTo(-41.2,8.8,-44.8,9.4);
	this.shape_12.setTransform(3.9083,138.5215);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.beginFill().beginStroke("#FFFFFF").moveTo(46.3,-10.4).curveTo(45.7,-10,45,-9.7).curveTo(41.2,-7.8,35,-5.9).curveTo(29.1,-4.1,21.4,-2.3).curveTo(15.1,-0.8,5.5,1.1).curveTo(1,2.1,-3.5,2.9).curveTo(-5.1,3.2,-7.9,3.7).curveTo(-8.2,3.8,-8.5,3.8).curveTo(-11.1,4.3,-12.3,4.5).curveTo(-15.9,5.2,-17.7,5.5).curveTo(-21.9,6.2,-24.1,6.5).curveTo(-27.9,7.2,-29.7,7.5).curveTo(-33.7,8.1,-35.6,8.4).curveTo(-39.5,9.1,-41.4,9.5).curveTo(-43.2,9.7,-46.8,10.3);
	this.shape_13.setTransform(5.9083,137.6056);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.beginFill().beginStroke("#FFFFFF").moveTo(47.2,-10.8).curveTo(46,-10,44.2,-9.1).curveTo(40.3,-7.2,34.1,-5.3).curveTo(28.2,-3.5,20.6,-1.7).curveTo(14.2,-0.2,4.7,1.7).curveTo(0.2,2.7,-4.4,3.5).curveTo(-5.9,3.8,-8.8,4.3).curveTo(-9,4.4,-9.3,4.4).curveTo(-12,4.9,-13.1,5.1).curveTo(-16.8,5.8,-18.5,6.1).curveTo(-22.8,6.8,-24.9,7.1).curveTo(-28.8,7.8,-30.6,8.1).curveTo(-34.5,8.7,-36.4,9).curveTo(-40.4,9.7,-42.3,10.1).curveTo(-44.1,10.3,-47.6,10.9);
	this.shape_14.setTransform(6.7583,137.0465);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.beginFill().beginStroke("#FFFFFF").moveTo(49,-12.9).curveTo(48.7,-12,48,-11.1).curveTo(46.9,-9.8,45.4,-8.8).curveTo(44.2,-8,42.4,-7.1).curveTo(38.5,-5.2,32.3,-3.3).curveTo(26.4,-1.5,18.8,0.3).curveTo(12.4,1.8,2.9,3.7).curveTo(-1.6,4.7,-6.2,5.5).curveTo(-7.7,5.8,-10.6,6.3).curveTo(-10.8,6.4,-11.1,6.4).curveTo(-13.8,6.9,-14.9,7.1).curveTo(-18.6,7.8,-20.3,8.1).curveTo(-24.6,8.8,-26.7,9.1).curveTo(-30.6,9.8,-32.4,10.1).curveTo(-36.3,10.7,-38.2,11).curveTo(-42.2,11.7,-44.1,12.1).curveTo(-45.9,12.3,-49.4,12.9);
	this.shape_15.setTransform(8.5833,135.0215);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.beginFill().beginStroke("#FFFFFF").moveTo(49.2,-13.5).curveTo(49.1,-12,47.8,-10.4).curveTo(46.7,-9.2,45.2,-8.2).curveTo(44,-7.4,42.2,-6.5).curveTo(38.3,-4.6,32.1,-2.7).curveTo(26.2,-0.9,18.6,1).curveTo(12.2,2.5,2.7,4.4).curveTo(-1.8,5.3,-6.4,6.1).curveTo(-7.9,6.5,-10.8,7).curveTo(-11,7,-11.3,7.1).curveTo(-14,7.6,-15.1,7.8).curveTo(-18.8,8.4,-20.5,8.8).curveTo(-24.8,9.4,-26.9,9.8).curveTo(-30.8,10.5,-32.6,10.7).curveTo(-36.5,11.3,-38.4,11.7).curveTo(-42.4,12.4,-44.3,12.7).curveTo(-46.1,12.9,-49.6,13.5);
	this.shape_16.setTransform(8.7583,134.3715);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.beginFill().beginStroke("#FFFFFF").moveTo(47.4,-15.9).curveTo(48.3,-14.8,48.7,-13.8).curveTo(50,-10.8,47.9,-8.2).curveTo(46.8,-7,45.2,-6).curveTo(44.1,-5.2,42.2,-4.3).curveTo(38.4,-2.4,32.2,-0.5).curveTo(26.3,1.3,18.6,3.2).curveTo(12.3,4.7,2.7,6.6).curveTo(-1.8,7.5,-6.3,8.3).curveTo(-7.9,8.7,-10.7,9.2).curveTo(-11,9.2,-11.3,9.3).curveTo(-13.9,9.8,-15.1,10).curveTo(-18.7,10.6,-20.5,11).curveTo(-24.7,11.6,-26.9,12).curveTo(-30.7,12.7,-32.5,12.9).curveTo(-36.5,13.5,-38.4,13.9).curveTo(-42.3,14.6,-44.2,14.9).curveTo(-46,15.1,-49.6,15.7);
	this.shape_17.setTransform(8.7415,132.1729);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.beginFill().beginStroke("#FFFFFF").moveTo(44.4,-17.4).curveTo(45,-16.8,45.6,-16.3).curveTo(47.8,-14.1,48.7,-12.2).curveTo(50,-9.3,47.9,-6.7).curveTo(46.8,-5.4,45.2,-4.4).curveTo(44.1,-3.6,42.2,-2.7).curveTo(38.4,-0.8,32.2,1.1).curveTo(26.3,2.9,18.6,4.7).curveTo(12.3,6.2,2.7,8.1).curveTo(-1.8,9.1,-6.3,9.9).curveTo(-7.9,10.2,-10.7,10.7).curveTo(-11,10.8,-11.3,10.8).curveTo(-13.9,11.3,-15.1,11.5).curveTo(-18.7,12.2,-20.5,12.5).curveTo(-24.7,13.2,-26.9,13.5).curveTo(-30.7,14.2,-32.5,14.5).curveTo(-36.5,15.1,-38.4,15.4).curveTo(-42.3,16.1,-44.2,16.5).curveTo(-46,16.7,-49.6,17.3);
	this.shape_18.setTransform(8.7415,130.6447);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.beginFill().beginStroke("#FFFFFF").moveTo(42.5,-18.1).curveTo(44.3,-16.7,45.6,-15.5).curveTo(47.8,-13.4,48.7,-11.5).curveTo(50,-8.5,47.9,-5.9).curveTo(46.8,-4.7,45.2,-3.7).curveTo(44.1,-2.9,42.2,-2).curveTo(38.4,-0.1,32.2,1.8).curveTo(26.3,3.6,18.6,5.5).curveTo(12.3,7,2.7,8.9).curveTo(-1.8,9.8,-6.3,10.6).curveTo(-7.9,11,-10.7,11.5).curveTo(-11,11.5,-11.3,11.6).curveTo(-13.9,12.1,-15.1,12.3).curveTo(-18.7,12.9,-20.5,13.3).curveTo(-24.7,13.9,-26.9,14.3).curveTo(-30.7,15,-32.5,15.2).curveTo(-36.5,15.8,-38.4,16.2).curveTo(-42.3,16.9,-44.2,17.2).curveTo(-46,17.4,-49.6,18);
	this.shape_19.setTransform(8.7415,129.8742);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.beginFill().beginStroke("#FFFFFF").moveTo(38.9,-19.3).curveTo(39,-19.2,39.1,-19.1).curveTo(41.3,-17.7,42.5,-16.8).curveTo(44.3,-15.4,45.6,-14.2).curveTo(47.8,-12.1,48.7,-10.2).curveTo(50,-7.2,47.9,-4.6).curveTo(46.8,-3.4,45.2,-2.4).curveTo(44.1,-1.6,42.2,-0.7).curveTo(38.4,1.2,32.2,3.1).curveTo(26.3,4.9,18.6,6.8).curveTo(12.3,8.3,2.7,10.2).curveTo(-1.8,11.1,-6.3,11.9).curveTo(-7.9,12.3,-10.7,12.8).curveTo(-11,12.8,-11.3,12.9).curveTo(-13.9,13.4,-15.1,13.6).curveTo(-18.7,14.2,-20.5,14.6).curveTo(-24.7,15.2,-26.9,15.6).curveTo(-30.7,16.3,-32.5,16.5).curveTo(-36.5,17.1,-38.4,17.5).curveTo(-42.3,18.2,-44.2,18.5).curveTo(-46,18.7,-49.6,19.3);
	this.shape_20.setTransform(8.7415,128.5715);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.beginFill().beginStroke("#FFFFFF").moveTo(36,-20.3).curveTo(37.4,-19.4,39.1,-18.2).curveTo(41.3,-16.8,42.5,-15.9).curveTo(44.3,-14.5,45.6,-13.3).curveTo(47.8,-11.1,48.7,-9.2).curveTo(50,-6.3,47.9,-3.7).curveTo(46.8,-2.4,45.2,-1.4).curveTo(44.1,-0.6,42.2,0.3).curveTo(38.4,2.2,32.2,4.1).curveTo(26.3,5.9,18.6,7.7).curveTo(12.3,9.2,2.7,11.1).curveTo(-1.8,12.1,-6.3,12.9).curveTo(-7.9,13.2,-10.7,13.7).curveTo(-11,13.8,-11.3,13.8).curveTo(-13.9,14.3,-15.1,14.5).curveTo(-18.7,15.2,-20.5,15.5).curveTo(-24.7,16.2,-26.9,16.5).curveTo(-30.7,17.2,-32.5,17.5).curveTo(-36.5,18.1,-38.4,18.4).curveTo(-42.3,19.1,-44.2,19.5).curveTo(-46,19.7,-49.6,20.3);
	this.shape_21.setTransform(8.7415,127.6215);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.beginFill().beginStroke("#FFFFFF").moveTo(35.6,-20.4).curveTo(37.1,-19.4,39.1,-18).curveTo(41.3,-16.6,42.5,-15.7).curveTo(44.3,-14.3,45.6,-13.1).curveTo(47.8,-11,48.7,-9.1).curveTo(50,-6.1,47.9,-3.5).curveTo(46.8,-2.3,45.2,-1.3).curveTo(44.1,-0.5,42.2,0.4).curveTo(38.4,2.3,32.2,4.2).curveTo(26.3,6,18.6,7.9).curveTo(12.3,9.4,2.7,11.3).curveTo(-1.8,12.2,-6.3,13).curveTo(-7.9,13.4,-10.7,13.9).curveTo(-11,13.9,-11.3,14).curveTo(-13.9,14.5,-15.1,14.7).curveTo(-18.7,15.3,-20.5,15.7).curveTo(-24.7,16.3,-26.9,16.7).curveTo(-30.7,17.4,-32.5,17.6).curveTo(-36.5,18.2,-38.4,18.6).curveTo(-42.3,19.3,-44.2,19.6).curveTo(-46,19.8,-49.6,20.4);
	this.shape_22.setTransform(8.7415,127.4965);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.beginFill().beginStroke("#FFFFFF").moveTo(30.8,-22).curveTo(32.1,-21.1,33.7,-20).curveTo(35.5,-18.8,39.1,-16.4).curveTo(41.3,-15,42.5,-14.1).curveTo(44.3,-12.7,45.6,-11.5).curveTo(47.8,-9.4,48.7,-7.5).curveTo(50,-4.5,47.9,-1.9).curveTo(46.8,-0.7,45.2,0.3).curveTo(44.1,1.1,42.2,2).curveTo(38.4,3.9,32.2,5.8).curveTo(26.3,7.6,18.6,9.5).curveTo(12.3,11,2.7,12.9).curveTo(-1.8,13.8,-6.3,14.6).curveTo(-7.9,15,-10.7,15.5).curveTo(-11,15.5,-11.3,15.6).curveTo(-13.9,16.1,-15.1,16.3).curveTo(-18.7,16.9,-20.5,17.3).curveTo(-24.7,17.9,-26.9,18.3).curveTo(-30.7,19,-32.5,19.2).curveTo(-36.5,19.8,-38.4,20.2).curveTo(-42.3,20.9,-44.2,21.2).curveTo(-46,21.4,-49.6,22);
	this.shape_23.setTransform(8.7415,125.8965);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.beginFill().beginStroke("#FFFFFF").moveTo(26.4,-23.9).curveTo(27.1,-22.9,28.3,-22).curveTo(28.6,-21.8,28.9,-21.6).curveTo(30.8,-20.1,33.7,-18.2).curveTo(35.5,-17,39.1,-14.6).curveTo(41.3,-13.2,42.5,-12.3).curveTo(44.3,-10.9,45.6,-9.7).curveTo(47.8,-7.5,48.7,-5.6).curveTo(50,-2.7,47.9,-0.1).curveTo(46.8,1.2,45.2,2.2).curveTo(44.1,3,42.2,3.9).curveTo(38.4,5.8,32.2,7.7).curveTo(26.3,9.5,18.6,11.3).curveTo(12.3,12.8,2.7,14.7).curveTo(-1.8,15.7,-6.3,16.5).curveTo(-7.9,16.8,-10.7,17.3).curveTo(-11,17.4,-11.3,17.4).curveTo(-13.9,17.9,-15.1,18.1).curveTo(-18.7,18.8,-20.5,19.1).curveTo(-24.7,19.8,-26.9,20.1).curveTo(-30.7,20.8,-32.5,21.1).curveTo(-36.5,21.7,-38.4,22).curveTo(-42.3,22.7,-44.2,23.1).curveTo(-46,23.3,-49.6,23.9);
	this.shape_24.setTransform(8.7415,124.0215);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.beginFill().beginStroke("#FFFFFF").moveTo(26,-24.1).curveTo(26.8,-23,28.3,-21.7).curveTo(30.4,-20,33.7,-17.9).curveTo(35.5,-16.7,39.1,-14.3).curveTo(41.3,-12.9,42.5,-12).curveTo(44.3,-10.6,45.6,-9.4).curveTo(47.8,-7.3,48.7,-5.4).curveTo(50,-2.4,47.9,0.2).curveTo(46.8,1.4,45.2,2.4).curveTo(44.1,3.2,42.2,4.1).curveTo(38.4,6,32.2,7.9).curveTo(26.3,9.7,18.6,11.6).curveTo(12.3,13.1,2.7,15).curveTo(-1.8,15.9,-6.3,16.7).curveTo(-7.9,17.1,-10.7,17.6).curveTo(-11,17.6,-11.3,17.7).curveTo(-13.9,18.2,-15.1,18.4).curveTo(-18.7,19,-20.5,19.4).curveTo(-24.7,20,-26.9,20.4).curveTo(-30.7,21.1,-32.5,21.3).curveTo(-36.5,21.9,-38.4,22.3).curveTo(-42.3,23,-44.2,23.3).curveTo(-46,23.5,-49.6,24.1);
	this.shape_25.setTransform(8.7415,123.7715);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.beginFill().beginStroke("#FFFFFF").moveTo(24.7,-25.9).curveTo(24.5,-24.8,25.3,-23.3).curveTo(26.2,-21.6,28.3,-19.9).curveTo(30.4,-18.2,33.7,-16.1).curveTo(35.5,-14.9,39.1,-12.5).curveTo(41.3,-11.1,42.5,-10.2).curveTo(44.3,-8.8,45.6,-7.6).curveTo(47.8,-5.4,48.7,-3.5).curveTo(50,-0.6,47.9,2).curveTo(46.8,3.3,45.2,4.3).curveTo(44.1,5.1,42.2,6).curveTo(38.4,7.9,32.2,9.8).curveTo(26.3,11.6,18.6,13.4).curveTo(12.3,14.9,2.7,16.8).curveTo(-1.8,17.8,-6.3,18.6).curveTo(-7.9,18.9,-10.7,19.4).curveTo(-11,19.5,-11.3,19.5).curveTo(-13.9,20,-15.1,20.2).curveTo(-18.7,20.9,-20.5,21.2).curveTo(-24.7,21.9,-26.9,22.2).curveTo(-30.7,22.9,-32.5,23.2).curveTo(-36.5,23.8,-38.4,24.1).curveTo(-42.3,24.8,-44.2,25.2).curveTo(-46,25.4,-49.6,26);
	this.shape_26.setTransform(8.7415,121.9465);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.beginFill().beginStroke("#FFFFFF").moveTo(25.9,-27).curveTo(23.8,-25,25.3,-22.2).curveTo(26.2,-20.5,28.3,-18.8).curveTo(30.4,-17.1,33.7,-15).curveTo(35.5,-13.8,39.1,-11.4).curveTo(41.3,-10,42.5,-9.1).curveTo(44.3,-7.7,45.6,-6.5).curveTo(47.8,-4.3,48.7,-2.4).curveTo(50,0.5,47.9,3.1).curveTo(46.8,4.4,45.2,5.4).curveTo(44.1,6.2,42.2,7.1).curveTo(38.4,9,32.2,10.9).curveTo(26.3,12.7,18.6,14.5).curveTo(12.3,16,2.7,17.9).curveTo(-1.8,18.9,-6.3,19.7).curveTo(-7.9,20,-10.7,20.5).curveTo(-11,20.6,-11.3,20.6).curveTo(-13.9,21.1,-15.1,21.3).curveTo(-18.7,22,-20.5,22.3).curveTo(-24.7,23,-26.9,23.3).curveTo(-30.7,24,-32.5,24.3).curveTo(-36.5,24.9,-38.4,25.2).curveTo(-42.3,25.9,-44.2,26.3).curveTo(-46,26.5,-49.6,27.1);
	this.shape_27.setTransform(8.7415,120.8465);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.beginFill().beginStroke("#FFFFFF").moveTo(27.7,-27.7).curveTo(26.7,-27.1,25.9,-26.4).curveTo(23.8,-24.3,25.3,-21.6).curveTo(26.2,-19.9,28.3,-18.1).curveTo(30.4,-16.4,33.7,-14.3).curveTo(35.5,-13.1,39.1,-10.7).curveTo(41.3,-9.3,42.5,-8.4).curveTo(44.3,-7,45.6,-5.8).curveTo(47.8,-3.7,48.7,-1.8).curveTo(50,1.2,47.9,3.8).curveTo(46.8,5,45.2,6).curveTo(44.1,6.8,42.2,7.7).curveTo(38.4,9.6,32.2,11.5).curveTo(26.3,13.3,18.6,15.2).curveTo(12.3,16.7,2.7,18.6).curveTo(-1.8,19.5,-6.3,20.3).curveTo(-7.9,20.7,-10.7,21.2).curveTo(-11,21.2,-11.3,21.3).curveTo(-13.9,21.8,-15.1,22).curveTo(-18.7,22.6,-20.5,23).curveTo(-24.7,23.6,-26.9,24).curveTo(-30.7,24.7,-32.5,24.9).curveTo(-36.5,25.5,-38.4,25.9).curveTo(-42.3,26.6,-44.2,26.9).curveTo(-46,27.1,-49.6,27.7);
	this.shape_28.setTransform(8.7415,120.1965);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.beginFill().beginStroke("#FFFFFF").moveTo(32,-28.4).curveTo(30.9,-28.2,30.1,-27.9).curveTo(27.4,-27,25.9,-25.6).curveTo(23.8,-23.6,25.3,-20.8).curveTo(26.2,-19.1,28.3,-17.4).curveTo(30.4,-15.7,33.7,-13.6).curveTo(35.5,-12.4,39.1,-10).curveTo(41.3,-8.6,42.5,-7.7).curveTo(44.3,-6.3,45.6,-5.1).curveTo(47.8,-2.9,48.7,-1).curveTo(50,1.9,47.9,4.5).curveTo(46.8,5.8,45.2,6.8).curveTo(44.1,7.6,42.2,8.5).curveTo(38.4,10.4,32.2,12.3).curveTo(26.3,14.1,18.6,15.9).curveTo(12.3,17.4,2.7,19.3).curveTo(-1.8,20.3,-6.3,21.1).curveTo(-7.9,21.4,-10.7,21.9).curveTo(-11,22,-11.3,22).curveTo(-13.9,22.5,-15.1,22.7).curveTo(-18.7,23.4,-20.5,23.7).curveTo(-24.7,24.4,-26.9,24.7).curveTo(-30.7,25.4,-32.5,25.7).curveTo(-36.5,26.3,-38.4,26.6).curveTo(-42.3,27.3,-44.2,27.7).curveTo(-46,27.9,-49.6,28.5);
	this.shape_29.setTransform(8.7415,119.4465);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.beginFill().beginStroke("#FFFFFF").moveTo(35.3,-28.8).curveTo(32,-28.3,30.1,-27.6).curveTo(27.4,-26.7,25.9,-25.3).curveTo(23.8,-23.2,25.3,-20.5).curveTo(26.2,-18.8,28.3,-17).curveTo(30.4,-15.3,33.7,-13.2).curveTo(35.5,-12,39.1,-9.6).curveTo(41.3,-8.2,42.5,-7.3).curveTo(44.3,-5.9,45.6,-4.7).curveTo(47.8,-2.6,48.7,-0.7).curveTo(50,2.3,47.9,4.9).curveTo(46.8,6.1,45.2,7.1).curveTo(44.1,7.9,42.2,8.8).curveTo(38.4,10.7,32.2,12.6).curveTo(26.3,14.4,18.6,16.3).curveTo(12.3,17.8,2.7,19.7).curveTo(-1.8,20.6,-6.3,21.4).curveTo(-7.9,21.8,-10.7,22.3).curveTo(-11,22.3,-11.3,22.4).curveTo(-13.9,22.9,-15.1,23.1).curveTo(-18.7,23.7,-20.5,24.1).curveTo(-24.7,24.7,-26.9,25.1).curveTo(-30.7,25.8,-32.5,26).curveTo(-36.5,26.6,-38.4,27).curveTo(-42.3,27.7,-44.2,28).curveTo(-46,28.2,-49.6,28.8);
	this.shape_30.setTransform(8.7415,119.0715);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.beginFill().beginStroke("#FFFFFF").moveTo(39.2,-29.1).curveTo(37.5,-28.9,35.9,-28.7).curveTo(32.2,-28.1,30.1,-27.3).curveTo(27.4,-26.4,25.9,-25).curveTo(23.8,-23,25.3,-20.2).curveTo(26.2,-18.5,28.3,-16.8).curveTo(30.4,-15.1,33.7,-13).curveTo(35.5,-11.8,39.1,-9.4).curveTo(41.3,-8,42.5,-7.1).curveTo(44.3,-5.7,45.6,-4.5).curveTo(47.8,-2.3,48.7,-0.4).curveTo(50,2.5,47.9,5.1).curveTo(46.8,6.4,45.2,7.4).curveTo(44.1,8.2,42.2,9.1).curveTo(38.4,11,32.2,12.9).curveTo(26.3,14.7,18.6,16.5).curveTo(12.3,18,2.7,19.9).curveTo(-1.8,20.9,-6.3,21.7).curveTo(-7.9,22,-10.7,22.5).curveTo(-11,22.6,-11.3,22.6).curveTo(-13.9,23.1,-15.1,23.3).curveTo(-18.7,24,-20.5,24.3).curveTo(-24.7,25,-26.9,25.3).curveTo(-30.7,26,-32.5,26.3).curveTo(-36.5,26.9,-38.4,27.2).curveTo(-42.3,27.9,-44.2,28.3).curveTo(-46,28.5,-49.6,29.1);
	this.shape_31.setTransform(8.7415,118.8215);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.beginFill().beginStroke("#FFFFFF").moveTo(43,-29.2).curveTo(42.8,-29.2,42.6,-29.2).curveTo(39,-29,35.9,-28.5).curveTo(32.2,-27.9,30.1,-27.2).curveTo(27.4,-26.3,25.9,-24.9).curveTo(23.8,-22.8,25.3,-20.1).curveTo(26.2,-18.4,28.3,-16.6).curveTo(30.4,-14.9,33.7,-12.8).curveTo(35.5,-11.6,39.1,-9.2).curveTo(41.3,-7.8,42.5,-6.9).curveTo(44.3,-5.5,45.6,-4.3).curveTo(47.8,-2.2,48.7,-0.3).curveTo(50,2.7,47.9,5.3).curveTo(46.8,6.5,45.2,7.5).curveTo(44.1,8.3,42.2,9.2).curveTo(38.4,11.1,32.2,13).curveTo(26.3,14.8,18.6,16.7).curveTo(12.3,18.2,2.7,20.1).curveTo(-1.8,21,-6.3,21.8).curveTo(-7.9,22.2,-10.7,22.7).curveTo(-11,22.7,-11.3,22.8).curveTo(-13.9,23.3,-15.1,23.5).curveTo(-18.7,24.1,-20.5,24.5).curveTo(-24.7,25.1,-26.9,25.5).curveTo(-30.7,26.2,-32.5,26.4).curveTo(-36.5,27,-38.4,27.4).curveTo(-42.3,28.1,-44.2,28.4).curveTo(-46,28.6,-49.6,29.2);
	this.shape_32.setTransform(8.7415,118.6965);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.beginFill().beginStroke("#FFFFFF").moveTo(46.7,-29.2).curveTo(44.8,-29.2,42.6,-29.2).curveTo(39,-29,35.9,-28.5).curveTo(32.2,-27.9,30.1,-27.2).curveTo(27.4,-26.3,25.9,-24.9).curveTo(23.8,-22.8,25.3,-20.1).curveTo(26.2,-18.4,28.3,-16.6).curveTo(30.4,-14.9,33.7,-12.8).curveTo(35.5,-11.6,39.1,-9.2).curveTo(41.3,-7.8,42.5,-6.9).curveTo(44.3,-5.5,45.6,-4.3).curveTo(47.8,-2.2,48.7,-0.3).curveTo(50,2.7,47.9,5.3).curveTo(46.8,6.5,45.2,7.5).curveTo(44.1,8.3,42.2,9.2).curveTo(38.4,11.1,32.2,13).curveTo(26.3,14.8,18.6,16.7).curveTo(12.3,18.2,2.7,20.1).curveTo(-1.8,21,-6.3,21.8).curveTo(-7.9,22.2,-10.7,22.7).curveTo(-11,22.7,-11.3,22.8).curveTo(-13.9,23.3,-15.1,23.5).curveTo(-18.7,24.1,-20.5,24.5).curveTo(-24.7,25.1,-26.9,25.5).curveTo(-30.7,26.2,-32.5,26.4).curveTo(-36.5,27,-38.4,27.4).curveTo(-42.3,28.1,-44.2,28.4).curveTo(-46,28.6,-49.6,29.2);
	this.shape_33.setTransform(8.7415,118.6965);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.beginFill().beginStroke("#FFFFFF").moveTo(50.4,-29).curveTo(49.5,-29,49.3,-29).curveTo(46,-29.2,41.9,-29.2).curveTo(38.3,-29,35.2,-28.5).curveTo(31.4,-27.9,29.3,-27.2).curveTo(26.6,-26.3,25.2,-24.9).curveTo(23.1,-22.8,24.5,-20.1).curveTo(25.5,-18.4,27.6,-16.6).curveTo(29.6,-14.9,32.9,-12.8).curveTo(34.8,-11.6,38.4,-9.2).curveTo(40.6,-7.8,41.7,-6.9).curveTo(43.5,-5.5,44.9,-4.3).curveTo(47.1,-2.2,48,-0.3).curveTo(49.2,2.7,47.1,5.3).curveTo(46,6.5,44.5,7.5).curveTo(43.3,8.3,41.5,9.2).curveTo(37.6,11.1,31.4,13).curveTo(25.5,14.8,17.9,16.7).curveTo(11.5,18.2,2,20.1).curveTo(-2.5,21,-7.1,21.8).curveTo(-8.6,22.2,-11.5,22.7).curveTo(-11.7,22.7,-12,22.8).curveTo(-14.7,23.3,-15.8,23.5).curveTo(-19.5,24.1,-21.2,24.5).curveTo(-25.5,25.1,-27.6,25.5).curveTo(-31.5,26.2,-33.3,26.4).curveTo(-37.2,27,-39.1,27.4).curveTo(-43.1,28.1,-45,28.4).curveTo(-46.8,28.6,-50.3,29.2);
	this.shape_34.setTransform(9.4965,118.6965);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.beginFill().beginStroke("#FFFFFF").moveTo(51.9,-28.8).curveTo(51.4,-28.8,50.9,-28.8).curveTo(47.7,-29,47.3,-29).curveTo(44,-29.2,39.9,-29.2).curveTo(36.3,-29,33.2,-28.5).curveTo(29.5,-27.9,27.4,-27.2).curveTo(24.7,-26.3,23.2,-24.9).curveTo(21.1,-22.8,22.6,-20.1).curveTo(23.5,-18.4,25.6,-16.6).curveTo(27.7,-14.9,31,-12.8).curveTo(32.8,-11.6,36.4,-9.2).curveTo(38.6,-7.8,39.8,-6.9).curveTo(41.6,-5.5,42.9,-4.3).curveTo(45.1,-2.2,46,-0.3).curveTo(47.3,2.7,45.2,5.3).curveTo(44.1,6.5,42.5,7.5).curveTo(41.4,8.3,39.5,9.2).curveTo(35.7,11.1,29.5,13).curveTo(23.6,14.8,15.9,16.7).curveTo(9.6,18.2,0,20.1).curveTo(-4.5,21,-9,21.8).curveTo(-10.6,22.2,-13.4,22.7).curveTo(-13.7,22.7,-14,22.8).curveTo(-16.6,23.3,-17.8,23.5).curveTo(-21.4,24.1,-23.2,24.5).curveTo(-27.4,25.1,-29.6,25.5).curveTo(-33.4,26.2,-35.2,26.4).curveTo(-39.2,27,-41.1,27.4).curveTo(-45,28.1,-46.9,28.4).curveTo(-48.7,28.6,-52.3,29.2);
	this.shape_35.setTransform(11.4333,118.6965);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.beginFill().beginStroke("#FFFFFF").moveTo(54.1,-28.5).curveTo(53.2,-28.6,52.7,-28.6).curveTo(51.3,-28.7,49.1,-28.8).curveTo(45.9,-29,45.6,-29).curveTo(42.3,-29.2,38.2,-29.2).curveTo(34.6,-29,31.5,-28.5).curveTo(27.7,-27.9,25.6,-27.2).curveTo(22.9,-26.3,21.5,-24.9).curveTo(19.4,-22.8,20.8,-20.1).curveTo(21.8,-18.4,23.9,-16.6).curveTo(25.9,-14.9,29.2,-12.8).curveTo(31.1,-11.6,34.7,-9.2).curveTo(36.9,-7.8,38,-6.9).curveTo(39.8,-5.5,41.2,-4.3).curveTo(43.4,-2.2,44.3,-0.3).curveTo(45.5,2.7,43.4,5.3).curveTo(42.3,6.5,40.8,7.5).curveTo(39.6,8.3,37.8,9.2).curveTo(33.9,11.1,27.7,13).curveTo(21.8,14.8,14.2,16.7).curveTo(7.8,18.2,-1.7,20.1).curveTo(-6.2,21,-10.8,21.8).curveTo(-12.3,22.2,-15.2,22.7).curveTo(-15.4,22.7,-15.7,22.8).curveTo(-18.4,23.3,-19.5,23.5).curveTo(-23.2,24.1,-24.9,24.5).curveTo(-29.2,25.1,-31.3,25.5).curveTo(-35.2,26.2,-37,26.4).curveTo(-40.9,27,-42.8,27.4).curveTo(-46.8,28.1,-48.7,28.4).curveTo(-50.5,28.6,-54,29.2);
	this.shape_36.setTransform(13.173,118.6965);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.2,-28.2).curveTo(55.1,-28.3,54.5,-28.4).curveTo(54.5,-28.4,54.4,-28.4).curveTo(51.8,-28.5,50.5,-28.6).curveTo(49.1,-28.7,47,-28.8).curveTo(43.8,-29,43.4,-29).curveTo(40.1,-29.2,36,-29.2).curveTo(32.4,-29,29.3,-28.5).curveTo(25.6,-27.9,23.5,-27.2).curveTo(20.8,-26.3,19.3,-24.9).curveTo(17.2,-22.8,18.7,-20.1).curveTo(19.6,-18.4,21.7,-16.6).curveTo(23.8,-14.9,27.1,-12.8).curveTo(28.9,-11.6,32.5,-9.2).curveTo(34.7,-7.8,35.9,-6.9).curveTo(37.7,-5.5,39,-4.3).curveTo(41.2,-2.2,42.1,-0.3).curveTo(43.4,2.7,41.3,5.3).curveTo(40.2,6.5,38.6,7.5).curveTo(37.5,8.3,35.6,9.2).curveTo(31.8,11.1,25.6,13).curveTo(19.7,14.8,12,16.7).curveTo(5.7,18.2,-3.9,20.1).curveTo(-8.4,21,-12.9,21.8).curveTo(-14.5,22.2,-17.3,22.7).curveTo(-17.6,22.7,-17.9,22.8).curveTo(-20.5,23.3,-21.7,23.5).curveTo(-25.3,24.1,-27.1,24.5).curveTo(-31.3,25.1,-33.5,25.5).curveTo(-37.3,26.2,-39.1,26.4).curveTo(-43.1,27,-45,27.4).curveTo(-48.9,28.1,-50.8,28.4).curveTo(-52.6,28.6,-56.2,29.2);
	this.shape_37.setTransform(15.307,118.6965);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.beginFill().beginStroke("#FFFFFF").moveTo(57.9,-27.9).curveTo(55.6,-28.1,54.5,-28.2).curveTo(53.4,-28.3,52.8,-28.4).curveTo(50.2,-28.5,48.8,-28.6).curveTo(47.4,-28.7,45.3,-28.8).curveTo(42.1,-29,41.7,-29).curveTo(38.4,-29.2,34.3,-29.2).curveTo(30.7,-29,27.6,-28.5).curveTo(23.9,-27.9,21.8,-27.2).curveTo(19.1,-26.3,17.6,-24.9).curveTo(15.5,-22.8,17,-20.1).curveTo(17.9,-18.4,20,-16.6).curveTo(22.1,-14.9,25.4,-12.8).curveTo(27.2,-11.6,30.8,-9.2).curveTo(33,-7.8,34.2,-6.9).curveTo(36,-5.5,37.3,-4.3).curveTo(39.5,-2.2,40.4,-0.3).curveTo(41.7,2.7,39.6,5.3).curveTo(38.5,6.5,36.9,7.5).curveTo(35.8,8.3,33.9,9.2).curveTo(30.1,11.1,23.9,13).curveTo(18,14.8,10.3,16.7).curveTo(4,18.2,-5.6,20.1).curveTo(-10.1,21,-14.6,21.8).curveTo(-16.2,22.2,-19,22.7).curveTo(-19.3,22.7,-19.6,22.8).curveTo(-22.2,23.3,-23.4,23.5).curveTo(-27,24.1,-28.8,24.5).curveTo(-33,25.1,-35.2,25.5).curveTo(-39,26.2,-40.8,26.4).curveTo(-44.8,27,-46.7,27.4).curveTo(-50.6,28.1,-52.5,28.4).curveTo(-54.3,28.6,-57.9,29.2);
	this.shape_38.setTransform(17.0055,118.6965);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.beginFill().beginStroke("#FFFFFF").moveTo(59.7,-27.5).lineTo(56.4,-27.8).curveTo(53.9,-28.1,52.6,-28.2).curveTo(51.6,-28.3,51,-28.4).curveTo(48.4,-28.5,47,-28.6).curveTo(45.6,-28.7,43.4,-28.8).curveTo(40.2,-29,39.9,-29).curveTo(36.6,-29.2,32.5,-29.2).curveTo(28.9,-29,25.8,-28.5).curveTo(22,-27.9,19.9,-27.2).curveTo(17.2,-26.3,15.8,-24.9).curveTo(13.7,-22.8,15.1,-20.1).curveTo(16.1,-18.4,18.2,-16.6).curveTo(20.2,-14.9,23.5,-12.8).curveTo(25.4,-11.6,29,-9.2).curveTo(31.2,-7.8,32.3,-6.9).curveTo(34.1,-5.5,35.5,-4.3).curveTo(37.7,-2.2,38.6,-0.3).curveTo(39.8,2.7,37.7,5.3).curveTo(36.6,6.5,35.1,7.5).curveTo(33.9,8.3,32.1,9.2).curveTo(28.2,11.1,22,13).curveTo(16.1,14.8,8.5,16.7).curveTo(2.1,18.2,-7.4,20.1).curveTo(-11.9,21,-16.5,21.8).curveTo(-18,22.2,-20.9,22.7).curveTo(-21.1,22.7,-21.4,22.8).curveTo(-24.1,23.3,-25.2,23.5).curveTo(-28.9,24.1,-30.6,24.5).curveTo(-34.9,25.1,-37,25.5).curveTo(-40.9,26.2,-42.7,26.4).curveTo(-46.6,27,-48.5,27.4).curveTo(-52.5,28.1,-54.4,28.4).curveTo(-56.2,28.6,-59.7,29.2);
	this.shape_39.setTransform(18.856,118.6965);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.beginFill().beginStroke("#FFFFFF").moveTo(61.6,-27.1).lineTo(54.6,-27.8).curveTo(52.1,-28.1,50.8,-28.2).curveTo(49.7,-28.3,49.1,-28.4).curveTo(46.5,-28.5,45.1,-28.6).curveTo(43.7,-28.7,41.6,-28.8).curveTo(38.4,-29,38,-29).curveTo(34.7,-29.2,30.6,-29.2).curveTo(27,-29,23.9,-28.5).curveTo(20.2,-27.9,18.1,-27.2).curveTo(15.4,-26.3,13.9,-24.9).curveTo(11.8,-22.8,13.3,-20.1).curveTo(14.2,-18.4,16.3,-16.6).curveTo(18.4,-14.9,21.7,-12.8).curveTo(23.5,-11.6,27.1,-9.2).curveTo(29.3,-7.8,30.5,-6.9).curveTo(32.3,-5.5,33.6,-4.3).curveTo(35.8,-2.2,36.7,-0.3).curveTo(38,2.7,35.9,5.3).curveTo(34.8,6.5,33.2,7.5).curveTo(32.1,8.3,30.2,9.2).curveTo(26.4,11.1,20.2,13).curveTo(14.3,14.8,6.6,16.7).curveTo(0.3,18.2,-9.3,20.1).curveTo(-13.8,21,-18.3,21.8).curveTo(-19.9,22.2,-22.7,22.7).curveTo(-23,22.7,-23.3,22.8).curveTo(-25.9,23.3,-27.1,23.5).curveTo(-30.7,24.1,-32.5,24.5).curveTo(-36.7,25.1,-38.9,25.5).curveTo(-42.7,26.2,-44.5,26.4).curveTo(-48.5,27,-50.4,27.4).curveTo(-54.3,28.1,-56.2,28.4).curveTo(-58,28.6,-61.6,29.2);
	this.shape_40.setTransform(20.7082,118.6965);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.beginFill().beginStroke("#FFFFFF").moveTo(63.9,-26.7).lineTo(52.3,-27.8).curveTo(49.8,-28.1,48.5,-28.2).curveTo(47.5,-28.3,46.9,-28.4).curveTo(44.3,-28.5,42.9,-28.6).curveTo(41.5,-28.7,39.3,-28.8).curveTo(36.1,-29,35.8,-29).curveTo(32.5,-29.2,28.4,-29.2).curveTo(24.8,-29,21.7,-28.5).curveTo(17.9,-27.9,15.8,-27.2).curveTo(13.1,-26.3,11.7,-24.9).curveTo(9.6,-22.8,11,-20.1).curveTo(12,-18.4,14.1,-16.6).curveTo(16.1,-14.9,19.4,-12.8).curveTo(21.3,-11.6,24.9,-9.2).curveTo(27.1,-7.8,28.2,-6.9).curveTo(30,-5.5,31.4,-4.3).curveTo(33.6,-2.2,34.5,-0.3).curveTo(35.7,2.7,33.6,5.3).curveTo(32.5,6.5,31,7.5).curveTo(29.8,8.3,28,9.2).curveTo(24.1,11.1,17.9,13).curveTo(12,14.8,4.4,16.7).curveTo(-2,18.2,-11.5,20.1).curveTo(-16,21,-20.6,21.8).curveTo(-22.1,22.2,-25,22.7).curveTo(-25.2,22.7,-25.5,22.8).curveTo(-28.2,23.3,-29.3,23.5).curveTo(-33,24.1,-34.7,24.5).curveTo(-39,25.1,-41.1,25.5).curveTo(-45,26.2,-46.8,26.4).curveTo(-50.7,27,-52.6,27.4).curveTo(-56.6,28.1,-58.5,28.4).curveTo(-60.3,28.6,-63.8,29.2);
	this.shape_41.setTransform(22.9831,118.6965);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.beginFill().beginStroke("#FFFFFF").moveTo(65.7,-26.3).curveTo(63.9,-26.5,63,-26.6).lineTo(50.5,-27.8).curveTo(48,-28.1,46.7,-28.2).curveTo(45.6,-28.3,45,-28.4).curveTo(42.4,-28.5,41,-28.6).curveTo(39.6,-28.7,37.5,-28.8).curveTo(34.3,-29,33.9,-29).curveTo(30.6,-29.2,26.5,-29.2).curveTo(22.9,-29,19.8,-28.5).curveTo(16.1,-27.9,14,-27.2).curveTo(11.3,-26.3,9.8,-24.9).curveTo(7.7,-22.8,9.2,-20.1).curveTo(10.1,-18.4,12.2,-16.6).curveTo(14.3,-14.9,17.6,-12.8).curveTo(19.4,-11.6,23,-9.2).curveTo(25.2,-7.8,26.4,-6.9).curveTo(28.2,-5.5,29.5,-4.3).curveTo(31.7,-2.2,32.6,-0.3).curveTo(33.9,2.7,31.8,5.3).curveTo(30.7,6.5,29.1,7.5).curveTo(28,8.3,26.1,9.2).curveTo(22.3,11.1,16.1,13).curveTo(10.2,14.8,2.5,16.7).curveTo(-3.8,18.2,-13.4,20.1).curveTo(-17.9,21,-22.4,21.8).curveTo(-24,22.2,-26.8,22.7).curveTo(-27.1,22.7,-27.4,22.8).curveTo(-30,23.3,-31.2,23.5).curveTo(-34.8,24.1,-36.6,24.5).curveTo(-40.8,25.1,-43,25.5).curveTo(-46.8,26.2,-48.6,26.4).curveTo(-52.6,27,-54.5,27.4).curveTo(-58.4,28.1,-60.3,28.4).curveTo(-62.1,28.6,-65.7,29.2);
	this.shape_42.setTransform(24.8109,118.6965);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.beginFill().beginStroke("#FFFFFF").moveTo(67.5,-25.9).curveTo(67.3,-25.9,67,-25.9).curveTo(64.8,-26.2,63.7,-26.3).curveTo(61.7,-26.5,60.7,-26.6).lineTo(48.2,-27.8).curveTo(45.7,-28.1,44.4,-28.2).curveTo(43.4,-28.3,42.8,-28.4).curveTo(40.2,-28.5,38.8,-28.6).curveTo(37.4,-28.7,35.2,-28.8).curveTo(32,-29,31.7,-29).curveTo(28.4,-29.2,24.3,-29.2).curveTo(20.7,-29,17.6,-28.5).curveTo(13.8,-27.9,11.7,-27.2).curveTo(9,-26.3,7.6,-24.9).curveTo(5.5,-22.8,6.9,-20.1).curveTo(7.9,-18.4,10,-16.6).curveTo(12,-14.9,15.3,-12.8).curveTo(17.2,-11.6,20.8,-9.2).curveTo(23,-7.8,24.1,-6.9).curveTo(25.9,-5.5,27.3,-4.3).curveTo(29.5,-2.2,30.4,-0.3).curveTo(31.6,2.7,29.5,5.3).curveTo(28.4,6.5,26.9,7.5).curveTo(25.7,8.3,23.9,9.2).curveTo(20,11.1,13.8,13).curveTo(7.9,14.8,0.3,16.7).curveTo(-6.1,18.2,-15.6,20.1).curveTo(-20.1,21,-24.7,21.8).curveTo(-26.2,22.2,-29.1,22.7).curveTo(-29.3,22.7,-29.6,22.8).curveTo(-32.3,23.3,-33.4,23.5).curveTo(-37.1,24.1,-38.8,24.5).curveTo(-43.1,25.1,-45.2,25.5).curveTo(-49.1,26.2,-50.9,26.4).curveTo(-54.8,27,-56.7,27.4).curveTo(-60.7,28.1,-62.6,28.4).curveTo(-64.4,28.6,-67.9,29.2);
	this.shape_43.setTransform(27.0833,118.6965);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.beginFill().beginStroke("#FFFFFF").moveTo(69.7,-25.6).lineTo(68.7,-25.7).curveTo(68.1,-25.8,65.3,-25.9).curveTo(63.1,-26.2,61.9,-26.3).curveTo(60,-26.5,59,-26.6).lineTo(46.5,-27.8).curveTo(44,-28.1,42.7,-28.2).curveTo(41.6,-28.3,41,-28.4).curveTo(38.4,-28.5,37,-28.6).curveTo(35.6,-28.7,33.5,-28.8).curveTo(30.3,-29,29.9,-29).curveTo(26.6,-29.2,22.5,-29.2).curveTo(18.9,-29,15.8,-28.5).curveTo(12.1,-27.9,10,-27.2).curveTo(7.3,-26.3,5.8,-24.9).curveTo(3.7,-22.8,5.2,-20.1).curveTo(6.1,-18.4,8.2,-16.6).curveTo(10.3,-14.9,13.6,-12.8).curveTo(15.4,-11.6,19,-9.2).curveTo(21.2,-7.8,22.4,-6.9).curveTo(24.2,-5.5,25.5,-4.3).curveTo(27.7,-2.2,28.6,-0.3).curveTo(29.9,2.7,27.8,5.3).curveTo(26.7,6.5,25.1,7.5).curveTo(24,8.3,22.1,9.2).curveTo(18.3,11.1,12.1,13).curveTo(6.2,14.8,-1.5,16.7).curveTo(-7.8,18.2,-17.4,20.1).curveTo(-21.9,21,-26.4,21.8).curveTo(-28,22.2,-30.8,22.7).curveTo(-31.1,22.7,-31.4,22.8).curveTo(-34,23.3,-35.2,23.5).curveTo(-38.8,24.1,-40.6,24.5).curveTo(-44.8,25.1,-47,25.5).curveTo(-50.8,26.2,-52.6,26.4).curveTo(-56.6,27,-58.5,27.4).curveTo(-62.4,28.1,-64.3,28.4).curveTo(-66.1,28.6,-69.7,29.2);
	this.shape_44.setTransform(28.8223,118.6965);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.beginFill().beginStroke("#FFFFFF").moveTo(71.4,-25.2).curveTo(71,-25.3,70.8,-25.3).lineTo(67,-25.7).curveTo(66.4,-25.8,63.6,-25.9).curveTo(61.4,-26.2,60.2,-26.3).curveTo(58.3,-26.5,57.3,-26.6).lineTo(44.8,-27.8).curveTo(42.3,-28.1,41,-28.2).curveTo(39.9,-28.3,39.3,-28.4).curveTo(36.7,-28.5,35.3,-28.6).curveTo(33.9,-28.7,31.8,-28.8).curveTo(28.6,-29,28.2,-29).curveTo(24.9,-29.2,20.8,-29.2).curveTo(17.2,-29,14.1,-28.5).curveTo(10.4,-27.9,8.3,-27.2).curveTo(5.6,-26.3,4.1,-24.9).curveTo(2,-22.8,3.5,-20.1).curveTo(4.4,-18.4,6.5,-16.6).curveTo(8.6,-14.9,11.9,-12.8).curveTo(13.7,-11.6,17.3,-9.2).curveTo(19.5,-7.8,20.7,-6.9).curveTo(22.5,-5.5,23.8,-4.3).curveTo(26,-2.2,26.9,-0.3).curveTo(28.2,2.7,26.1,5.3).curveTo(25,6.5,23.4,7.5).curveTo(22.3,8.3,20.4,9.2).curveTo(16.6,11.1,10.4,13).curveTo(4.5,14.8,-3.2,16.7).curveTo(-9.5,18.2,-19.1,20.1).curveTo(-23.6,21,-28.1,21.8).curveTo(-29.7,22.2,-32.5,22.7).curveTo(-32.8,22.7,-33.1,22.8).curveTo(-35.7,23.3,-36.9,23.5).curveTo(-40.5,24.1,-42.3,24.5).curveTo(-46.5,25.1,-48.7,25.5).curveTo(-52.5,26.2,-54.3,26.4).curveTo(-58.3,27,-60.2,27.4).curveTo(-64.1,28.1,-66,28.4).curveTo(-67.8,28.6,-71.4,29.2);
	this.shape_45.setTransform(30.5187,118.6965);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.beginFill().beginStroke("#FFFFFF").moveTo(73.4,-25).curveTo(72.4,-25,71.2,-25.1).curveTo(69.3,-25.2,68.3,-25.3).lineTo(64.5,-25.7).curveTo(63.9,-25.8,61.1,-25.9).curveTo(58.9,-26.2,57.7,-26.3).curveTo(55.8,-26.5,54.8,-26.6).lineTo(42.3,-27.8).curveTo(39.8,-28.1,38.5,-28.2).curveTo(37.4,-28.3,36.8,-28.4).curveTo(34.2,-28.5,32.8,-28.6).curveTo(31.4,-28.7,29.3,-28.8).curveTo(26.1,-29,25.7,-29).curveTo(22.4,-29.2,18.3,-29.2).curveTo(14.7,-29,11.6,-28.5).curveTo(7.9,-27.9,5.8,-27.2).curveTo(3.1,-26.3,1.6,-24.9).curveTo(-0.5,-22.8,1,-20.1).curveTo(1.9,-18.4,4,-16.6).curveTo(6.1,-14.9,9.4,-12.8).curveTo(11.2,-11.6,14.8,-9.2).curveTo(17,-7.8,18.2,-6.9).curveTo(20,-5.5,21.3,-4.3).curveTo(23.5,-2.2,24.4,-0.3).curveTo(25.7,2.7,23.6,5.3).curveTo(22.5,6.5,20.9,7.5).curveTo(19.8,8.3,17.9,9.2).curveTo(14.1,11.1,7.9,13).curveTo(2,14.8,-5.7,16.7).curveTo(-12,18.2,-21.6,20.1).curveTo(-26.1,21,-30.6,21.8).curveTo(-32.2,22.2,-35,22.7).curveTo(-35.3,22.7,-35.6,22.8).curveTo(-38.2,23.3,-39.4,23.5).curveTo(-43,24.1,-44.8,24.5).curveTo(-49,25.1,-51.2,25.5).curveTo(-55,26.2,-56.8,26.4).curveTo(-60.8,27,-62.7,27.4).curveTo(-66.6,28.1,-68.5,28.4).curveTo(-70.3,28.6,-73.9,29.2);
	this.shape_46.setTransform(33.0083,118.6965);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.beginFill().beginStroke("#FFFFFF").moveTo(75.1,-24.8).curveTo(72.5,-25,69.5,-25.1).curveTo(67.6,-25.2,66.6,-25.3).lineTo(62.8,-25.7).curveTo(62.2,-25.8,59.4,-25.9).curveTo(57.2,-26.2,56,-26.3).curveTo(54.1,-26.5,53.1,-26.6).lineTo(40.6,-27.8).curveTo(38.1,-28.1,36.8,-28.2).curveTo(35.7,-28.3,35.1,-28.4).curveTo(32.5,-28.5,31.1,-28.6).curveTo(29.7,-28.7,27.6,-28.8).curveTo(24.4,-29,24,-29).curveTo(20.7,-29.2,16.6,-29.2).curveTo(13,-29,9.9,-28.5).curveTo(6.2,-27.9,4.1,-27.2).curveTo(1.4,-26.3,-0.1,-24.9).curveTo(-2.2,-22.8,-0.7,-20.1).curveTo(0.2,-18.4,2.3,-16.6).curveTo(4.4,-14.9,7.7,-12.8).curveTo(9.5,-11.6,13.1,-9.2).curveTo(15.3,-7.8,16.5,-6.9).curveTo(18.3,-5.5,19.6,-4.3).curveTo(21.8,-2.2,22.7,-0.3).curveTo(24,2.7,21.9,5.3).curveTo(20.8,6.5,19.2,7.5).curveTo(18.1,8.3,16.2,9.2).curveTo(12.4,11.1,6.2,13).curveTo(0.3,14.8,-7.4,16.7).curveTo(-13.7,18.2,-23.3,20.1).curveTo(-27.8,21,-32.3,21.8).curveTo(-33.9,22.2,-36.7,22.7).curveTo(-37,22.7,-37.3,22.8).curveTo(-39.9,23.3,-41.1,23.5).curveTo(-44.7,24.1,-46.5,24.5).curveTo(-50.7,25.1,-52.9,25.5).curveTo(-56.7,26.2,-58.5,26.4).curveTo(-62.5,27,-64.4,27.4).curveTo(-68.3,28.1,-70.2,28.4).curveTo(-72,28.6,-75.6,29.2);
	this.shape_47.setTransform(34.7083,118.6965);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.beginFill().beginStroke("#FFFFFF").moveTo(77.2,-24.8).curveTo(76.2,-24.8,74.4,-24.8).curveTo(71.2,-24.9,67.4,-25.1).curveTo(65.5,-25.2,64.5,-25.3).lineTo(60.7,-25.7).curveTo(60.1,-25.8,57.3,-25.9).curveTo(55.1,-26.2,53.9,-26.3).curveTo(52,-26.5,51,-26.6).lineTo(38.5,-27.8).curveTo(36,-28.1,34.7,-28.2).curveTo(33.6,-28.3,33,-28.4).curveTo(30.4,-28.5,29,-28.6).curveTo(27.6,-28.7,25.5,-28.8).curveTo(22.3,-29,21.9,-29).curveTo(18.6,-29.2,14.5,-29.2).curveTo(10.9,-29,7.8,-28.5).curveTo(4.1,-27.9,2,-27.2).curveTo(-0.7,-26.3,-2.2,-24.9).curveTo(-4.3,-22.8,-2.8,-20.1).curveTo(-1.9,-18.4,0.2,-16.6).curveTo(2.3,-14.9,5.6,-12.8).curveTo(7.4,-11.6,11,-9.2).curveTo(13.2,-7.8,14.4,-6.9).curveTo(16.2,-5.5,17.5,-4.3).curveTo(19.7,-2.2,20.6,-0.3).curveTo(21.9,2.7,19.8,5.3).curveTo(18.7,6.5,17.1,7.5).curveTo(16,8.3,14.1,9.2).curveTo(10.3,11.1,4.1,13).curveTo(-1.8,14.8,-9.5,16.7).curveTo(-15.8,18.2,-25.4,20.1).curveTo(-29.9,21,-34.4,21.8).curveTo(-36,22.2,-38.8,22.7).curveTo(-39.1,22.7,-39.4,22.8).curveTo(-42,23.3,-43.2,23.5).curveTo(-46.8,24.1,-48.6,24.5).curveTo(-52.8,25.1,-55,25.5).curveTo(-58.8,26.2,-60.6,26.4).curveTo(-64.6,27,-66.5,27.4).curveTo(-70.4,28.1,-72.3,28.4).curveTo(-74.1,28.6,-77.7,29.2);
	this.shape_48.setTransform(36.8083,118.6965);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.beginFill().beginStroke("#FFFFFF").moveTo(79.4,-25).curveTo(77.8,-24.8,75.9,-24.8).curveTo(74.9,-24.8,72.3,-24.8).curveTo(69.1,-24.9,65.3,-25.1).curveTo(63.4,-25.2,62.4,-25.3).lineTo(58.6,-25.7).curveTo(58,-25.8,55.2,-25.9).curveTo(53,-26.2,51.8,-26.3).curveTo(49.9,-26.5,48.9,-26.6).lineTo(36.4,-27.8).curveTo(33.9,-28.1,32.6,-28.2).curveTo(31.5,-28.3,30.9,-28.4).curveTo(28.3,-28.5,26.9,-28.6).curveTo(25.5,-28.7,23.4,-28.8).curveTo(20.2,-29,19.8,-29).curveTo(16.5,-29.2,12.4,-29.2).curveTo(8.8,-29,5.7,-28.5).curveTo(2,-27.9,-0.1,-27.2).curveTo(-2.8,-26.3,-4.3,-24.9).curveTo(-6.4,-22.8,-4.9,-20.1).curveTo(-4,-18.4,-1.9,-16.6).curveTo(0.2,-14.9,3.5,-12.8).curveTo(5.3,-11.6,8.9,-9.2).curveTo(11.1,-7.8,12.3,-6.9).curveTo(14.1,-5.5,15.4,-4.3).curveTo(17.6,-2.2,18.5,-0.3).curveTo(19.8,2.7,17.7,5.3).curveTo(16.6,6.5,15,7.5).curveTo(13.9,8.3,12,9.2).curveTo(8.2,11.1,2,13).curveTo(-3.9,14.8,-11.6,16.7).curveTo(-17.9,18.2,-27.5,20.1).curveTo(-32,21,-36.5,21.8).curveTo(-38.1,22.2,-40.9,22.7).curveTo(-41.2,22.7,-41.5,22.8).curveTo(-44.1,23.3,-45.3,23.5).curveTo(-48.9,24.1,-50.7,24.5).curveTo(-54.9,25.1,-57.1,25.5).curveTo(-60.9,26.2,-62.7,26.4).curveTo(-66.7,27,-68.6,27.4).curveTo(-72.5,28.1,-74.4,28.4).curveTo(-76.2,28.6,-79.8,29.2);
	this.shape_49.setTransform(38.9333,118.6965);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.beginFill().beginStroke("#FFFFFF").moveTo(81.1,-25.1).curveTo(80.4,-25.1,79.4,-25).curveTo(78.1,-25,77.6,-25).curveTo(76.1,-24.8,74.2,-24.8).curveTo(73.1,-24.8,70.6,-24.8).curveTo(67.4,-24.9,63.5,-25.1).curveTo(61.6,-25.2,60.7,-25.3).lineTo(56.9,-25.7).curveTo(56.3,-25.8,53.4,-25.9).curveTo(51.2,-26.2,50.1,-26.3).curveTo(48.1,-26.5,47.1,-26.6).lineTo(34.6,-27.8).curveTo(32.1,-28.1,30.8,-28.2).curveTo(29.8,-28.3,29.2,-28.4).curveTo(26.6,-28.5,25.2,-28.6).curveTo(23.8,-28.7,21.6,-28.8).curveTo(18.4,-29,18.1,-29).curveTo(14.8,-29.2,10.7,-29.2).curveTo(7.1,-29,4,-28.5).curveTo(0.2,-27.9,-1.9,-27.2).curveTo(-4.6,-26.3,-6,-24.9).curveTo(-8.1,-22.8,-6.7,-20.1).curveTo(-5.7,-18.4,-3.6,-16.6).curveTo(-1.6,-14.9,1.7,-12.8).curveTo(3.6,-11.6,7.2,-9.2).curveTo(9.4,-7.8,10.5,-6.9).curveTo(12.3,-5.5,13.7,-4.3).curveTo(15.9,-2.2,16.8,-0.3).curveTo(18,2.7,15.9,5.3).curveTo(14.8,6.5,13.3,7.5).curveTo(12.1,8.3,10.3,9.2).curveTo(6.4,11.1,0.2,13).curveTo(-5.7,14.8,-13.3,16.7).curveTo(-19.7,18.2,-29.2,20.1).curveTo(-33.7,21,-38.3,21.8).curveTo(-39.8,22.2,-42.7,22.7).curveTo(-42.9,22.7,-43.2,22.8).curveTo(-45.9,23.3,-47,23.5).curveTo(-50.7,24.1,-52.4,24.5).curveTo(-56.7,25.1,-58.8,25.5).curveTo(-62.7,26.2,-64.5,26.4).curveTo(-68.4,27,-70.3,27.4).curveTo(-74.3,28.1,-76.2,28.4).curveTo(-78,28.6,-81.5,29.2);
	this.shape_50.setTransform(40.6583,118.6965);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.beginFill().beginStroke("#FFFFFF").moveTo(83,-25.8).curveTo(81.5,-25.5,79.3,-25.2).curveTo(78.6,-25.1,77.5,-25).curveTo(76.2,-25,75.7,-25).curveTo(74.2,-24.8,72.3,-24.8).curveTo(71.2,-24.8,68.7,-24.8).curveTo(65.5,-24.9,61.6,-25.1).curveTo(59.7,-25.2,58.8,-25.3).lineTo(55,-25.7).curveTo(54.4,-25.8,51.5,-25.9).curveTo(49.3,-26.2,48.2,-26.3).curveTo(46.2,-26.5,45.2,-26.6).lineTo(32.7,-27.8).curveTo(30.2,-28.1,28.9,-28.2).curveTo(27.9,-28.3,27.3,-28.4).curveTo(24.7,-28.5,23.3,-28.6).curveTo(21.9,-28.7,19.7,-28.8).curveTo(16.5,-29,16.2,-29).curveTo(12.9,-29.2,8.8,-29.2).curveTo(5.2,-29,2.1,-28.5).curveTo(-1.7,-27.9,-3.8,-27.2).curveTo(-6.5,-26.3,-7.9,-24.9).curveTo(-10,-22.8,-8.6,-20.1).curveTo(-7.6,-18.4,-5.5,-16.6).curveTo(-3.5,-14.9,-0.2,-12.8).curveTo(1.7,-11.6,5.3,-9.2).curveTo(7.5,-7.8,8.6,-6.9).curveTo(10.4,-5.5,11.8,-4.3).curveTo(14,-2.2,14.9,-0.3).curveTo(16.1,2.7,14,5.3).curveTo(12.9,6.5,11.4,7.5).curveTo(10.2,8.3,8.4,9.2).curveTo(4.5,11.1,-1.7,13).curveTo(-7.6,14.8,-15.2,16.7).curveTo(-21.6,18.2,-31.1,20.1).curveTo(-35.6,21,-40.2,21.8).curveTo(-41.7,22.2,-44.6,22.7).curveTo(-44.8,22.7,-45.1,22.8).curveTo(-47.8,23.3,-48.9,23.5).curveTo(-52.6,24.1,-54.3,24.5).curveTo(-58.6,25.1,-60.7,25.5).curveTo(-64.6,26.2,-66.4,26.4).curveTo(-70.3,27,-72.2,27.4).curveTo(-76.2,28.1,-78.1,28.4).curveTo(-79.9,28.6,-83.4,29.2);
	this.shape_51.setTransform(42.5583,118.6965);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.beginFill().beginStroke("#FFFFFF").moveTo(85.1,-26.9).curveTo(84.8,-26.8,84.6,-26.7).curveTo(83.4,-26.3,82.2,-26).curveTo(80.4,-25.6,77.2,-25.2).curveTo(76.5,-25.1,75.4,-25).curveTo(74.1,-25,73.6,-25).curveTo(72.1,-24.8,70.2,-24.8).curveTo(69.1,-24.8,66.6,-24.8).curveTo(63.4,-24.9,59.5,-25.1).curveTo(57.6,-25.2,56.7,-25.3).lineTo(52.9,-25.7).curveTo(52.3,-25.8,49.4,-25.9).curveTo(47.2,-26.2,46.1,-26.3).curveTo(44.1,-26.5,43.1,-26.6).lineTo(30.6,-27.8).curveTo(28.1,-28.1,26.8,-28.2).curveTo(25.8,-28.3,25.2,-28.4).curveTo(22.6,-28.5,21.2,-28.6).curveTo(19.8,-28.7,17.6,-28.8).curveTo(14.4,-29,14.1,-29).curveTo(10.8,-29.2,6.7,-29.2).curveTo(3.1,-29,-0,-28.5).curveTo(-3.8,-27.9,-5.9,-27.2).curveTo(-8.6,-26.3,-10,-24.9).curveTo(-12.1,-22.8,-10.7,-20.1).curveTo(-9.7,-18.4,-7.6,-16.6).curveTo(-5.6,-14.9,-2.3,-12.8).curveTo(-0.4,-11.6,3.2,-9.2).curveTo(5.4,-7.8,6.5,-6.9).curveTo(8.3,-5.5,9.7,-4.3).curveTo(11.9,-2.2,12.8,-0.3).curveTo(14,2.7,11.9,5.3).curveTo(10.8,6.5,9.3,7.5).curveTo(8.1,8.3,6.3,9.2).curveTo(2.4,11.1,-3.8,13).curveTo(-9.7,14.8,-17.3,16.7).curveTo(-23.7,18.2,-33.2,20.1).curveTo(-37.7,21,-42.3,21.8).curveTo(-43.8,22.2,-46.7,22.7).curveTo(-46.9,22.7,-47.2,22.8).curveTo(-49.9,23.3,-51,23.5).curveTo(-54.7,24.1,-56.4,24.5).curveTo(-60.7,25.1,-62.8,25.5).curveTo(-66.7,26.2,-68.5,26.4).curveTo(-72.4,27,-74.3,27.4).curveTo(-78.3,28.1,-80.2,28.4).curveTo(-82,28.6,-85.5,29.2);
	this.shape_52.setTransform(44.6583,118.6965);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.beginFill().beginStroke("#FFFFFF").moveTo(86.9,-28.3).curveTo(85,-27.4,82.8,-26.7).curveTo(81.7,-26.3,80.4,-26).curveTo(78.6,-25.6,75.5,-25.2).curveTo(74.8,-25.1,73.7,-25).curveTo(72.4,-25,71.9,-25).curveTo(70.3,-24.8,68.4,-24.8).curveTo(67.4,-24.8,64.8,-24.8).curveTo(61.6,-24.9,57.8,-25.1).curveTo(55.9,-25.2,54.9,-25.3).lineTo(51.1,-25.7).curveTo(50.5,-25.8,47.7,-25.9).curveTo(45.5,-26.2,44.3,-26.3).curveTo(42.4,-26.5,41.4,-26.6).lineTo(28.9,-27.8).curveTo(26.4,-28.1,25.1,-28.2).curveTo(24,-28.3,23.4,-28.4).curveTo(20.8,-28.5,19.4,-28.6).curveTo(18,-28.7,15.9,-28.8).curveTo(12.7,-29,12.3,-29).curveTo(9,-29.2,4.9,-29.2).curveTo(1.3,-29,-1.8,-28.5).curveTo(-5.5,-27.9,-7.6,-27.2).curveTo(-10.3,-26.3,-11.8,-24.9).curveTo(-13.9,-22.8,-12.4,-20.1).curveTo(-11.5,-18.4,-9.4,-16.6).curveTo(-7.3,-14.9,-4,-12.8).curveTo(-2.2,-11.6,1.4,-9.2).curveTo(3.6,-7.8,4.8,-6.9).curveTo(6.6,-5.5,7.9,-4.3).curveTo(10.1,-2.2,11,-0.3).curveTo(12.3,2.7,10.2,5.3).curveTo(9.1,6.5,7.5,7.5).curveTo(6.4,8.3,4.5,9.2).curveTo(0.7,11.1,-5.5,13).curveTo(-11.4,14.8,-19.1,16.7).curveTo(-25.4,18.2,-35,20.1).curveTo(-39.5,21,-44,21.8).curveTo(-45.6,22.2,-48.4,22.7).curveTo(-48.7,22.7,-49,22.8).curveTo(-51.6,23.3,-52.8,23.5).curveTo(-56.4,24.1,-58.2,24.5).curveTo(-62.4,25.1,-64.6,25.5).curveTo(-68.4,26.2,-70.2,26.4).curveTo(-74.2,27,-76.1,27.4).curveTo(-80,28.1,-81.9,28.4).curveTo(-83.7,28.6,-87.3,29.2);
	this.shape_53.setTransform(46.4333,118.6965);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.beginFill().beginStroke("#FFFFFF").moveTo(88.3,-29.7).curveTo(88.2,-29.6,88,-29.5).curveTo(85.2,-27.6,81.3,-26.4).curveTo(80.2,-26,78.9,-25.7).curveTo(77.1,-25.3,74,-24.8).curveTo(73.3,-24.7,72.2,-24.7).curveTo(70.9,-24.6,70.4,-24.6).curveTo(68.8,-24.4,66.9,-24.4).curveTo(65.9,-24.4,63.3,-24.5).curveTo(60.1,-24.5,56.3,-24.8).curveTo(54.4,-24.9,53.4,-24.9).lineTo(49.6,-25.4).curveTo(49,-25.4,46.2,-25.6).curveTo(44,-25.8,42.8,-26).curveTo(40.9,-26.2,39.9,-26.3).lineTo(27.4,-27.5).curveTo(24.9,-27.7,23.6,-27.9).curveTo(22.5,-28,21.9,-28.1).curveTo(19.3,-28.2,17.9,-28.3).curveTo(16.5,-28.4,14.4,-28.5).curveTo(11.2,-28.7,10.8,-28.7).curveTo(7.5,-28.8,3.4,-28.8).curveTo(-0.2,-28.6,-3.3,-28.2).curveTo(-7,-27.6,-9.1,-26.8).curveTo(-11.8,-25.9,-13.3,-24.5).curveTo(-15.4,-22.5,-13.9,-19.7).curveTo(-13,-18,-10.9,-16.3).curveTo(-8.8,-14.6,-5.5,-12.5).curveTo(-3.7,-11.3,-0.1,-8.9).curveTo(2.1,-7.5,3.3,-6.6).curveTo(5.1,-5.2,6.4,-4).curveTo(8.6,-1.8,9.5,0.1).curveTo(10.8,3,8.7,5.6).curveTo(7.6,6.9,6,7.9).curveTo(4.9,8.7,3,9.6).curveTo(-0.8,11.5,-7,13.4).curveTo(-12.9,15.2,-20.6,17).curveTo(-26.9,18.5,-36.5,20.4).curveTo(-41,21.4,-45.5,22.2).curveTo(-47.1,22.5,-49.9,23).curveTo(-50.2,23.1,-50.5,23.1).curveTo(-53.1,23.6,-54.3,23.8).curveTo(-57.9,24.5,-59.7,24.8).curveTo(-63.9,25.5,-66.1,25.8).curveTo(-69.9,26.5,-71.7,26.8).curveTo(-75.7,27.4,-77.6,27.7).curveTo(-81.5,28.4,-83.4,28.8).curveTo(-85.2,29,-88.8,29.6);
	this.shape_54.setTransform(47.9083,118.3197);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.beginFill().beginStroke("#FFFFFF").moveTo(89.5,-30.7).curveTo(88.2,-29.5,86.9,-28.6).curveTo(84,-26.7,80.2,-25.4).curveTo(79,-25,77.8,-24.7).curveTo(76,-24.3,72.8,-23.9).curveTo(72.1,-23.8,71,-23.7).curveTo(69.7,-23.7,69.2,-23.7).curveTo(67.7,-23.5,65.8,-23.5).curveTo(64.7,-23.5,62.2,-23.5).curveTo(59,-23.6,55.1,-23.8).curveTo(53.2,-23.9,52.3,-24).lineTo(48.5,-24.4).curveTo(47.9,-24.5,45,-24.6).curveTo(42.8,-24.9,41.7,-25).curveTo(39.7,-25.2,38.7,-25.3).lineTo(26.2,-26.5).curveTo(23.7,-26.8,22.4,-26.9).curveTo(21.4,-27,20.8,-27.1).curveTo(18.2,-27.2,16.8,-27.3).curveTo(15.4,-27.4,13.2,-27.5).curveTo(10,-27.7,9.7,-27.7).curveTo(6.4,-27.9,2.3,-27.9).curveTo(-1.3,-27.7,-4.4,-27.2).curveTo(-8.2,-26.6,-10.3,-25.9).curveTo(-13,-25,-14.4,-23.6).curveTo(-16.5,-21.5,-15.1,-18.8).curveTo(-14.1,-17.1,-12,-15.3).curveTo(-10,-13.6,-6.7,-11.5).curveTo(-4.8,-10.3,-1.2,-7.9).curveTo(1,-6.5,2.1,-5.6).curveTo(3.9,-4.2,5.3,-3).curveTo(7.5,-0.9,8.4,1).curveTo(9.6,4,7.5,6.6).curveTo(6.4,7.8,4.9,8.8).curveTo(3.7,9.6,1.9,10.5).curveTo(-2,12.4,-8.2,14.3).curveTo(-14.1,16.1,-21.7,18).curveTo(-28.1,19.5,-37.6,21.4).curveTo(-42.1,22.3,-46.7,23.1).curveTo(-48.2,23.5,-51.1,24).curveTo(-51.3,24,-51.6,24.1).curveTo(-54.3,24.6,-55.4,24.8).curveTo(-59.1,25.4,-60.8,25.8).curveTo(-65.1,26.4,-67.2,26.8).curveTo(-71.1,27.5,-72.9,27.7).curveTo(-76.8,28.3,-78.7,28.7).curveTo(-82.7,29.4,-84.6,29.7).curveTo(-86.4,29.9,-89.9,30.5);
	this.shape_55.setTransform(49.0833,117.3593);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.beginFill().beginStroke("#FFFFFF").moveTo(90.8,-32.2).curveTo(90.5,-31.8,90.2,-31.4).curveTo(88.2,-28.9,85.6,-27.1).curveTo(82.8,-25.2,78.9,-24).curveTo(77.8,-23.6,76.5,-23.3).curveTo(74.7,-22.9,71.6,-22.4).curveTo(70.9,-22.3,69.8,-22.3).curveTo(68.5,-22.2,68,-22.2).curveTo(66.4,-22,64.5,-22).curveTo(63.5,-22,60.9,-22.1).curveTo(57.7,-22.1,53.9,-22.4).curveTo(52,-22.5,51,-22.5).lineTo(47.2,-23).curveTo(46.6,-23,43.8,-23.2).curveTo(41.6,-23.4,40.4,-23.6).curveTo(38.5,-23.8,37.5,-23.9).lineTo(25,-25.1).curveTo(22.5,-25.3,21.2,-25.5).curveTo(20.1,-25.6,19.5,-25.7).curveTo(16.9,-25.8,15.5,-25.9).curveTo(14.1,-26,12,-26.1).curveTo(8.8,-26.3,8.4,-26.3).curveTo(5.1,-26.4,1,-26.4).curveTo(-2.6,-26.2,-5.7,-25.8).curveTo(-9.4,-25.2,-11.5,-24.4).curveTo(-14.2,-23.5,-15.7,-22.1).curveTo(-17.8,-20.1,-16.3,-17.3).curveTo(-15.4,-15.6,-13.3,-13.9).curveTo(-11.2,-12.2,-7.9,-10.1).curveTo(-6.1,-8.9,-2.5,-6.5).curveTo(-0.3,-5.1,0.9,-4.2).curveTo(2.7,-2.8,4,-1.6).curveTo(6.2,0.6,7.1,2.5).curveTo(8.4,5.4,6.3,8).curveTo(5.2,9.3,3.6,10.3).curveTo(2.5,11.1,0.6,12).curveTo(-3.2,13.9,-9.4,15.8).curveTo(-15.3,17.6,-23,19.4).curveTo(-29.3,20.9,-38.9,22.8).curveTo(-43.4,23.8,-47.9,24.6).curveTo(-49.5,24.9,-52.3,25.4).curveTo(-52.6,25.5,-52.9,25.5).curveTo(-55.5,26,-56.7,26.2).curveTo(-60.3,26.9,-62.1,27.2).curveTo(-66.3,27.9,-68.5,28.2).curveTo(-72.3,28.9,-74.1,29.2).curveTo(-78.1,29.8,-80,30.1).curveTo(-83.9,30.8,-85.8,31.2).curveTo(-87.6,31.4,-91.2,32);
	this.shape_56.setTransform(50.3333,115.9215);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.beginFill().beginStroke("#FFFFFF").moveTo(91.9,-34.1).curveTo(90.6,-31.5,89,-29.5).curveTo(87.1,-27,84.5,-25.2).curveTo(81.6,-23.3,77.8,-22.1).curveTo(76.6,-21.7,75.4,-21.4).curveTo(73.6,-21,70.4,-20.5).curveTo(69.7,-20.4,68.6,-20.4).curveTo(67.3,-20.3,66.8,-20.3).curveTo(65.3,-20.1,63.4,-20.1).curveTo(62.3,-20.1,59.8,-20.2).curveTo(56.6,-20.2,52.7,-20.5).curveTo(50.8,-20.6,49.9,-20.6).lineTo(46.1,-21.1).curveTo(45.5,-21.1,42.6,-21.3).curveTo(40.4,-21.5,39.3,-21.7).curveTo(37.3,-21.9,36.3,-22).lineTo(23.8,-23.2).curveTo(21.3,-23.4,20,-23.6).curveTo(19,-23.7,18.4,-23.8).curveTo(15.8,-23.9,14.4,-24).curveTo(13,-24.1,10.8,-24.2).curveTo(7.6,-24.4,7.3,-24.4).curveTo(4,-24.5,-0.1,-24.5).curveTo(-3.7,-24.3,-6.8,-23.9).curveTo(-10.6,-23.3,-12.7,-22.5).curveTo(-15.4,-21.6,-16.8,-20.2).curveTo(-18.9,-18.2,-17.5,-15.4).curveTo(-16.5,-13.7,-14.4,-12).curveTo(-12.4,-10.3,-9.1,-8.2).curveTo(-7.2,-7,-3.6,-4.6).curveTo(-1.4,-3.2,-0.3,-2.3).curveTo(1.5,-0.9,2.9,0.3).curveTo(5.1,2.5,6,4.4).curveTo(7.2,7.3,5.1,9.9).curveTo(4,11.2,2.5,12.2).curveTo(1.3,13,-0.5,13.9).curveTo(-4.4,15.8,-10.6,17.7).curveTo(-16.5,19.5,-24.1,21.3).curveTo(-30.5,22.8,-40,24.7).curveTo(-44.5,25.7,-49.1,26.5).curveTo(-50.6,26.8,-53.5,27.3).curveTo(-53.7,27.4,-54,27.4).curveTo(-56.7,27.9,-57.8,28.1).curveTo(-61.5,28.8,-63.2,29.1).curveTo(-67.5,29.8,-69.6,30.1).curveTo(-73.5,30.8,-75.3,31.1).curveTo(-79.2,31.7,-81.1,32).curveTo(-85.1,32.7,-87,33.1).curveTo(-88.8,33.3,-92.3,33.9);
	this.shape_57.setTransform(51.4833,114.0347);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.beginFill().beginStroke("#FFFFFF").moveTo(92.8,-36.1).lineTo(92.6,-35.8).curveTo(91.8,-33.6,91.5,-32.8).curveTo(89.9,-29.7,88.2,-27.5).curveTo(86.2,-24.9,83.6,-23.2).curveTo(80.8,-21.3,76.9,-20).curveTo(75.8,-19.6,74.5,-19.3).curveTo(72.7,-18.9,69.6,-18.5).curveTo(68.9,-18.4,67.8,-18.3).curveTo(66.5,-18.3,66,-18.3).curveTo(64.4,-18.1,62.5,-18.1).curveTo(61.5,-18.1,58.9,-18.1).curveTo(55.7,-18.2,51.9,-18.4).curveTo(50,-18.5,49,-18.6).lineTo(45.2,-19).curveTo(44.6,-19.1,41.8,-19.2).curveTo(39.6,-19.5,38.4,-19.6).curveTo(36.5,-19.8,35.5,-19.9).lineTo(23,-21.1).curveTo(20.5,-21.4,19.2,-21.5).curveTo(18.1,-21.6,17.5,-21.7).curveTo(14.9,-21.8,13.5,-21.9).curveTo(12.1,-22,10,-22.1).curveTo(6.8,-22.3,6.4,-22.3).curveTo(3.1,-22.5,-1,-22.5).curveTo(-4.6,-22.3,-7.7,-21.8).curveTo(-11.4,-21.2,-13.5,-20.5).curveTo(-16.2,-19.6,-17.7,-18.2).curveTo(-19.8,-16.1,-18.3,-13.4).curveTo(-17.4,-11.7,-15.3,-9.9).curveTo(-13.2,-8.2,-9.9,-6.1).curveTo(-8.1,-4.9,-4.5,-2.5).curveTo(-2.3,-1.1,-1.1,-0.2).curveTo(0.7,1.2,2,2.4).curveTo(4.2,4.5,5.1,6.4).curveTo(6.4,9.4,4.3,12).curveTo(3.2,13.2,1.6,14.2).curveTo(0.5,15,-1.4,15.9).curveTo(-5.2,17.8,-11.4,19.7).curveTo(-17.3,21.5,-25,23.4).curveTo(-31.3,24.9,-40.9,26.8).curveTo(-45.4,27.7,-49.9,28.5).curveTo(-51.5,28.9,-54.3,29.4).curveTo(-54.6,29.4,-54.9,29.5).curveTo(-57.5,30,-58.7,30.2).curveTo(-62.3,30.8,-64.1,31.2).curveTo(-68.3,31.8,-70.5,32.2).curveTo(-74.3,32.9,-76.1,33.1).curveTo(-80.1,33.7,-82,34.1).curveTo(-85.9,34.8,-87.8,35.1).curveTo(-89.6,35.3,-93.2,35.9);
	this.shape_58.setTransform(52.3004,111.9975);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.beginFill().beginStroke("#FFFFFF").moveTo(93.8,-38.6).curveTo(93.4,-38.1,93.2,-37.2).curveTo(92.7,-35.8,92.7,-35.8).lineTo(91.7,-33.1).curveTo(90.9,-30.9,90.6,-30.1).curveTo(89,-27,87.3,-24.8).curveTo(85.3,-22.2,82.7,-20.5).curveTo(79.9,-18.6,76,-17.3).curveTo(74.9,-16.9,73.6,-16.6).curveTo(71.8,-16.2,68.7,-15.8).curveTo(68,-15.7,66.9,-15.6).curveTo(65.6,-15.6,65.1,-15.6).curveTo(63.5,-15.4,61.6,-15.4).curveTo(60.6,-15.4,58,-15.4).curveTo(54.8,-15.5,51,-15.7).curveTo(49.1,-15.8,48.1,-15.9).lineTo(44.3,-16.3).curveTo(43.7,-16.4,40.9,-16.5).curveTo(38.7,-16.8,37.5,-16.9).curveTo(35.6,-17.1,34.6,-17.2).lineTo(22.1,-18.4).curveTo(19.6,-18.7,18.3,-18.8).curveTo(17.2,-18.9,16.6,-19).curveTo(14,-19.1,12.6,-19.2).curveTo(11.2,-19.3,9.1,-19.4).curveTo(5.9,-19.6,5.5,-19.6).curveTo(2.2,-19.8,-1.9,-19.8).curveTo(-5.5,-19.6,-8.6,-19.1).curveTo(-12.3,-18.5,-14.4,-17.8).curveTo(-17.1,-16.9,-18.6,-15.5).curveTo(-20.7,-13.4,-19.2,-10.7).curveTo(-18.3,-9,-16.2,-7.2).curveTo(-14.1,-5.5,-10.8,-3.4).curveTo(-9,-2.2,-5.4,0.2).curveTo(-3.2,1.6,-2,2.5).curveTo(-0.2,3.9,1.1,5.1).curveTo(3.3,7.2,4.2,9.1).curveTo(5.5,12.1,3.4,14.7).curveTo(2.3,15.9,0.7,16.9).curveTo(-0.4,17.7,-2.3,18.6).curveTo(-6.1,20.5,-12.3,22.4).curveTo(-18.2,24.2,-25.9,26.1).curveTo(-32.2,27.6,-41.8,29.5).curveTo(-46.3,30.4,-50.8,31.2).curveTo(-52.4,31.6,-55.2,32.1).curveTo(-55.5,32.1,-55.8,32.2).curveTo(-58.4,32.7,-59.6,32.9).curveTo(-63.2,33.5,-65,33.9).curveTo(-69.2,34.5,-71.4,34.9).curveTo(-75.2,35.6,-77,35.8).curveTo(-81,36.4,-82.9,36.8).curveTo(-86.8,37.5,-88.7,37.8).curveTo(-90.5,38,-94.1,38.6);
	this.shape_59.setTransform(53.2381,109.2965);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.beginFill().beginStroke("#FFFFFF").moveTo(68.8,-34.3).curveTo(68.5,-33.8,68.3,-32.9).curveTo(67.8,-31.5,67.8,-31.5).lineTo(66.7,-28.8).curveTo(66,-26.6,65.6,-25.8).curveTo(64.1,-22.7,62.3,-20.5).curveTo(60.4,-17.9,57.8,-16.2).curveTo(54.9,-14.3,51.1,-13).curveTo(49.9,-12.6,48.7,-12.3).curveTo(46.9,-11.9,43.7,-11.5).curveTo(43,-11.4,41.9,-11.3).curveTo(40.6,-11.3,40.1,-11.3).curveTo(38.6,-11.1,36.7,-11.1).curveTo(35.6,-11.1,33.1,-11.1).curveTo(29.9,-11.2,26,-11.4).curveTo(24.1,-11.5,23.2,-11.6).lineTo(19.4,-12).curveTo(18.8,-12.1,15.9,-12.2).curveTo(13.7,-12.5,12.6,-12.6).curveTo(10.6,-12.8,9.6,-12.9).lineTo(-2.9,-14.1).curveTo(-5.4,-14.4,-6.7,-14.5).curveTo(-7.7,-14.6,-8.3,-14.7).curveTo(-10.9,-14.8,-12.3,-14.9).curveTo(-13.7,-15,-15.9,-15.1).curveTo(-19.1,-15.3,-19.4,-15.3).curveTo(-22.7,-15.5,-26.8,-15.5).curveTo(-30.4,-15.3,-33.5,-14.8).curveTo(-37.3,-14.2,-39.4,-13.5).curveTo(-42.1,-12.6,-43.5,-11.2).curveTo(-45.6,-9.1,-44.2,-6.4).curveTo(-43.2,-4.7,-41.1,-2.9).curveTo(-39.1,-1.2,-35.8,0.9).curveTo(-33.9,2.1,-30.3,4.5).curveTo(-28.1,5.9,-27,6.8).curveTo(-25.2,8.2,-23.8,9.4).curveTo(-21.6,11.5,-20.7,13.4).curveTo(-19.5,16.4,-21.6,19).curveTo(-22.7,20.2,-24.2,21.2).curveTo(-25.4,22,-27.2,22.9).curveTo(-31.1,24.8,-37.3,26.7).curveTo(-43.2,28.5,-50.8,30.4).curveTo(-57.2,31.9,-66.7,33.8).curveTo(-67.9,34,-69.2,34.3);
	this.shape_60.setTransform(78.1565,104.975);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.beginFill().beginStroke("#FFFFFF").moveTo(63.8,-33.2).curveTo(63.5,-32.7,63.3,-31.8).curveTo(62.8,-30.5,62.8,-30.4).lineTo(61.7,-27.7).curveTo(61,-25.6,60.6,-24.8).curveTo(59.1,-21.7,57.3,-19.4).curveTo(55.4,-16.9,52.8,-15.1).curveTo(49.9,-13.2,46.1,-12).curveTo(44.9,-11.6,43.7,-11.3).curveTo(41.9,-10.9,38.7,-10.4).curveTo(38,-10.3,36.9,-10.3).curveTo(35.6,-10.2,35.1,-10.2).curveTo(33.6,-10,31.7,-10).curveTo(30.6,-10,28.1,-10.1).curveTo(24.9,-10.1,21,-10.4).curveTo(19.1,-10.5,18.2,-10.5).lineTo(14.4,-11).curveTo(13.8,-11,10.9,-11.2).curveTo(8.7,-11.4,7.6,-11.6).curveTo(5.6,-11.8,4.6,-11.9).lineTo(-7.9,-13.1).curveTo(-10.4,-13.3,-11.7,-13.5).curveTo(-12.7,-13.6,-13.3,-13.7).curveTo(-15.9,-13.8,-17.3,-13.9).curveTo(-18.7,-14,-20.9,-14.1).curveTo(-24.1,-14.3,-24.4,-14.3).curveTo(-27.7,-14.4,-31.8,-14.4).curveTo(-35.4,-14.2,-38.5,-13.8).curveTo(-42.3,-13.2,-44.4,-12.4).curveTo(-47.1,-11.5,-48.5,-10.1).curveTo(-50.6,-8.1,-49.2,-5.3).curveTo(-48.2,-3.6,-46.1,-1.9).curveTo(-44.1,-0.2,-40.8,1.9).curveTo(-38.9,3.1,-35.3,5.5).curveTo(-33.1,6.9,-32,7.8).curveTo(-30.2,9.2,-28.8,10.4).curveTo(-26.6,12.6,-25.7,14.5).curveTo(-24.5,17.4,-26.6,20).curveTo(-27.7,21.3,-29.2,22.3).curveTo(-30.4,23.1,-32.2,24).curveTo(-36.1,25.9,-42.3,27.8).curveTo(-48.2,29.6,-55.8,31.4).curveTo(-59.5,32.3,-64.2,33.3);
	this.shape_61.setTransform(83.1534,103.9447);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.beginFill().beginStroke("#FFFFFF").moveTo(58.4,-32).curveTo(58,-31.5,57.8,-30.6).curveTo(57.3,-29.2,57.3,-29.2).lineTo(56.3,-26.5).curveTo(55.5,-24.3,55.2,-23.5).curveTo(53.6,-20.4,51.9,-18.2).curveTo(49.9,-15.6,47.3,-13.9).curveTo(44.5,-12,40.6,-10.7).curveTo(39.5,-10.3,38.2,-10).curveTo(36.4,-9.6,33.3,-9.2).curveTo(32.6,-9.1,31.5,-9).curveTo(30.2,-9,29.7,-9).curveTo(28.1,-8.8,26.2,-8.8).curveTo(25.2,-8.8,22.6,-8.8).curveTo(19.4,-8.9,15.6,-9.1).curveTo(13.7,-9.2,12.7,-9.3).lineTo(8.9,-9.7).curveTo(8.3,-9.8,5.5,-9.9).curveTo(3.3,-10.2,2.1,-10.3).curveTo(0.2,-10.5,-0.8,-10.6).lineTo(-13.3,-11.8).curveTo(-15.8,-12.1,-17.1,-12.2).curveTo(-18.2,-12.3,-18.8,-12.4).curveTo(-21.4,-12.5,-22.8,-12.6).curveTo(-24.2,-12.7,-26.3,-12.8).curveTo(-29.5,-13,-29.9,-13).curveTo(-33.2,-13.2,-37.3,-13.2).curveTo(-40.9,-13,-44,-12.5).curveTo(-47.7,-11.9,-49.8,-11.2).curveTo(-52.5,-10.3,-54,-8.9).curveTo(-56.1,-6.8,-54.6,-4.1).curveTo(-53.7,-2.4,-51.6,-0.6).curveTo(-49.5,1.1,-46.2,3.2).curveTo(-44.4,4.4,-40.8,6.8).curveTo(-38.6,8.2,-37.4,9.1).curveTo(-35.6,10.5,-34.3,11.7).curveTo(-32.1,13.8,-31.2,15.7).curveTo(-29.9,18.7,-32,21.3).curveTo(-33.1,22.5,-34.7,23.5).curveTo(-35.8,24.3,-37.7,25.2).curveTo(-41.5,27.1,-47.7,29).curveTo(-52.6,30.5,-58.6,32);
	this.shape_62.setTransform(88.6439,102.6925);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-30.8).curveTo(56.5,-30.3,56.3,-29.4).curveTo(55.8,-28,55.8,-28).lineTo(54.7,-25.3).curveTo(54,-23.1,53.6,-22.3).curveTo(52.1,-19.2,50.3,-17).curveTo(48.4,-14.4,45.8,-12.7).curveTo(42.9,-10.8,39.1,-9.5).curveTo(37.9,-9.1,36.7,-8.8).curveTo(34.9,-8.4,31.7,-8).curveTo(31,-7.9,29.9,-7.8).curveTo(28.6,-7.8,28.1,-7.8).curveTo(26.6,-7.6,24.7,-7.6).curveTo(23.6,-7.6,21.1,-7.6).curveTo(17.9,-7.7,14,-7.9).curveTo(12.1,-8,11.2,-8.1).lineTo(7.4,-8.5).curveTo(6.8,-8.6,3.9,-8.7).curveTo(1.7,-9,0.6,-9.1).curveTo(-1.4,-9.3,-2.4,-9.4).lineTo(-14.9,-10.6).curveTo(-17.4,-10.9,-18.7,-11).curveTo(-19.7,-11.1,-20.3,-11.2).curveTo(-22.9,-11.3,-24.3,-11.4).curveTo(-25.7,-11.5,-27.9,-11.6).curveTo(-31.1,-11.8,-31.4,-11.8).curveTo(-34.7,-12,-38.8,-12).curveTo(-42.4,-11.8,-45.5,-11.3).curveTo(-49.3,-10.7,-51.4,-10).curveTo(-54.1,-9.1,-55.5,-7.7).curveTo(-57.6,-5.6,-56.2,-2.9).curveTo(-55.2,-1.2,-53.1,0.6).curveTo(-51.1,2.3,-47.8,4.4).curveTo(-45.9,5.6,-42.3,8).curveTo(-40.1,9.4,-39,10.3).curveTo(-37.2,11.7,-35.8,12.9).curveTo(-33.6,15,-32.7,16.9).curveTo(-31.5,19.9,-33.6,22.5).curveTo(-34.7,23.7,-36.2,24.7).curveTo(-37.4,25.5,-39.2,26.4).curveTo(-43.1,28.3,-49.3,30.2).curveTo(-50.2,30.5,-51.2,30.8);
	this.shape_63.setTransform(90.1587,101.4769);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-30).curveTo(56.5,-29.5,56.3,-28.6).curveTo(55.8,-27.2,55.8,-27.2).lineTo(54.7,-24.5).curveTo(54,-22.3,53.6,-21.5).curveTo(52.1,-18.4,50.3,-16.2).curveTo(48.4,-13.6,45.8,-11.9).curveTo(42.9,-10,39.1,-8.7).curveTo(37.9,-8.3,36.7,-8).curveTo(34.9,-7.6,31.7,-7.2).curveTo(31,-7.1,29.9,-7).curveTo(28.6,-7,28.1,-7).curveTo(26.6,-6.8,24.7,-6.8).curveTo(23.6,-6.8,21.1,-6.8).curveTo(17.9,-6.9,14,-7.1).curveTo(12.1,-7.2,11.2,-7.3).lineTo(7.4,-7.7).curveTo(6.8,-7.8,3.9,-7.9).curveTo(1.7,-8.2,0.6,-8.3).curveTo(-1.4,-8.5,-2.4,-8.6).lineTo(-14.9,-9.8).curveTo(-17.4,-10.1,-18.7,-10.2).curveTo(-19.7,-10.3,-20.3,-10.4).curveTo(-22.9,-10.5,-24.3,-10.6).curveTo(-25.7,-10.7,-27.9,-10.8).curveTo(-31.1,-11,-31.4,-11).curveTo(-34.7,-11.2,-38.8,-11.2).curveTo(-42.4,-11,-45.5,-10.5).curveTo(-49.3,-9.9,-51.4,-9.2).curveTo(-54.1,-8.3,-55.5,-6.9).curveTo(-57.6,-4.8,-56.2,-2.1).curveTo(-55.2,-0.4,-53.1,1.4).curveTo(-51.1,3.1,-47.8,5.2).curveTo(-45.9,6.4,-42.3,8.8).curveTo(-40.1,10.2,-39,11.1).curveTo(-37.2,12.5,-35.8,13.7).curveTo(-33.6,15.8,-32.7,17.7).curveTo(-31.5,20.7,-33.6,23.3).curveTo(-34.7,24.5,-36.2,25.5).curveTo(-37.4,26.3,-39.2,27.2).curveTo(-42,28.6,-46.2,30);
	this.shape_64.setTransform(90.1587,100.6867);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-27.7).curveTo(56.5,-27.2,56.3,-26.3).curveTo(55.8,-25,55.8,-24.9).lineTo(54.7,-22.2).curveTo(54,-20.1,53.6,-19.3).curveTo(52.1,-16.2,50.3,-13.9).curveTo(48.4,-11.4,45.8,-9.6).curveTo(42.9,-7.7,39.1,-6.5).curveTo(37.9,-6.1,36.7,-5.8).curveTo(34.9,-5.4,31.7,-4.9).curveTo(31,-4.8,29.9,-4.8).curveTo(28.6,-4.7,28.1,-4.7).curveTo(26.6,-4.5,24.7,-4.5).curveTo(23.6,-4.5,21.1,-4.6).curveTo(17.9,-4.6,14,-4.9).curveTo(12.1,-5,11.2,-5).lineTo(7.4,-5.5).curveTo(6.8,-5.5,3.9,-5.7).curveTo(1.7,-5.9,0.6,-6.1).curveTo(-1.4,-6.3,-2.4,-6.4).lineTo(-14.9,-7.6).curveTo(-17.4,-7.8,-18.7,-8).curveTo(-19.7,-8.1,-20.3,-8.2).curveTo(-22.9,-8.3,-24.3,-8.4).curveTo(-25.7,-8.5,-27.9,-8.6).curveTo(-31.1,-8.8,-31.4,-8.8).curveTo(-34.7,-8.9,-38.8,-8.9).curveTo(-42.4,-8.7,-45.5,-8.3).curveTo(-49.3,-7.7,-51.4,-6.9).curveTo(-54.1,-6,-55.5,-4.6).curveTo(-57.6,-2.6,-56.2,0.2).curveTo(-55.2,1.9,-53.1,3.6).curveTo(-51.1,5.3,-47.8,7.4).curveTo(-45.9,8.6,-42.3,11).curveTo(-40.1,12.4,-39,13.3).curveTo(-37.2,14.7,-35.8,15.9).curveTo(-33.6,18.1,-32.7,20).curveTo(-31.5,22.9,-33.6,25.5).curveTo(-34.6,26.7,-36.2,27.7);
	this.shape_65.setTransform(90.1587,98.4375);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-23.2).curveTo(56.5,-22.7,56.3,-21.8).curveTo(55.8,-20.4,55.8,-20.4).lineTo(54.7,-17.7).curveTo(54,-15.5,53.6,-14.7).curveTo(52.1,-11.6,50.3,-9.4).curveTo(48.4,-6.8,45.8,-5.1).curveTo(42.9,-3.2,39.1,-1.9).curveTo(37.9,-1.5,36.7,-1.2).curveTo(34.9,-0.8,31.7,-0.4).curveTo(31,-0.3,29.9,-0.2).curveTo(28.6,-0.2,28.1,-0.2).curveTo(26.6,0,24.7,0).curveTo(23.6,0,21.1,-0).curveTo(17.9,-0.1,14,-0.3).curveTo(12.1,-0.4,11.2,-0.5).lineTo(7.4,-0.9).curveTo(6.8,-1,3.9,-1.1).curveTo(1.7,-1.4,0.6,-1.5).curveTo(-1.4,-1.7,-2.4,-1.8).lineTo(-14.9,-3).curveTo(-17.4,-3.3,-18.7,-3.4).curveTo(-19.7,-3.5,-20.3,-3.6).curveTo(-22.9,-3.7,-24.3,-3.8).curveTo(-25.7,-3.9,-27.9,-4).curveTo(-31.1,-4.2,-31.4,-4.2).curveTo(-34.7,-4.4,-38.8,-4.4).curveTo(-42.4,-4.2,-45.5,-3.7).curveTo(-49.3,-3.1,-51.4,-2.4).curveTo(-54.1,-1.5,-55.5,-0.1).curveTo(-57.6,2,-56.2,4.7).curveTo(-55.2,6.4,-53.1,8.2).curveTo(-51.1,9.9,-47.8,12).curveTo(-45.9,13.2,-42.3,15.6).curveTo(-40.1,17,-39,17.9).curveTo(-37.2,19.3,-35.8,20.5).curveTo(-34.4,21.9,-33.5,23.2);
	this.shape_66.setTransform(90.1587,93.875);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-20.2).curveTo(56.5,-19.7,56.3,-18.8).curveTo(55.8,-17.4,55.8,-17.4).lineTo(54.7,-14.7).curveTo(54,-12.5,53.6,-11.7).curveTo(52.1,-8.6,50.3,-6.4).curveTo(48.4,-3.8,45.8,-2.1).curveTo(42.9,-0.2,39.1,1.1).curveTo(37.9,1.5,36.7,1.8).curveTo(34.9,2.2,31.7,2.6).curveTo(31,2.7,29.9,2.8).curveTo(28.6,2.8,28.1,2.8).curveTo(26.6,3,24.7,3).curveTo(23.6,3,21.1,3).curveTo(17.9,2.9,14,2.7).curveTo(12.1,2.6,11.2,2.5).lineTo(7.4,2.1).curveTo(6.8,2,3.9,1.9).curveTo(1.7,1.6,0.6,1.5).curveTo(-1.4,1.3,-2.4,1.2).lineTo(-14.9,-0).curveTo(-17.4,-0.3,-18.7,-0.4).curveTo(-19.7,-0.5,-20.3,-0.6).curveTo(-22.9,-0.7,-24.3,-0.8).curveTo(-25.7,-0.9,-27.9,-1).curveTo(-31.1,-1.2,-31.4,-1.2).curveTo(-34.7,-1.4,-38.8,-1.4).curveTo(-42.4,-1.2,-45.5,-0.7).curveTo(-49.3,-0.1,-51.4,0.6).curveTo(-54.1,1.5,-55.5,2.9).curveTo(-57.6,5,-56.2,7.7).curveTo(-55.2,9.4,-53.1,11.2).curveTo(-51.1,12.9,-47.8,15).curveTo(-45.9,16.2,-42.3,18.6).curveTo(-40.9,19.5,-39.9,20.2);
	this.shape_67.setTransform(90.1587,90.875);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-17.1).curveTo(56.5,-16.6,56.3,-15.7).curveTo(55.8,-14.4,55.8,-14.3).lineTo(54.7,-11.6).curveTo(54,-9.5,53.6,-8.7).curveTo(52.1,-5.6,50.3,-3.3).curveTo(48.4,-0.8,45.8,1).curveTo(42.9,2.9,39.1,4.1).curveTo(37.9,4.5,36.7,4.8).curveTo(34.9,5.2,31.7,5.7).curveTo(31,5.8,29.9,5.8).curveTo(28.6,5.9,28.1,5.9).curveTo(26.6,6.1,24.7,6.1).curveTo(23.6,6.1,21.1,6).curveTo(17.9,6,14,5.7).curveTo(12.1,5.6,11.2,5.6).lineTo(7.4,5.1).curveTo(6.8,5.1,3.9,4.9).curveTo(1.7,4.7,0.6,4.5).curveTo(-1.4,4.3,-2.4,4.2).lineTo(-14.9,3).curveTo(-17.4,2.8,-18.7,2.6).curveTo(-19.7,2.5,-20.3,2.4).curveTo(-22.9,2.3,-24.3,2.2).curveTo(-25.7,2.1,-27.9,2).curveTo(-31.1,1.8,-31.4,1.8).curveTo(-34.7,1.7,-38.8,1.7).curveTo(-42.4,1.9,-45.5,2.3).curveTo(-49.3,2.9,-51.4,3.7).curveTo(-54.1,4.6,-55.5,6).curveTo(-57.6,8,-56.2,10.8).curveTo(-55.2,12.5,-53.1,14.2).curveTo(-51.5,15.6,-49,17.2);
	this.shape_68.setTransform(90.1587,87.8337);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.beginFill().beginStroke("#FFFFFF").moveTo(56.8,-14.1).curveTo(56.5,-13.6,56.3,-12.7).curveTo(55.8,-11.3,55.8,-11.3).lineTo(54.7,-8.6).curveTo(54,-6.4,53.6,-5.6).curveTo(52.1,-2.5,50.3,-0.3).curveTo(48.4,2.3,45.8,4).curveTo(42.9,5.9,39.1,7.2).curveTo(37.9,7.6,36.7,7.9).curveTo(34.9,8.3,31.7,8.7).curveTo(31,8.8,29.9,8.9).curveTo(28.6,8.9,28.1,8.9).curveTo(26.6,9.1,24.7,9.1).curveTo(23.6,9.1,21.1,9.1).curveTo(17.9,9,14,8.8).curveTo(12.1,8.7,11.2,8.6).lineTo(7.4,8.2).curveTo(6.8,8.1,3.9,8).curveTo(1.7,7.7,0.6,7.6).curveTo(-1.4,7.4,-2.4,7.3).lineTo(-14.9,6.1).curveTo(-17.4,5.8,-18.7,5.7).curveTo(-19.7,5.6,-20.3,5.5).curveTo(-22.9,5.4,-24.3,5.3).curveTo(-25.7,5.2,-27.9,5.1).curveTo(-31.1,4.9,-31.4,4.9).curveTo(-34.7,4.7,-38.8,4.7).curveTo(-42.4,4.9,-45.5,5.4).curveTo(-49.3,6,-51.4,6.7).curveTo(-54.1,7.6,-55.5,9).curveTo(-57.6,11.1,-56.2,13.8).curveTo(-56,14.1,-55.9,14.3);
	this.shape_69.setTransform(90.1587,84.7631);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.beginFill().beginStroke("#FFFFFF").moveTo(53.5,-11.6).curveTo(53.2,-11.1,53,-10.2).curveTo(52.5,-8.9,52.5,-8.8).lineTo(51.4,-6.1).curveTo(50.7,-4,50.3,-3.2).curveTo(48.8,-0.1,47,2.2).curveTo(45.1,4.7,42.5,6.5).curveTo(39.6,8.4,35.8,9.6).curveTo(34.6,10,33.4,10.3).curveTo(31.6,10.7,28.4,11.2).curveTo(27.7,11.3,26.6,11.3).curveTo(25.3,11.4,24.8,11.4).curveTo(23.3,11.6,21.4,11.6).curveTo(20.3,11.6,17.8,11.5).curveTo(14.6,11.5,10.7,11.2).curveTo(8.8,11.1,7.9,11.1).lineTo(4.1,10.6).curveTo(3.5,10.6,0.6,10.4).curveTo(-1.6,10.2,-2.7,10).curveTo(-4.7,9.8,-5.7,9.7).lineTo(-18.2,8.5).curveTo(-20.7,8.3,-22,8.1).curveTo(-23,8,-23.6,7.9).curveTo(-26.2,7.8,-27.6,7.7).curveTo(-29,7.6,-31.2,7.5).curveTo(-34.4,7.3,-34.7,7.3).curveTo(-38,7.2,-42.1,7.2).curveTo(-45.7,7.4,-48.8,7.8).curveTo(-51.6,8.3,-53.5,8.8);
	this.shape_70.setTransform(93.4548,82.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.beginFill().beginStroke("#FFFFFF").moveTo(48.5,-11.6).curveTo(48.2,-11.1,48,-10.2).curveTo(47.5,-8.9,47.5,-8.8).lineTo(46.4,-6.1).curveTo(45.7,-4,45.3,-3.2).curveTo(43.8,-0.1,42,2.2).curveTo(40.1,4.7,37.5,6.5).curveTo(34.6,8.4,30.8,9.6).curveTo(29.6,10,28.4,10.3).curveTo(26.6,10.7,23.4,11.2).curveTo(22.7,11.3,21.6,11.3).curveTo(20.3,11.4,19.8,11.4).curveTo(18.3,11.6,16.4,11.6).curveTo(15.3,11.6,12.8,11.5).curveTo(9.6,11.5,5.7,11.2).curveTo(3.8,11.1,2.9,11.1).lineTo(-0.9,10.6).curveTo(-1.5,10.6,-4.4,10.4).curveTo(-6.6,10.2,-7.7,10).curveTo(-9.7,9.8,-10.7,9.7).lineTo(-23.2,8.5).curveTo(-25.7,8.3,-27,8.1).curveTo(-28,8,-28.6,7.9).curveTo(-31.2,7.8,-32.6,7.7).curveTo(-34,7.6,-36.2,7.5).curveTo(-39.4,7.3,-39.7,7.3).curveTo(-43,7.2,-47.1,7.2).curveTo(-47.8,7.2,-48.5,7.3);
	this.shape_71.setTransform(98.4548,82.3);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.beginFill().beginStroke("#FFFFFF").moveTo(42.5,-11.6).curveTo(42.2,-11.1,42,-10.2).curveTo(41.5,-8.9,41.5,-8.8).lineTo(40.4,-6.1).curveTo(39.7,-4,39.3,-3.2).curveTo(37.8,-0.1,36,2.2).curveTo(34.1,4.7,31.5,6.5).curveTo(28.6,8.4,24.8,9.6).curveTo(23.6,10,22.4,10.3).curveTo(20.6,10.7,17.4,11.2).curveTo(16.7,11.3,15.6,11.3).curveTo(14.3,11.4,13.8,11.4).curveTo(12.3,11.6,10.4,11.6).curveTo(9.3,11.6,6.8,11.5).curveTo(3.6,11.5,-0.3,11.2).curveTo(-2.2,11.1,-3.1,11.1).lineTo(-6.9,10.6).curveTo(-7.5,10.6,-10.4,10.4).curveTo(-12.6,10.2,-13.7,10).curveTo(-15.7,9.8,-16.7,9.7).lineTo(-29.2,8.5).curveTo(-31.7,8.3,-33,8.1).curveTo(-34,8,-34.6,7.9).curveTo(-37.2,7.8,-38.6,7.7).curveTo(-40,7.6,-42.2,7.5).curveTo(-42.3,7.5,-42.5,7.5);
	this.shape_72.setTransform(104.4548,82.3);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.beginFill().beginStroke("#FFFFFF").moveTo(37.5,-11.6).curveTo(37.2,-11.1,37,-10.2).curveTo(36.5,-8.9,36.5,-8.8).lineTo(35.4,-6.1).curveTo(34.7,-4,34.3,-3.2).curveTo(32.8,-0.1,31,2.2).curveTo(29.1,4.7,26.5,6.5).curveTo(23.6,8.4,19.8,9.6).curveTo(18.6,10,17.4,10.3).curveTo(15.6,10.7,12.4,11.2).curveTo(11.7,11.3,10.6,11.3).curveTo(9.3,11.4,8.8,11.4).curveTo(7.3,11.6,5.4,11.6).curveTo(4.3,11.6,1.8,11.5).curveTo(-1.4,11.5,-5.3,11.2).curveTo(-7.2,11.1,-8.1,11.1).lineTo(-11.9,10.6).curveTo(-12.5,10.6,-15.4,10.4).curveTo(-17.6,10.2,-18.7,10).curveTo(-20.7,9.8,-21.7,9.7).lineTo(-34.2,8.5).curveTo(-36.2,8.3,-37.5,8.2);
	this.shape_73.setTransform(109.4548,82.3);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.beginFill().beginStroke("#FFFFFF").moveTo(32.3,-11.6).curveTo(32,-11.1,31.8,-10.2).curveTo(31.3,-8.9,31.3,-8.8).lineTo(30.2,-6.1).curveTo(29.5,-4,29.1,-3.2).curveTo(27.6,-0.1,25.8,2.2).curveTo(23.9,4.7,21.3,6.5).curveTo(18.4,8.4,14.6,9.6).curveTo(13.4,10,12.2,10.3).curveTo(10.4,10.7,7.2,11.2).curveTo(6.5,11.3,5.4,11.3).curveTo(4.1,11.4,3.6,11.4).curveTo(2.1,11.6,0.2,11.6).curveTo(-0.9,11.6,-3.4,11.5).curveTo(-6.6,11.5,-10.5,11.2).curveTo(-12.4,11.1,-13.3,11.1).lineTo(-17.1,10.6).curveTo(-17.7,10.6,-20.6,10.4).curveTo(-22.8,10.2,-23.9,10).curveTo(-25.9,9.8,-26.9,9.7).lineTo(-32.7,9.2);
	this.shape_74.setTransform(114.6812,82.3);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.beginFill().beginStroke("#FFFFFF").moveTo(27,-11.6).curveTo(26.7,-11.1,26.5,-10.2).curveTo(26,-8.9,26,-8.8).lineTo(24.9,-6.1).curveTo(24.2,-4,23.8,-3.2).curveTo(22.3,-0.1,20.5,2.2).curveTo(18.6,4.7,16,6.5).curveTo(13.1,8.4,9.3,9.6).curveTo(8.1,10,6.9,10.3).curveTo(5.1,10.7,1.9,11.2).curveTo(1.2,11.3,0.1,11.3).curveTo(-1.2,11.4,-1.7,11.4).curveTo(-3.2,11.6,-5.1,11.6).curveTo(-6.2,11.6,-8.7,11.5).curveTo(-11.9,11.5,-15.8,11.2).curveTo(-17.7,11.1,-18.6,11.1).lineTo(-22.4,10.6).curveTo(-23,10.6,-25.9,10.4).curveTo(-26.4,10.4,-27,10.3);
	this.shape_75.setTransform(119.9548,82.3);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.beginFill().beginStroke("#FFFFFF").moveTo(22,-11.6).curveTo(21.7,-11.1,21.5,-10.2).curveTo(21,-8.9,21,-8.8).lineTo(19.9,-6.1).curveTo(19.2,-4,18.8,-3.2).curveTo(17.3,-0.1,15.5,2.2).curveTo(13.6,4.7,11,6.5).curveTo(8.1,8.4,4.3,9.6).curveTo(3.1,10,1.9,10.3).curveTo(0.1,10.7,-3.1,11.2).curveTo(-3.8,11.3,-4.9,11.3).curveTo(-6.2,11.4,-6.7,11.4).curveTo(-8.2,11.6,-10.1,11.6).curveTo(-11.2,11.6,-13.7,11.5).curveTo(-16.9,11.5,-20.8,11.2).curveTo(-21.4,11.2,-22,11.2);
	this.shape_76.setTransform(124.9548,82.3);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.beginFill().beginStroke("#FFFFFF").moveTo(17.3,-11.6).curveTo(16.9,-11.1,16.7,-10.2).curveTo(16.2,-8.9,16.2,-8.8).lineTo(15.2,-6.1).curveTo(14.4,-4,14.1,-3.2).curveTo(12.5,-0.1,10.8,2.2).curveTo(8.8,4.7,6.2,6.5).curveTo(3.4,8.4,-0.5,9.6).curveTo(-1.6,10,-2.9,10.3).curveTo(-4.7,10.7,-7.8,11.2).curveTo(-8.5,11.3,-9.6,11.3).curveTo(-10.9,11.4,-11.4,11.4).curveTo(-13,11.6,-14.9,11.6).curveTo(-15.7,11.6,-17.7,11.6);
	this.shape_77.setTransform(129.7016,82.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.beginFill().beginStroke("#FFFFFF").moveTo(13.3,-11.5).curveTo(12.9,-11,12.7,-10.1).curveTo(12.2,-8.7,12.2,-8.7).lineTo(11.2,-6).curveTo(10.4,-3.8,10.1,-3).curveTo(8.5,0.1,6.8,2.3).curveTo(4.8,4.9,2.2,6.6).curveTo(-0.6,8.5,-4.5,9.8).curveTo(-5.6,10.2,-6.9,10.5).curveTo(-8.7,10.9,-11.8,11.3).curveTo(-12.5,11.4,-13.6,11.5);
	this.shape_78.setTransform(133.7435,82.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},13).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[]},1).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[]},1).to({state:[{t:this.shape}]},19).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).wait(1));

	// PLANE
	this.PLANE_ANIMATION = new lib.Plane();
	this.PLANE_ANIMATION.name = "PLANE_ANIMATION";
	this.PLANE_ANIMATION.parent = this;
	this.PLANE_ANIMATION.setTransform(-30.7,143.9,0.2108,0.2107,0,0,0,-409.3,212.2);

	this.timeline.addTween(cjs.Tween.get(this.PLANE_ANIMATION).to({regY:211.9,guide:{path:[-30.6,143.9,-16.3,141.9,-8.3,140.7,-5.3,140.3,-2.5,139.9,8.7,138.2,17.1,136.6,48.2,130.6,69,120.2,73.1,118.2,73.9,115.9,74.7,113.7,72.4,110.8,70.4,108,65.2,103.8,62.3,101.4,52.9,94.1,49.4,91.4,48.3,89.3,47.1,87.3,48.3,86,50.5,83.5,60.7,83,69.5,82.7,85.5,83.8,97.1,84.6,118,86.6,124,87.2,129.2,87.2,149.6,86.9,158.9,76.9,162.6,72.9,164.1,68.1,164.9,65.7,164.9,63.9]}},72).wait(16).to({alpha:0},7,cjs.Ease.cubicOut).to({_off:true},2).wait(1).to({_off:false,regY:212.2,x:-30.7,y:143.9,alpha:1},0).to({regY:211.9,guide:{path:[-30.6,143.9,-16.3,141.9,-8.3,140.7,-5.3,140.3,-2.5,139.9,8.7,138.2,17.1,136.6,48.2,130.6,69,120.2,73.1,118.2,73.9,115.9,74.7,113.7,72.4,110.8,70.4,108,65.2,103.8,62.3,101.4,52.9,94.1,49.4,91.4,48.3,89.3,47.1,87.3,48.3,86,50.5,83.5,60.7,83,69.5,82.7,85.5,83.8,97.1,84.6,118,86.6,124,87.2,129.2,87.2,149.6,86.9,158.9,76.9,162.6,72.9,164.1,68.1,164.9,65.7,164.9,63.9]}},72).wait(16).to({alpha:0},7,cjs.Ease.cubicOut).to({_off:true},2).wait(1).to({_off:false,regY:212.2,x:-30.7,y:143.9,alpha:1},0).to({regY:211.9,guide:{path:[-30.6,143.9,-16.3,141.9,-8.3,140.7,-5.3,140.3,-2.5,139.9,8.7,138.2,17.1,136.6,48.2,130.6,69,120.2,73.1,118.2,73.9,115.9,74.7,113.7,72.4,110.8,70.4,108,65.2,103.8,62.3,101.4,52.9,94.1,49.4,91.4,48.3,89.3,47.1,87.3,48.3,86,50.5,83.5,60.7,83,69.5,82.7,85.5,83.8,97.1,84.6,118,86.6,124,87.2,129.2,87.2,149.6,86.9,158.9,76.9,162.6,72.9,164.1,68.1,164.9,65.7,164.9,63.9]}},72).wait(9).to({alpha:0},7,cjs.Ease.cubicOut).wait(1));

	// Layer_20 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.moveTo(-122,111.5).lineTo(-122,-111.5).lineTo(121.9,-111.5).lineTo(121.9,111.5).closePath();
	mask.setTransform(82,87.55);

	// IMG2
	this.instance = new lib.Tween5("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(82,58);

	this.instance_1 = new lib.Tween6("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(82,247);
	this.instance_1._off = true;

	var maskedShapeInstanceList = [this.instance,this.instance_1];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,y:247},90).wait(195));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},90).to({y:273.5,alpha:0},6).to({_off:true},1).wait(188));

	// IMG1
	this.instance_2 = new lib.Tween3("synched",0);
	this.instance_2.parent = this;
	this.instance_2.setTransform(-90,138);
	this.instance_2._off = true;

	this.instance_3 = new lib.Tween4("synched",0);
	this.instance_3.parent = this;
	this.instance_3.setTransform(76,138);
	this.instance_3._off = true;

	var maskedShapeInstanceList = [this.instance_2,this.instance_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(88).to({_off:false},0).to({_off:true,x:76},88).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(88).to({_off:false},88).to({x:160,alpha:0},9).to({_off:true},1).wait(99));

	// IMG3
	this.instance_4 = new lib.Tween7("synched",0);
	this.instance_4.parent = this;
	this.instance_4.setTransform(179,111.85);
	this.instance_4._off = true;

	this.instance_5 = new lib.Tween8("synched",0);
	this.instance_5.parent = this;
	this.instance_5.setTransform(39,111.85);

	var maskedShapeInstanceList = [this.instance_4,this.instance_5];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_4}]},178).to({state:[{t:this.instance_5}]},106).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(178).to({_off:false},0).to({_off:true,x:39},106).wait(1));

	// TEXT_3
	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(60.2,351.85,0.782,0.782);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(189).to({_off:false},0).to({y:385.85,alpha:1},7,cjs.Ease.cubicOut).wait(82).to({y:424.3,alpha:0},6,cjs.Ease.cubicIn).wait(1));

	// TEXT_2
	this.instance_7 = new lib.Symbol3();
	this.instance_7.parent = this;
	this.instance_7.setTransform(60.2,351.85,0.782,0.782);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(94).to({_off:false},0).to({y:385.85,alpha:1},8,cjs.Ease.cubicOut).wait(81).to({y:424.3,alpha:0},6,cjs.Ease.cubicIn).to({_off:true},1).wait(95));

	// TEXT_1
	this.instance_8 = new lib.Symbol4();
	this.instance_8.parent = this;
	this.instance_8.setTransform(60.2,351.85,0.782,0.782);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:60,y:385.85,alpha:1},13,cjs.Ease.cubicOut).wait(73).to({x:60.2},0).to({y:424.3,alpha:0},7,cjs.Ease.cubicIn).to({_off:true},5).wait(187));

	// Layer_3
	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.beginFill("#FFFFFF").beginStroke().moveTo(44.2,6.8).curveTo(43.7,6.5,43.7,6).lineTo(44.4,5.8).curveTo(44.4,6.1,44.7,6.3).curveTo(44.9,6.5,45.3,6.6).curveTo(46.2,6.6,46.2,5.5).lineTo(46.2,5.1).curveTo(45.9,5.7,45.2,5.7).curveTo(44.6,5.7,44.1,5.1).curveTo(43.7,4.7,43.7,4).curveTo(43.7,3.3,44.1,2.8).curveTo(44.5,2.4,45.2,2.3).curveTo(46,2.3,46.2,2.9).lineTo(46.2,2.4).lineTo(47,2.4).lineTo(47,5.5).curveTo(47,6.3,46.6,6.7).curveTo(46.2,7.3,45.3,7.3).curveTo(44.6,7.2,44.2,6.8).closePath().moveTo(44.7,3.3).curveTo(44.5,3.6,44.5,4).curveTo(44.5,4.5,44.7,4.7).curveTo(45,4.9,45.4,5).curveTo(45.8,4.9,46,4.7).curveTo(46.2,4.5,46.2,4).curveTo(46.2,3.6,46,3.3).curveTo(45.8,3,45.4,3.1).curveTo(45,3,44.7,3.3).closePath().moveTo(-20.4,6.8).curveTo(-20.8,6.5,-20.9,6).lineTo(-20.1,5.8).curveTo(-20.1,6.1,-19.9,6.3).curveTo(-19.6,6.5,-19.3,6.6).curveTo(-18.3,6.6,-18.3,5.5).lineTo(-18.3,5.1).curveTo(-18.6,5.7,-19.3,5.7).curveTo(-20,5.7,-20.4,5.1).curveTo(-20.9,4.7,-20.9,4).curveTo(-20.9,3.3,-20.5,2.8).curveTo(-20,2.4,-19.3,2.3).curveTo(-18.6,2.3,-18.3,2.9).lineTo(-18.3,2.4).lineTo(-17.5,2.4).lineTo(-17.5,5.5).curveTo(-17.5,6.3,-17.9,6.7).curveTo(-18.4,7.3,-19.3,7.3).curveTo(-19.9,7.2,-20.4,6.8).closePath().moveTo(-19.8,3.3).curveTo(-20.1,3.6,-20.1,4).curveTo(-20.1,4.5,-19.8,4.7).curveTo(-19.6,4.9,-19.2,5).curveTo(-18.8,4.9,-18.5,4.7).curveTo(-18.3,4.5,-18.3,4).curveTo(-18.3,3.6,-18.6,3.3).curveTo(-18.8,3,-19.2,3.1).curveTo(-19.6,3,-19.8,3.3).closePath().moveTo(-6.9,7.1).lineTo(-6.9,2.4).lineTo(-6.2,2.4).lineTo(-6.2,2.9).lineTo(-5.8,2.4).curveTo(-5.5,2.3,-5.1,2.3).curveTo(-4.3,2.3,-3.9,2.9).curveTo(-3.5,3.3,-3.5,4.1).curveTo(-3.5,4.8,-3.9,5.3).curveTo(-4.4,5.9,-5.1,5.9).curveTo(-5.8,5.9,-6.1,5.4).lineTo(-6.1,7.1).closePath().moveTo(-5.9,3.3).curveTo(-6.2,3.6,-6.2,4.1).curveTo(-6.2,4.6,-5.9,4.9).curveTo(-5.6,5.1,-5.2,5.1).curveTo(-4.8,5.1,-4.6,4.9).curveTo(-4.3,4.6,-4.3,4.1).curveTo(-4.3,3.6,-4.6,3.3).curveTo(-4.8,3.1,-5.2,3.1).curveTo(-5.6,3.1,-5.9,3.3).closePath().moveTo(-11.1,7.1).lineTo(-11.1,2.4).lineTo(-10.4,2.4).lineTo(-10.4,2.9).lineTo(-10,2.4).curveTo(-9.7,2.3,-9.3,2.3).curveTo(-8.5,2.3,-8.1,2.9).curveTo(-7.7,3.3,-7.7,4.1).curveTo(-7.7,4.8,-8.1,5.3).curveTo(-8.6,5.9,-9.3,5.9).curveTo(-10,5.9,-10.3,5.4).lineTo(-10.3,7.1).closePath().moveTo(-10.1,3.3).curveTo(-10.4,3.6,-10.4,4.1).curveTo(-10.4,4.6,-10.1,4.9).curveTo(-9.8,5.1,-9.4,5.1).curveTo(-9,5.1,-8.8,4.9).curveTo(-8.5,4.6,-8.5,4.1).curveTo(-8.5,3.6,-8.8,3.3).curveTo(-9,3.1,-9.4,3.1).curveTo(-9.8,3.1,-10.1,3.3).closePath().moveTo(-44.2,7.1).lineTo(-44.2,2.4).lineTo(-43.5,2.4).lineTo(-43.5,2.9).lineTo(-43.1,2.4).curveTo(-42.8,2.3,-42.4,2.3).curveTo(-41.6,2.3,-41.2,2.9).curveTo(-40.8,3.3,-40.8,4.1).curveTo(-40.8,4.8,-41.2,5.3).curveTo(-41.7,5.9,-42.4,5.9).curveTo(-43.1,5.9,-43.4,5.4).lineTo(-43.4,7.1).closePath().moveTo(-43.2,3.3).curveTo(-43.5,3.6,-43.5,4.1).curveTo(-43.5,4.6,-43.2,4.9).curveTo(-42.9,5.1,-42.5,5.1).curveTo(-42.1,5.1,-41.9,4.9).curveTo(-41.6,4.6,-41.6,4.1).curveTo(-41.6,3.6,-41.9,3.3).curveTo(-42.1,3.1,-42.5,3.1).curveTo(-42.9,3.1,-43.2,3.3).closePath().moveTo(52,6).curveTo(52,6,51.9,5.9).curveTo(51.9,5.8,51.9,5.8).curveTo(51.8,5.7,51.8,5.7).curveTo(51.8,5.6,51.8,5.6).curveTo(51.8,5.5,51.8,5.5).curveTo(51.8,5.4,51.9,5.4).curveTo(51.9,5.3,51.9,5.2).curveTo(52,5.2,52,5.1).curveTo(52.1,5.1,52.1,5.1).curveTo(52.2,5.1,52.2,5).curveTo(52.3,5,52.3,5).curveTo(52.4,5,52.4,5).lineTo(52.8,5.1).lineTo(53,5.6).curveTo(53,5.6,53,5.7).curveTo(53,5.7,52.9,5.8).curveTo(52.9,5.8,52.9,5.9).curveTo(52.9,6,52.8,6).lineTo(52.4,6.1).curveTo(52.4,6.1,52.3,6.1).curveTo(52.3,6.1,52.2,6.1).curveTo(52.2,6.1,52.1,6.1).curveTo(52.1,6,52,6).closePath().moveTo(48.3,5.4).curveTo(47.7,4.9,47.7,4.1).curveTo(47.7,3.3,48.2,2.8).curveTo(48.7,2.3,49.4,2.3).curveTo(50.2,2.3,50.6,2.8).curveTo(51.1,3.2,51.1,4).lineTo(51,4.3).lineTo(48.5,4.3).curveTo(48.6,4.7,48.8,5).curveTo(49.1,5.2,49.5,5.2).curveTo(50.1,5.2,50.3,4.6).lineTo(51,4.9).curveTo(50.9,5.3,50.5,5.6).curveTo(50.1,5.9,49.5,5.9).curveTo(48.7,5.9,48.3,5.4).closePath().moveTo(50.2,3.7).curveTo(50.2,3.4,50,3.2).curveTo(49.8,2.9,49.4,3).curveTo(49,2.9,48.8,3.2).curveTo(48.6,3.4,48.6,3.7).lineTo(50.2,3.7).lineTo(50.2,3.7).closePath().moveTo(36.3,5.6).curveTo(36,5.3,36,4.9).curveTo(36,4.4,36.3,4.1).curveTo(36.6,3.9,37,3.9).lineTo(37.9,3.7).curveTo(37.9,3.7,38,3.7).curveTo(38,3.7,38.1,3.6).curveTo(38.1,3.6,38.1,3.6).curveTo(38.1,3.5,38.1,3.4).curveTo(38.1,3,37.5,3).curveTo(37.2,3,37,3.2).curveTo(37,3.2,36.9,3.2).curveTo(36.9,3.3,36.9,3.3).curveTo(36.9,3.4,36.8,3.4).curveTo(36.8,3.5,36.8,3.5).lineTo(36.1,3.4).curveTo(36.1,2.9,36.5,2.6).curveTo(36.9,2.3,37.5,2.3).curveTo(38.2,2.3,38.6,2.6).curveTo(38.9,3,38.9,3.5).lineTo(38.9,5.2).lineTo(39,5.8).lineTo(38.2,5.8).lineTo(38.2,5.3).curveTo(37.9,5.9,37.1,5.9).curveTo(36.6,5.9,36.3,5.6).closePath().moveTo(37.3,4.3).curveTo(36.8,4.5,36.8,4.9).lineTo(36.9,5.1).lineTo(37.3,5.2).curveTo(38.1,5.2,38.1,4.4).lineTo(38.1,4.2).closePath().moveTo(28.7,5.4).curveTo(28.2,4.9,28.2,4.1).curveTo(28.2,3.3,28.7,2.8).curveTo(29.2,2.3,29.9,2.3).curveTo(30.6,2.3,31,2.6).curveTo(31.4,2.9,31.5,3.4).lineTo(30.8,3.7).curveTo(30.6,3,29.9,3.1).curveTo(29.5,3,29.3,3.3).curveTo(29,3.6,29,4.1).curveTo(29,4.6,29.3,4.9).curveTo(29.5,5.2,29.9,5.1).curveTo(30.3,5.1,30.5,5).lineTo(30.8,4.6).lineTo(31.5,4.8).curveTo(31.4,5.2,31,5.6).curveTo(30.6,5.9,29.9,5.9).curveTo(29.2,5.9,28.7,5.4).closePath().moveTo(22.7,5.3).curveTo(22.3,4.8,22.3,4.1).curveTo(22.3,3.3,22.7,2.9).curveTo(23.2,2.3,23.9,2.3).curveTo(24.7,2.3,24.9,2.8).lineTo(24.9,0.7).lineTo(25.7,0.7).lineTo(25.7,5.2).lineTo(25.7,5.8).lineTo(25,5.8).lineTo(24.9,5.3).curveTo(24.6,5.9,23.9,5.9).curveTo(23.2,5.9,22.7,5.3).closePath().moveTo(23.4,3.3).curveTo(23.1,3.6,23.1,4.1).curveTo(23.1,4.6,23.3,4.9).curveTo(23.6,5.1,24,5.1).curveTo(24.4,5.1,24.7,4.9).curveTo(24.9,4.6,24.9,4.1).curveTo(24.9,3.6,24.7,3.3).curveTo(24.4,3,24,3).curveTo(23.6,3,23.4,3.3).closePath().moveTo(15,5.6).curveTo(14.6,5.3,14.6,4.9).curveTo(14.6,4.4,14.9,4.1).curveTo(15.2,3.9,15.7,3.9).lineTo(16.5,3.7).curveTo(16.6,3.7,16.6,3.7).curveTo(16.7,3.7,16.7,3.6).curveTo(16.7,3.6,16.8,3.6).curveTo(16.8,3.5,16.8,3.4).curveTo(16.8,3,16.2,3).curveTo(15.8,3,15.7,3.2).curveTo(15.6,3.2,15.6,3.2).curveTo(15.5,3.3,15.5,3.3).curveTo(15.5,3.4,15.5,3.4).curveTo(15.5,3.5,15.5,3.5).lineTo(14.7,3.4).curveTo(14.8,2.9,15.1,2.6).curveTo(15.5,2.3,16.1,2.3).curveTo(16.9,2.3,17.3,2.6).curveTo(17.6,3,17.6,3.5).lineTo(17.6,5.2).lineTo(17.6,5.8).lineTo(16.9,5.8).lineTo(16.8,5.3).curveTo(16.5,5.9,15.8,5.9).curveTo(15.3,5.9,15,5.6).closePath().moveTo(15.9,4.3).curveTo(15.5,4.5,15.5,4.9).lineTo(15.6,5.1).lineTo(15.9,5.2).curveTo(16.8,5.2,16.8,4.4).lineTo(16.8,4.2).closePath().moveTo(7.7,5.6).curveTo(7.4,5.3,7.4,4.9).curveTo(7.4,4.4,7.7,4.1).curveTo(8,3.9,8.4,3.9).lineTo(9.3,3.7).curveTo(9.3,3.7,9.4,3.7).curveTo(9.4,3.7,9.5,3.6).curveTo(9.5,3.6,9.5,3.6).curveTo(9.5,3.5,9.5,3.4).curveTo(9.5,3,8.9,3).curveTo(8.6,3,8.4,3.2).curveTo(8.4,3.2,8.3,3.2).curveTo(8.3,3.3,8.3,3.3).curveTo(8.3,3.4,8.2,3.4).curveTo(8.2,3.5,8.2,3.5).lineTo(7.5,3.4).curveTo(7.5,2.9,7.9,2.6).curveTo(8.3,2.3,8.9,2.3).curveTo(9.6,2.3,10,2.6).curveTo(10.3,3,10.3,3.5).lineTo(10.3,5.2).lineTo(10.4,5.8).lineTo(9.6,5.8).lineTo(9.6,5.3).curveTo(9.3,5.9,8.5,5.9).curveTo(8,5.9,7.7,5.6).closePath().moveTo(8.7,4.3).curveTo(8.2,4.5,8.2,4.9).lineTo(8.3,5.1).lineTo(8.7,5.2).curveTo(9.5,5.2,9.5,4.4).lineTo(9.5,4.2).closePath().moveTo(0.1,5.4).curveTo(-0.4,4.9,-0.4,4.1).curveTo(-0.4,3.3,0.1,2.8).curveTo(0.6,2.3,1.4,2.3).curveTo(2.2,2.3,2.7,2.8).curveTo(3.2,3.3,3.2,4.1).curveTo(3.2,4.9,2.7,5.4).curveTo(2.2,5.9,1.4,5.9).curveTo(0.6,5.9,0.1,5.4).closePath().moveTo(0.7,3.3).curveTo(0.4,3.6,0.4,4.1).curveTo(0.4,4.6,0.7,4.9).curveTo(1,5.2,1.4,5.2).curveTo(1.8,5.2,2.1,4.9).curveTo(2.3,4.6,2.3,4.1).curveTo(2.3,3.6,2.1,3.3).curveTo(1.8,3,1.4,3).curveTo(1,3,0.7,3.3).closePath().moveTo(-14.7,5.6).curveTo(-15.1,5.3,-15.1,4.9).curveTo(-15.1,4.4,-14.8,4.1).curveTo(-14.5,3.9,-14,3.9).lineTo(-13.2,3.7).curveTo(-13.1,3.7,-13.1,3.7).curveTo(-13,3.7,-13,3.6).curveTo(-13,3.6,-12.9,3.6).curveTo(-12.9,3.5,-12.9,3.4).curveTo(-12.9,3,-13.5,3).curveTo(-13.9,3,-14,3.2).curveTo(-14.1,3.2,-14.1,3.2).curveTo(-14.2,3.3,-14.2,3.3).curveTo(-14.2,3.4,-14.2,3.4).curveTo(-14.2,3.5,-14.2,3.5).lineTo(-15,3.4).curveTo(-14.9,2.9,-14.6,2.6).curveTo(-14.2,2.3,-13.6,2.3).curveTo(-12.8,2.3,-12.4,2.6).curveTo(-12.1,3,-12.1,3.5).lineTo(-12.1,5.2).lineTo(-12.1,5.8).lineTo(-12.8,5.8).lineTo(-12.9,5.3).curveTo(-13.2,5.9,-13.9,5.9).curveTo(-14.4,5.9,-14.7,5.6).closePath().moveTo(-13.8,4.3).curveTo(-14.2,4.5,-14.2,4.9).lineTo(-14.1,5.1).lineTo(-13.8,5.2).curveTo(-12.9,5.2,-12.9,4.4).lineTo(-12.9,4.2).closePath().moveTo(-38.1,5.6).curveTo(-38.4,5.3,-38.4,4.9).curveTo(-38.4,4.4,-38.1,4.1).curveTo(-37.8,3.9,-37.4,3.9).lineTo(-36.5,3.7).curveTo(-36.5,3.7,-36.4,3.7).curveTo(-36.4,3.7,-36.3,3.6).curveTo(-36.3,3.6,-36.3,3.6).curveTo(-36.3,3.5,-36.3,3.4).curveTo(-36.3,3,-36.9,3).curveTo(-37.2,3,-37.4,3.2).curveTo(-37.4,3.2,-37.5,3.2).curveTo(-37.5,3.3,-37.5,3.3).curveTo(-37.5,3.4,-37.6,3.4).curveTo(-37.6,3.5,-37.6,3.5).lineTo(-38.3,3.4).curveTo(-38.3,2.9,-37.9,2.6).curveTo(-37.5,2.3,-36.9,2.3).curveTo(-36.2,2.3,-35.8,2.6).curveTo(-35.5,3,-35.5,3.5).lineTo(-35.5,5.2).lineTo(-35.4,5.8).lineTo(-36.2,5.8).lineTo(-36.2,5.3).curveTo(-36.5,5.9,-37.3,5.9).curveTo(-37.8,5.9,-38.1,5.6).closePath().moveTo(-37.1,4.3).curveTo(-37.6,4.5,-37.6,4.9).lineTo(-37.5,5.1).lineTo(-37.1,5.2).curveTo(-36.3,5.2,-36.3,4.4).lineTo(-36.3,4.2).closePath().moveTo(-49.8,5.4).curveTo(-50.3,4.9,-50.3,4.1).curveTo(-50.3,3.3,-49.8,2.8).curveTo(-49.3,2.3,-48.5,2.3).curveTo(-47.7,2.3,-47.2,2.8).curveTo(-46.7,3.3,-46.7,4.1).curveTo(-46.7,4.9,-47.2,5.4).curveTo(-47.7,5.9,-48.5,5.9).curveTo(-49.3,5.9,-49.8,5.4).closePath().moveTo(-49.2,3.3).curveTo(-49.5,3.6,-49.5,4.1).curveTo(-49.5,4.6,-49.2,4.9).curveTo(-48.9,5.2,-48.5,5.2).curveTo(-48.1,5.2,-47.8,4.9).curveTo(-47.6,4.6,-47.6,4.1).curveTo(-47.6,3.6,-47.8,3.3).curveTo(-48.1,3,-48.5,3).curveTo(-48.9,3,-49.2,3.3).closePath().moveTo(-52,5.6).curveTo(-52.3,5.3,-52.3,4.9).lineTo(-52.3,3.1).lineTo(-53,3.1).lineTo(-53,2.4).lineTo(-52.8,2.4).curveTo(-52.3,2.4,-52.3,1.9).lineTo(-52.3,1.3).lineTo(-51.5,1.3).lineTo(-51.5,2.4).lineTo(-50.8,2.4).lineTo(-50.8,3.1).lineTo(-51.5,3.1).lineTo(-51.5,4.7).curveTo(-51.5,5.1,-51.1,5.1).lineTo(-50.8,5.1).lineTo(-50.8,5.8).lineTo(-51.3,5.8).curveTo(-51.8,5.8,-52,5.6).closePath().moveTo(42.1,5.8).lineTo(42.1,3.8).curveTo(42.1,3.1,41.4,3.1).curveTo(41.1,3.1,40.9,3.2).curveTo(40.7,3.5,40.7,3.9).lineTo(40.7,5.8).lineTo(39.9,5.8).lineTo(39.9,2.4).lineTo(40.7,2.4).lineTo(40.7,2.9).curveTo(41,2.3,41.7,2.3).curveTo(42.3,2.3,42.6,2.7).curveTo(42.9,3,42.9,3.7).lineTo(42.9,5.8).closePath().moveTo(34.4,5.8).lineTo(34.4,3.8).curveTo(34.4,3.1,33.7,3.1).curveTo(33.4,3.1,33.2,3.2).curveTo(33,3.4,33,3.8).lineTo(33,5.8).lineTo(32.2,5.8).lineTo(32.2,0.7).lineTo(33,0.7).lineTo(33,2.7).curveTo(33.3,2.3,34,2.3).curveTo(34.6,2.3,34.9,2.7).curveTo(35.2,3,35.2,3.7).lineTo(35.2,5.8).closePath().moveTo(20.8,5.8).lineTo(20.8,3.8).curveTo(20.8,3.1,20.1,3.1).curveTo(19.7,3.1,19.5,3.2).curveTo(19.4,3.5,19.4,3.9).lineTo(19.4,5.8).lineTo(18.6,5.8).lineTo(18.6,2.4).lineTo(19.3,2.4).lineTo(19.3,2.9).curveTo(19.7,2.3,20.3,2.3).curveTo(20.9,2.3,21.3,2.7).curveTo(21.6,3,21.6,3.7).lineTo(21.6,5.8).closePath().moveTo(11.3,5.8).lineTo(11.3,0.7).lineTo(12.1,0.7).lineTo(12.1,5.8).closePath().moveTo(4.9,5.8).lineTo(3.5,2.4).lineTo(4.4,2.4).lineTo(5.3,4.9).lineTo(6.2,2.4).lineTo(7,2.4).lineTo(5.7,5.8).closePath().moveTo(-2.7,5.8).lineTo(-2.7,2.4).lineTo(-2,2.4).lineTo(-2,3).curveTo(-1.7,2.3,-1,2.3).lineTo(-0.8,2.3).lineTo(-0.8,3.2).lineTo(-1,3.2).curveTo(-1.9,3.2,-1.9,4.2).lineTo(-1.9,5.8).closePath().moveTo(-22.4,5.8).lineTo(-22.4,3.8).curveTo(-22.4,3.1,-23.1,3.1).curveTo(-23.5,3.1,-23.7,3.2).curveTo(-23.8,3.5,-23.8,3.9).lineTo(-23.8,5.8).lineTo(-24.6,5.8).lineTo(-24.6,2.4).lineTo(-23.9,2.4).lineTo(-23.9,2.9).curveTo(-23.5,2.3,-22.9,2.3).curveTo(-22.3,2.3,-21.9,2.7).curveTo(-21.6,3,-21.6,3.7).lineTo(-21.6,5.8).closePath().moveTo(-26.5,5.8).lineTo(-26.5,2.4).lineTo(-25.7,2.4).lineTo(-25.7,5.8).closePath().moveTo(-28.3,5.8).lineTo(-28.3,3.8).curveTo(-28.3,3.1,-29,3.1).curveTo(-29.3,3.1,-29.5,3.2).curveTo(-29.7,3.5,-29.7,3.9).lineTo(-29.7,5.8).lineTo(-30.5,5.8).lineTo(-30.5,2.4).lineTo(-29.7,2.4).lineTo(-29.7,2.9).curveTo(-29.4,2.3,-28.7,2.3).curveTo(-28.1,2.3,-27.8,2.7).curveTo(-27.5,3,-27.5,3.7).lineTo(-27.5,5.8).closePath().moveTo(-32.3,5.8).lineTo(-32.3,3.8).curveTo(-32.3,3.1,-33,3.1).curveTo(-33.3,3.1,-33.5,3.2).curveTo(-33.7,3.5,-33.7,3.9).lineTo(-33.7,5.8).lineTo(-34.5,5.8).lineTo(-34.5,2.4).lineTo(-33.7,2.4).lineTo(-33.7,2.9).curveTo(-33.4,2.3,-32.7,2.3).curveTo(-32.1,2.3,-31.8,2.7).curveTo(-31.5,3,-31.5,3.7).lineTo(-31.5,5.8).closePath().moveTo(-40,5.8).lineTo(-40,0.7).lineTo(-39.2,0.7).lineTo(-39.2,5.8).closePath().moveTo(-26.5,1.5).curveTo(-26.5,1.5,-26.5,1.5).curveTo(-26.6,1.4,-26.6,1.4).curveTo(-26.6,1.3,-26.6,1.3).curveTo(-26.6,1.2,-26.6,1.2).curveTo(-26.6,1.1,-26.6,1.1).curveTo(-26.6,1,-26.6,1).curveTo(-26.6,0.9,-26.5,0.9).curveTo(-26.5,0.8,-26.5,0.8).curveTo(-26.4,0.8,-26.4,0.7).curveTo(-26.4,0.7,-26.3,0.7).curveTo(-26.3,0.7,-26.2,0.7).curveTo(-26.2,0.6,-26.1,0.6).curveTo(-26.1,0.6,-26,0.7).curveTo(-26,0.7,-25.9,0.7).curveTo(-25.9,0.7,-25.8,0.7).curveTo(-25.8,0.8,-25.7,0.8).curveTo(-25.7,0.8,-25.7,0.9).curveTo(-25.6,0.9,-25.6,1).curveTo(-25.6,1,-25.6,1.1).curveTo(-25.6,1.1,-25.6,1.2).curveTo(-25.6,1.2,-25.6,1.3).curveTo(-25.6,1.3,-25.6,1.4).curveTo(-25.6,1.4,-25.7,1.5).curveTo(-25.7,1.5,-25.7,1.5).curveTo(-25.8,1.6,-25.8,1.6).curveTo(-25.9,1.6,-25.9,1.7).curveTo(-26,1.7,-26,1.7).curveTo(-26.1,1.7,-26.1,1.7).curveTo(-26.2,1.7,-26.2,1.7).curveTo(-26.3,1.7,-26.3,1.7).curveTo(-26.4,1.6,-26.4,1.6).curveTo(-26.4,1.6,-26.5,1.5).closePath().moveTo(35.8,-0.7).lineTo(35.8,-1.4).lineTo(36.1,-1.4).curveTo(36.5,-1.4,36.5,-1.8).lineTo(36.5,-5.5).lineTo(37.3,-5.5).lineTo(37.3,-1.7).curveTo(37.3,-1.3,37,-1).curveTo(36.8,-0.6,36.3,-0.6).lineTo(35.8,-0.7).closePath().moveTo(16.8,-0.7).lineTo(17.6,-2.5).lineTo(16.1,-5.5).lineTo(17,-5.5).lineTo(18,-3.3).lineTo(18.9,-5.5).lineTo(19.8,-5.5).lineTo(17.6,-0.7).closePath().moveTo(-21.8,-0.7).lineTo(-21.8,-5.5).lineTo(-21.1,-5.5).lineTo(-21.1,-5).lineTo(-20.7,-5.5).curveTo(-20.4,-5.6,-20,-5.6).curveTo(-19.2,-5.6,-18.8,-5).curveTo(-18.4,-4.6,-18.4,-3.8).curveTo(-18.4,-3.1,-18.8,-2.5).curveTo(-19.3,-2,-20,-2).curveTo(-20.7,-2,-21,-2.5).lineTo(-21,-0.7).closePath().moveTo(-20.8,-4.6).curveTo(-21.1,-4.3,-21.1,-3.8).curveTo(-21.1,-3.3,-20.8,-3.1).curveTo(-20.5,-2.8,-20.1,-2.8).curveTo(-19.7,-2.8,-19.5,-3.1).curveTo(-19.2,-3.3,-19.2,-3.8).curveTo(-19.2,-4.3,-19.5,-4.6).curveTo(-19.7,-4.9,-20.1,-4.9).curveTo(-20.5,-4.9,-20.8,-4.6).closePath().moveTo(42.4,-2.5).curveTo(41.9,-3.1,41.9,-3.8).curveTo(41.9,-4.6,42.4,-5.1).curveTo(42.9,-5.6,43.6,-5.6).curveTo(44.3,-5.6,44.7,-5.2).curveTo(45.1,-4.9,45.2,-4.5).lineTo(44.5,-4.2).curveTo(44.3,-4.9,43.6,-4.9).curveTo(43.2,-4.8,43,-4.6).curveTo(42.7,-4.3,42.7,-3.8).curveTo(42.7,-3.3,43,-3).curveTo(43.2,-2.8,43.6,-2.8).curveTo(44,-2.8,44.2,-3).lineTo(44.5,-3.3).lineTo(45.2,-3.1).curveTo(45.1,-2.6,44.7,-2.3).curveTo(44.3,-2,43.6,-2).curveTo(42.9,-2,42.4,-2.5).closePath().moveTo(38.6,-2.5).curveTo(38.1,-3,38.1,-3.8).curveTo(38.1,-4.6,38.6,-5.1).curveTo(39.1,-5.6,39.7,-5.6).curveTo(40.5,-5.6,41,-5.1).curveTo(41.4,-4.6,41.4,-3.9).lineTo(41.4,-3.6).lineTo(38.9,-3.6).curveTo(38.9,-3.2,39.2,-3).curveTo(39.4,-2.7,39.8,-2.7).curveTo(40.5,-2.7,40.7,-3.3).lineTo(41.4,-3.1).curveTo(41.2,-2.6,40.8,-2.3).curveTo(40.4,-2,39.8,-2).curveTo(39.1,-2,38.6,-2.5).closePath().moveTo(40.6,-4.2).curveTo(40.6,-4.5,40.4,-4.7).curveTo(40.1,-4.9,39.7,-5).curveTo(39.4,-4.9,39.2,-4.7).curveTo(38.9,-4.5,38.9,-4.2).lineTo(40.6,-4.2).lineTo(40.6,-4.2).closePath().moveTo(33.1,-2.5).lineTo(33.1,-2.1).lineTo(32.3,-2.1).lineTo(32.3,-7.1).lineTo(33.1,-7.1).lineTo(33.1,-5.1).lineTo(33.5,-5.5).curveTo(33.8,-5.6,34.2,-5.6).curveTo(34.9,-5.6,35.3,-5.1).curveTo(35.7,-4.6,35.7,-3.8).curveTo(35.7,-3.1,35.3,-2.5).curveTo(34.9,-2,34.1,-2).curveTo(33.4,-2,33.1,-2.5).closePath().moveTo(33.4,-4.6).curveTo(33.1,-4.3,33.1,-3.8).curveTo(33.1,-3.3,33.4,-3).curveTo(33.6,-2.8,34,-2.8).curveTo(34.4,-2.8,34.7,-3).curveTo(34.9,-3.3,34.9,-3.8).curveTo(34.9,-4.3,34.7,-4.6).curveTo(34.4,-4.9,34,-4.9).curveTo(33.6,-4.9,33.4,-4.6).closePath().moveTo(28.6,-2.4).curveTo(28.3,-2.8,28.3,-3.3).lineTo(28.3,-5.5).lineTo(29.1,-5.5).lineTo(29.1,-3.5).curveTo(29.1,-3.2,29.2,-3).curveTo(29.4,-2.8,29.8,-2.8).curveTo(30.1,-2.8,30.3,-3).curveTo(30.5,-3.2,30.5,-3.5).lineTo(30.5,-5.5).lineTo(31.3,-5.5).lineTo(31.3,-2.7).lineTo(31.3,-2.1).lineTo(30.5,-2.1).lineTo(30.5,-2.5).lineTo(30.1,-2.1).lineTo(29.6,-2).curveTo(29,-2,28.6,-2.4).closePath().moveTo(24.4,-2.5).curveTo(23.9,-2.9,23.9,-3.5).lineTo(24.6,-3.8).curveTo(24.7,-3.3,25,-3.1).curveTo(25.3,-2.8,25.8,-2.8).curveTo(26.2,-2.8,26.5,-3).curveTo(26.7,-3.1,26.7,-3.4).curveTo(26.7,-3.9,26,-4.1).lineTo(25.3,-4.2).curveTo(24.7,-4.4,24.4,-4.8).curveTo(24.1,-5.1,24.1,-5.7).curveTo(24.1,-6.2,24.6,-6.7).curveTo(25.1,-7.2,25.7,-7.1).curveTo(26.5,-7.1,27,-6.8).curveTo(27.4,-6.4,27.5,-5.9).lineTo(26.7,-5.7).curveTo(26.7,-5.9,26.5,-6.1).curveTo(26.2,-6.5,25.8,-6.5).curveTo(25.4,-6.5,25.1,-6.2).curveTo(24.9,-6,24.9,-5.7).curveTo(24.9,-5.2,25.5,-5).lineTo(26.2,-5).curveTo(26.8,-4.8,27.2,-4.4).curveTo(27.5,-4,27.5,-3.5).curveTo(27.5,-2.9,27.1,-2.4).curveTo(26.6,-2,25.8,-2).curveTo(24.9,-2,24.4,-2.5).closePath().moveTo(6.9,-2.5).curveTo(6.4,-3,6.4,-3.8).curveTo(6.4,-4.6,6.9,-5.1).curveTo(7.4,-5.6,8.2,-5.6).curveTo(9,-5.6,9.5,-5.1).curveTo(10,-4.6,10,-3.8).curveTo(10,-3,9.5,-2.5).curveTo(9,-2,8.2,-2).curveTo(7.4,-2,6.9,-2.5).closePath().moveTo(7.5,-4.6).curveTo(7.2,-4.3,7.2,-3.8).curveTo(7.2,-3.3,7.5,-3).curveTo(7.8,-2.7,8.2,-2.7).curveTo(8.6,-2.7,8.9,-3).curveTo(9.1,-3.3,9.1,-3.8).curveTo(9.1,-4.3,8.9,-4.6).curveTo(8.6,-4.9,8.2,-4.9).curveTo(7.8,-4.9,7.5,-4.6).closePath().moveTo(-2.8,-2.5).curveTo(-3.3,-3,-3.3,-3.8).curveTo(-3.3,-4.6,-2.8,-5.1).curveTo(-2.3,-5.6,-1.6,-5.6).curveTo(-0.8,-5.6,-0.3,-5.1).curveTo(0.2,-4.6,0.2,-3.8).curveTo(0.2,-3,-0.3,-2.5).curveTo(-0.8,-2,-1.6,-2).curveTo(-2.3,-2,-2.8,-2.5).closePath().moveTo(-2.2,-4.6).curveTo(-2.5,-4.3,-2.5,-3.8).curveTo(-2.5,-3.3,-2.2,-3).curveTo(-1.9,-2.7,-1.6,-2.7).curveTo(-1.2,-2.7,-0.9,-3).curveTo(-0.6,-3.3,-0.6,-3.8).curveTo(-0.6,-4.3,-0.9,-4.6).curveTo(-1.2,-4.9,-1.6,-4.9).curveTo(-1.9,-4.9,-2.2,-4.6).closePath().moveTo(-8,-2.3).curveTo(-8.3,-2.6,-8.3,-3).lineTo(-7.6,-3.2).curveTo(-7.6,-3.1,-7.6,-3.1).curveTo(-7.6,-3,-7.6,-3).curveTo(-7.6,-2.9,-7.5,-2.9).curveTo(-7.5,-2.8,-7.5,-2.8).curveTo(-7.3,-2.6,-7,-2.6).lineTo(-6.6,-2.8).curveTo(-6.5,-2.8,-6.5,-2.8).curveTo(-6.5,-2.8,-6.5,-2.9).curveTo(-6.4,-2.9,-6.4,-3).curveTo(-6.4,-3,-6.4,-3.1).curveTo(-6.4,-3.4,-6.8,-3.4).lineTo(-7.3,-3.5).curveTo(-7.8,-3.6,-8,-3.9).curveTo(-8.3,-4.2,-8.3,-4.5).curveTo(-8.3,-5,-7.9,-5.3).curveTo(-7.5,-5.6,-7,-5.6).curveTo(-6.4,-5.6,-6,-5.2).curveTo(-5.7,-5,-5.7,-4.7).lineTo(-6.4,-4.4).curveTo(-6.4,-5,-7,-5).curveTo(-7.1,-5,-7.1,-5).curveTo(-7.2,-5,-7.2,-5).curveTo(-7.3,-4.9,-7.3,-4.9).curveTo(-7.3,-4.9,-7.4,-4.9).lineTo(-7.5,-4.6).curveTo(-7.5,-4.5,-7.5,-4.5).curveTo(-7.4,-4.4,-7.4,-4.4).curveTo(-7.4,-4.3,-7.3,-4.3).curveTo(-7.2,-4.3,-7.2,-4.2).lineTo(-6.6,-4.1).curveTo(-5.7,-3.9,-5.7,-3.1).curveTo(-5.7,-2.6,-6,-2.3).curveTo(-6.3,-2,-6.9,-2).curveTo(-7.6,-2,-8,-2.3).closePath().moveTo(-11.2,-2.3).curveTo(-11.5,-2.6,-11.5,-3).lineTo(-10.8,-3.2).curveTo(-10.8,-3.1,-10.8,-3.1).curveTo(-10.8,-3,-10.7,-3).curveTo(-10.7,-2.9,-10.7,-2.9).curveTo(-10.7,-2.8,-10.6,-2.8).curveTo(-10.4,-2.6,-10.1,-2.6).lineTo(-9.7,-2.8).curveTo(-9.7,-2.8,-9.7,-2.8).curveTo(-9.6,-2.8,-9.6,-2.9).curveTo(-9.6,-2.9,-9.6,-3).curveTo(-9.6,-3,-9.6,-3.1).curveTo(-9.6,-3.4,-10,-3.4).lineTo(-10.5,-3.5).curveTo(-10.9,-3.6,-11.2,-3.9).curveTo(-11.4,-4.2,-11.4,-4.5).curveTo(-11.4,-5,-11,-5.3).curveTo(-10.7,-5.6,-10.2,-5.6).curveTo(-9.5,-5.6,-9.2,-5.2).curveTo(-8.9,-5,-8.8,-4.7).lineTo(-9.5,-4.4).curveTo(-9.6,-5,-10.2,-5).curveTo(-10.2,-5,-10.3,-5).curveTo(-10.3,-5,-10.4,-5).curveTo(-10.4,-4.9,-10.4,-4.9).curveTo(-10.5,-4.9,-10.5,-4.9).lineTo(-10.6,-4.6).curveTo(-10.6,-4.5,-10.6,-4.5).curveTo(-10.6,-4.4,-10.6,-4.4).curveTo(-10.5,-4.3,-10.5,-4.3).curveTo(-10.4,-4.3,-10.3,-4.2).lineTo(-9.8,-4.1).curveTo(-8.8,-3.9,-8.8,-3.1).curveTo(-8.8,-2.6,-9.1,-2.3).curveTo(-9.5,-2,-10.1,-2).curveTo(-10.8,-2,-11.2,-2.3).closePath().moveTo(-14.7,-2.5).curveTo(-15.3,-3,-15.3,-3.8).curveTo(-15.3,-4.6,-14.8,-5.1).curveTo(-14.3,-5.6,-13.6,-5.6).curveTo(-12.8,-5.6,-12.4,-5.1).curveTo(-11.9,-4.6,-11.9,-3.9).lineTo(-12,-3.6).lineTo(-14.5,-3.6).curveTo(-14.4,-3.2,-14.2,-3).curveTo(-13.9,-2.7,-13.5,-2.7).curveTo(-12.9,-2.7,-12.7,-3.3).lineTo(-12,-3.1).curveTo(-12.1,-2.6,-12.5,-2.3).curveTo(-12.9,-2,-13.5,-2).curveTo(-14.3,-2,-14.7,-2.5).closePath().moveTo(-12.8,-4.2).curveTo(-12.8,-4.5,-13,-4.7).curveTo(-13.2,-4.9,-13.6,-5).curveTo(-14,-4.9,-14.2,-4.7).curveTo(-14.4,-4.5,-14.4,-4.2).lineTo(-12.8,-4.2).lineTo(-12.8,-4.2).closePath().moveTo(-37.2,-2.3).curveTo(-37.5,-2.6,-37.5,-3).lineTo(-36.8,-3.2).curveTo(-36.8,-3.1,-36.8,-3.1).curveTo(-36.8,-3,-36.7,-3).curveTo(-36.7,-2.9,-36.7,-2.9).curveTo(-36.7,-2.8,-36.6,-2.8).curveTo(-36.4,-2.6,-36.1,-2.6).lineTo(-35.7,-2.8).curveTo(-35.7,-2.8,-35.7,-2.8).curveTo(-35.6,-2.8,-35.6,-2.9).curveTo(-35.6,-2.9,-35.6,-3).curveTo(-35.6,-3,-35.6,-3.1).curveTo(-35.6,-3.4,-36,-3.4).lineTo(-36.5,-3.5).curveTo(-36.9,-3.6,-37.2,-3.9).curveTo(-37.4,-4.2,-37.4,-4.5).curveTo(-37.4,-5,-37,-5.3).curveTo(-36.7,-5.6,-36.2,-5.6).curveTo(-35.5,-5.6,-35.2,-5.2).curveTo(-34.9,-5,-34.8,-4.7).lineTo(-35.5,-4.4).curveTo(-35.6,-5,-36.2,-5).curveTo(-36.2,-5,-36.3,-5).curveTo(-36.3,-5,-36.4,-5).curveTo(-36.4,-4.9,-36.4,-4.9).curveTo(-36.5,-4.9,-36.5,-4.9).lineTo(-36.6,-4.6).curveTo(-36.6,-4.5,-36.6,-4.5).curveTo(-36.6,-4.4,-36.6,-4.4).curveTo(-36.5,-4.3,-36.5,-4.3).curveTo(-36.4,-4.3,-36.3,-4.2).lineTo(-35.8,-4.1).curveTo(-34.8,-3.9,-34.8,-3.1).curveTo(-34.8,-2.6,-35.1,-2.3).curveTo(-35.5,-2,-36.1,-2).curveTo(-36.8,-2,-37.2,-2.3).closePath().moveTo(46.4,-2.3).curveTo(46.1,-2.6,46.1,-3.1).lineTo(46.1,-4.8).lineTo(45.5,-4.8).lineTo(45.5,-5.5).lineTo(45.7,-5.5).curveTo(46.2,-5.5,46.2,-6).lineTo(46.2,-6.6).lineTo(46.9,-6.6).lineTo(46.9,-5.5).lineTo(47.6,-5.5).lineTo(47.6,-4.8).lineTo(46.9,-4.8).lineTo(46.9,-3.2).curveTo(46.9,-2.8,47.4,-2.8).lineTo(47.6,-2.8).lineTo(47.6,-2.2).lineTo(47.1,-2.1).curveTo(46.7,-2.1,46.4,-2.3).closePath().moveTo(20.5,-2.2).curveTo(20.5,-2.2,20.4,-2.3).curveTo(20.4,-2.4,20.4,-2.4).curveTo(20.3,-2.5,20.3,-2.5).curveTo(20.3,-2.6,20.3,-2.6).curveTo(20.3,-2.7,20.3,-2.8).curveTo(20.3,-2.8,20.4,-2.9).curveTo(20.4,-2.9,20.4,-3).curveTo(20.5,-3,20.5,-3.1).curveTo(20.6,-3.1,20.6,-3.1).curveTo(20.7,-3.1,20.7,-3.2).curveTo(20.8,-3.2,20.8,-3.2).curveTo(20.9,-3.2,20.9,-3.2).lineTo(21.3,-3.1).lineTo(21.5,-2.6).curveTo(21.5,-2.6,21.5,-2.5).curveTo(21.5,-2.5,21.4,-2.4).curveTo(21.4,-2.4,21.4,-2.3).curveTo(21.4,-2.2,21.3,-2.2).lineTo(20.9,-2.1).curveTo(20.9,-2.1,20.8,-2.1).curveTo(20.8,-2.1,20.7,-2.1).curveTo(20.7,-2.1,20.6,-2.1).curveTo(20.6,-2.2,20.5,-2.2).closePath().moveTo(-33.5,-2.3).curveTo(-33.8,-2.6,-33.8,-3.1).lineTo(-33.8,-4.8).lineTo(-34.5,-4.8).lineTo(-34.5,-5.5).lineTo(-34.3,-5.5).curveTo(-33.8,-5.5,-33.8,-6).lineTo(-33.8,-6.6).lineTo(-33,-6.6).lineTo(-33,-5.5).lineTo(-32.3,-5.5).lineTo(-32.3,-4.8).lineTo(-33,-4.8).lineTo(-33,-3.2).curveTo(-33,-2.8,-32.6,-2.8).lineTo(-32.3,-2.8).lineTo(-32.3,-2.2).lineTo(-32.8,-2.1).curveTo(-33.3,-2.1,-33.5,-2.3).closePath().moveTo(-41.1,-2.3).curveTo(-41.4,-2.6,-41.4,-3.1).lineTo(-41.4,-4.8).lineTo(-42,-4.8).lineTo(-42,-5.5).lineTo(-41.8,-5.5).curveTo(-41.3,-5.5,-41.3,-6).lineTo(-41.3,-6.6).lineTo(-40.6,-6.6).lineTo(-40.6,-5.5).lineTo(-39.9,-5.5).lineTo(-39.9,-4.8).lineTo(-40.6,-4.8).lineTo(-40.6,-3.2).curveTo(-40.6,-2.8,-40.1,-2.8).lineTo(-39.9,-2.8).lineTo(-39.9,-2.2).lineTo(-40.4,-2.1).curveTo(-40.8,-2.1,-41.1,-2.3).closePath().moveTo(14.8,-2.1).lineTo(14.8,-7.1).lineTo(15.6,-7.1).lineTo(15.6,-2.1).closePath().moveTo(13,-2.1).lineTo(13,-4.1).curveTo(13,-4.8,12.3,-4.9).curveTo(11.9,-4.9,11.7,-4.7).curveTo(11.6,-4.4,11.6,-4).lineTo(11.6,-2.1).lineTo(10.8,-2.1).lineTo(10.8,-5.5).lineTo(11.5,-5.5).lineTo(11.5,-5).curveTo(11.9,-5.6,12.5,-5.6).curveTo(13.1,-5.6,13.5,-5.2).curveTo(13.8,-4.9,13.8,-4.2).lineTo(13.8,-2.1).closePath().moveTo(3.2,-2.1).lineTo(3.2,-4.1).curveTo(3.2,-4.8,2.5,-4.9).curveTo(2.2,-4.9,2,-4.7).curveTo(1.8,-4.4,1.8,-4).lineTo(1.8,-2.1).lineTo(1,-2.1).lineTo(1,-5.5).lineTo(1.8,-5.5).lineTo(1.8,-5).curveTo(2.1,-5.6,2.8,-5.6).curveTo(3.4,-5.6,3.7,-5.2).curveTo(4,-4.9,4,-4.2).lineTo(4,-2.1).closePath().moveTo(-4.9,-2.1).lineTo(-4.9,-5.5).lineTo(-4.1,-5.5).lineTo(-4.1,-2.1).closePath().moveTo(-17.6,-2.1).lineTo(-17.6,-5.5).lineTo(-16.9,-5.5).lineTo(-16.9,-5).curveTo(-16.6,-5.5,-15.9,-5.6).lineTo(-15.7,-5.6).lineTo(-15.7,-4.7).lineTo(-15.9,-4.7).curveTo(-16.8,-4.7,-16.8,-3.7).lineTo(-16.8,-2.1).closePath().moveTo(-23.6,-2.1).lineTo(-23.6,-4.2).curveTo(-23.6,-4.9,-24.3,-4.9).curveTo(-24.6,-4.9,-24.8,-4.7).curveTo(-25,-4.5,-25,-4.1).lineTo(-25,-2.1).lineTo(-25.8,-2.1).lineTo(-25.8,-4.2).curveTo(-25.8,-4.9,-26.4,-4.9).curveTo(-26.8,-4.9,-27,-4.7).curveTo(-27.1,-4.5,-27.1,-4.1).lineTo(-27.1,-2.1).lineTo(-27.9,-2.1).lineTo(-27.9,-5.5).lineTo(-27.2,-5.5).lineTo(-27.2,-5).curveTo(-27,-5.3,-26.7,-5.5).curveTo(-26.5,-5.6,-26.2,-5.6).curveTo(-25.4,-5.6,-25.1,-5).curveTo(-24.8,-5.6,-24,-5.6).curveTo(-23.5,-5.6,-23.2,-5.3).curveTo(-22.8,-5,-22.8,-4.3).lineTo(-22.8,-2.1).closePath().moveTo(-29.8,-2.1).lineTo(-29.8,-5.5).lineTo(-29,-5.5).lineTo(-29,-2.1).closePath().moveTo(-39,-2.1).lineTo(-39,-5.5).lineTo(-38.2,-5.5).lineTo(-38.2,-2.1).closePath().moveTo(-44.2,-2.1).lineTo(-44.2,-5.5).lineTo(-43.5,-5.5).lineTo(-43.5,-5).curveTo(-43.2,-5.5,-42.5,-5.6).lineTo(-42.3,-5.6).lineTo(-42.3,-4.7).lineTo(-42.5,-4.7).curveTo(-43.4,-4.7,-43.4,-3.7).lineTo(-43.4,-2.1).closePath().moveTo(-45.7,-2.1).lineTo(-46.2,-3.3).lineTo(-48.3,-3.3).lineTo(-48.8,-2.1).lineTo(-49.7,-2.1).lineTo(-47.7,-7).lineTo(-46.8,-7).lineTo(-44.8,-2.1).closePath().moveTo(-46.5,-4.1).lineTo(-47.3,-6.1).lineTo(-48,-4.1).lineTo(-46.5,-4.1).closePath().moveTo(36.5,-6.4).curveTo(36.5,-6.4,36.5,-6.4).curveTo(36.4,-6.5,36.4,-6.5).curveTo(36.4,-6.6,36.4,-6.6).curveTo(36.4,-6.6,36.4,-6.7).curveTo(36.4,-6.8,36.4,-6.8).curveTo(36.4,-6.9,36.4,-6.9).curveTo(36.4,-7,36.5,-7).curveTo(36.5,-7.1,36.5,-7.1).curveTo(36.6,-7.1,36.6,-7.2).curveTo(36.6,-7.2,36.7,-7.2).curveTo(36.7,-7.2,36.8,-7.2).curveTo(36.8,-7.3,36.9,-7.3).curveTo(36.9,-7.3,37,-7.2).curveTo(37,-7.2,37.1,-7.2).curveTo(37.1,-7.2,37.2,-7.2).curveTo(37.2,-7.1,37.3,-7.1).curveTo(37.3,-7.1,37.3,-7).curveTo(37.4,-7,37.4,-6.9).curveTo(37.4,-6.9,37.4,-6.8).curveTo(37.4,-6.8,37.4,-6.7).curveTo(37.4,-6.6,37.4,-6.6).curveTo(37.4,-6.6,37.4,-6.5).curveTo(37.4,-6.5,37.3,-6.4).curveTo(37.3,-6.4,37.3,-6.4).curveTo(37.2,-6.3,37.2,-6.3).curveTo(37.1,-6.3,37.1,-6.2).curveTo(37,-6.2,37,-6.2).curveTo(36.9,-6.2,36.9,-6.2).curveTo(36.8,-6.2,36.8,-6.2).curveTo(36.7,-6.2,36.7,-6.2).curveTo(36.6,-6.3,36.6,-6.3).curveTo(36.6,-6.3,36.5,-6.4).closePath().moveTo(-4.9,-6.4).curveTo(-4.9,-6.4,-4.9,-6.4).curveTo(-5,-6.5,-5,-6.5).curveTo(-5,-6.6,-5,-6.6).curveTo(-5,-6.6,-5,-6.7).curveTo(-5,-6.8,-5,-6.8).curveTo(-5,-6.9,-5,-6.9).curveTo(-5,-7,-4.9,-7).curveTo(-4.9,-7.1,-4.9,-7.1).curveTo(-4.8,-7.1,-4.8,-7.2).curveTo(-4.8,-7.2,-4.7,-7.2).curveTo(-4.7,-7.2,-4.6,-7.2).curveTo(-4.6,-7.3,-4.5,-7.3).curveTo(-4.5,-7.3,-4.4,-7.2).curveTo(-4.4,-7.2,-4.3,-7.2).curveTo(-4.3,-7.2,-4.2,-7.2).curveTo(-4.2,-7.1,-4.1,-7.1).curveTo(-4.1,-7.1,-4.1,-7).curveTo(-4,-7,-4,-6.9).curveTo(-4,-6.9,-4,-6.8).curveTo(-4,-6.8,-4,-6.7).curveTo(-4,-6.6,-4,-6.6).curveTo(-4,-6.6,-4,-6.5).curveTo(-4,-6.5,-4.1,-6.4).curveTo(-4.1,-6.4,-4.1,-6.4).curveTo(-4.2,-6.3,-4.2,-6.3).curveTo(-4.3,-6.3,-4.3,-6.2).curveTo(-4.4,-6.2,-4.4,-6.2).curveTo(-4.5,-6.2,-4.5,-6.2).curveTo(-4.6,-6.2,-4.6,-6.2).curveTo(-4.7,-6.2,-4.7,-6.2).curveTo(-4.8,-6.3,-4.8,-6.3).curveTo(-4.8,-6.3,-4.9,-6.4).closePath().moveTo(-29.8,-6.4).curveTo(-29.8,-6.4,-29.8,-6.4).curveTo(-29.9,-6.5,-29.9,-6.5).curveTo(-29.9,-6.6,-29.9,-6.6).curveTo(-29.9,-6.6,-29.9,-6.7).curveTo(-29.9,-6.8,-29.9,-6.8).curveTo(-29.9,-6.9,-29.9,-6.9).curveTo(-29.9,-7,-29.8,-7).curveTo(-29.8,-7.1,-29.8,-7.1).curveTo(-29.7,-7.1,-29.7,-7.2).curveTo(-29.7,-7.2,-29.6,-7.2).curveTo(-29.6,-7.2,-29.5,-7.2).curveTo(-29.5,-7.3,-29.4,-7.3).curveTo(-29.4,-7.3,-29.3,-7.2).curveTo(-29.2,-7.2,-29.2,-7.2).curveTo(-29.1,-7.2,-29.1,-7.2).curveTo(-29.1,-7.1,-29,-7.1).curveTo(-29,-7.1,-29,-7).curveTo(-28.9,-7,-28.9,-6.9).curveTo(-28.9,-6.9,-28.9,-6.8).curveTo(-28.9,-6.8,-28.9,-6.7).curveTo(-28.9,-6.6,-28.9,-6.6).curveTo(-28.9,-6.6,-28.9,-6.5).curveTo(-28.9,-6.5,-29,-6.4).curveTo(-29,-6.4,-29,-6.4).curveTo(-29.1,-6.3,-29.1,-6.3).curveTo(-29.1,-6.3,-29.2,-6.2).curveTo(-29.2,-6.2,-29.3,-6.2).curveTo(-29.4,-6.2,-29.4,-6.2).curveTo(-29.5,-6.2,-29.5,-6.2).curveTo(-29.6,-6.2,-29.6,-6.2).curveTo(-29.7,-6.3,-29.7,-6.3).curveTo(-29.7,-6.3,-29.8,-6.4).closePath().moveTo(-39,-6.4).curveTo(-39.1,-6.4,-39.1,-6.4).curveTo(-39.1,-6.5,-39.1,-6.5).curveTo(-39.2,-6.6,-39.2,-6.6).curveTo(-39.2,-6.6,-39.2,-6.7).curveTo(-39.2,-6.8,-39.2,-6.8).curveTo(-39.2,-6.9,-39.1,-6.9).curveTo(-39.1,-7,-39.1,-7).curveTo(-39.1,-7.1,-39,-7.1).curveTo(-39,-7.1,-38.9,-7.2).curveTo(-38.9,-7.2,-38.9,-7.2).curveTo(-38.8,-7.2,-38.8,-7.2).curveTo(-38.7,-7.3,-38.7,-7.3).curveTo(-38.6,-7.3,-38.6,-7.2).curveTo(-38.5,-7.2,-38.4,-7.2).curveTo(-38.4,-7.2,-38.4,-7.2).curveTo(-38.3,-7.1,-38.3,-7.1).curveTo(-38.2,-7.1,-38.2,-7).curveTo(-38.2,-7,-38.2,-6.9).curveTo(-38.1,-6.9,-38.1,-6.8).curveTo(-38.1,-6.8,-38.1,-6.7).curveTo(-38.1,-6.6,-38.1,-6.6).curveTo(-38.1,-6.6,-38.2,-6.5).curveTo(-38.2,-6.5,-38.2,-6.4).curveTo(-38.2,-6.4,-38.3,-6.4).curveTo(-38.3,-6.3,-38.4,-6.3).curveTo(-38.4,-6.3,-38.4,-6.2).curveTo(-38.5,-6.2,-38.6,-6.2).curveTo(-38.6,-6.2,-38.7,-6.2).curveTo(-38.7,-6.2,-38.8,-6.2).curveTo(-38.8,-6.2,-38.9,-6.2).curveTo(-38.9,-6.3,-38.9,-6.3).curveTo(-39,-6.3,-39,-6.4).closePath();
	this.shape_79.setTransform(60.875,582.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_79).wait(285));

	// Layer_2
	this.instance_9 = new lib.Symbol15();
	this.instance_9.parent = this;
	this.instance_9.setTransform(60.1,270.7,1.0814,1.0797,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(285));

	// Lenmdlease_logo
	this.instance_10 = new lib.LEndlease();
	this.instance_10.parent = this;
	this.instance_10.setTransform(60,529,0.7478,0.7478);

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(285));

	// Layer_4
	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.beginFill("#000000").beginStroke().moveTo(32.1,3.6).curveTo(31.3,2.7,31.2,1.3).curveTo(31.2,0,32.1,-0.8).curveTo(32.8,-1.6,33.9,-1.6).curveTo(35.2,-1.6,35.9,-0.8).curveTo(36.7,-0,36.7,1.3).lineTo(36.6,1.7).lineTo(32.3,1.7).curveTo(32.4,2.4,32.9,2.9).curveTo(33.4,3.4,34,3.4).curveTo(35.3,3.4,35.7,2.2).lineTo(36.6,2.6).curveTo(36.4,3.4,35.7,3.8).curveTo(35,4.4,34,4.4).curveTo(32.9,4.4,32.1,3.6).closePath().moveTo(35.5,0.8).curveTo(35.4,0.1,35.1,-0.2).curveTo(34.6,-0.7,33.9,-0.7).curveTo(33.3,-0.7,32.9,-0.2).curveTo(32.4,0.2,32.4,0.8).lineTo(35.5,0.8).lineTo(35.5,0.8).closePath().moveTo(21.2,3.5).curveTo(20.4,2.6,20.4,1.3).curveTo(20.4,0.1,21.2,-0.8).curveTo(22,-1.6,23.2,-1.6).curveTo(24.5,-1.6,25.3,-0.8).curveTo(26.1,0.1,26.1,1.3).curveTo(26.1,2.6,25.3,3.5).curveTo(24.5,4.4,23.2,4.4).curveTo(22,4.4,21.2,3.5).closePath().moveTo(22,-0.1).curveTo(21.5,0.4,21.5,1.3).curveTo(21.5,2.3,22,2.9).curveTo(22.5,3.4,23.2,3.4).curveTo(24,3.4,24.5,2.9).curveTo(25,2.3,25,1.3).curveTo(25,0.4,24.5,-0.1).curveTo(24,-0.7,23.2,-0.7).curveTo(22.5,-0.7,22,-0.1).closePath().moveTo(-2.5,3.5).curveTo(-3.4,2.6,-3.3,1.3).curveTo(-3.4,0.1,-2.5,-0.8).curveTo(-1.7,-1.6,-0.4,-1.6).curveTo(0.8,-1.6,1.6,-0.8).curveTo(2.5,0.1,2.5,1.3).curveTo(2.5,2.6,1.6,3.5).curveTo(0.8,4.4,-0.4,4.4).curveTo(-1.7,4.4,-2.5,3.5).closePath().moveTo(-1.7,-0.1).curveTo(-2.2,0.4,-2.2,1.3).curveTo(-2.2,2.3,-1.7,2.9).curveTo(-1.2,3.4,-0.4,3.4).curveTo(0.3,3.4,0.8,2.9).curveTo(1.3,2.3,1.3,1.3).curveTo(1.3,0.4,0.8,-0.1).curveTo(0.3,-0.7,-0.4,-0.7).curveTo(-1.2,-0.7,-1.7,-0.1).closePath().moveTo(-21.4,3.5).curveTo(-22.3,2.6,-22.2,1.3).curveTo(-22.3,0,-21.4,-0.8).curveTo(-20.6,-1.6,-19.4,-1.6).curveTo(-18.4,-1.6,-17.6,-1.1).curveTo(-17.1,-0.6,-16.9,0.2).lineTo(-17.9,0.6).curveTo(-18.2,-0.6,-19.4,-0.6).curveTo(-20.1,-0.6,-20.6,-0.1).curveTo(-21.1,0.4,-21.1,1.3).curveTo(-21.1,2.3,-20.6,2.8).curveTo(-20.1,3.3,-19.4,3.3).curveTo(-18.1,3.3,-17.8,2.2).lineTo(-16.8,2.6).curveTo(-17.1,3.3,-17.6,3.8).curveTo(-18.4,4.4,-19.4,4.4).curveTo(-20.6,4.4,-21.4,3.5).closePath().moveTo(-35.4,3.2).curveTo(-36.6,2,-36.6,0).curveTo(-36.6,-2,-35.4,-3.2).curveTo(-34.2,-4.3,-32.6,-4.3).curveTo(-31.2,-4.3,-30.1,-3.6).curveTo(-29.2,-2.9,-28.9,-1.7).lineTo(-30,-1.3).curveTo(-30.4,-3.3,-32.6,-3.3).curveTo(-33.8,-3.3,-34.6,-2.4).curveTo(-35.5,-1.5,-35.5,0).curveTo(-35.5,1.6,-34.6,2.5).curveTo(-33.8,3.3,-32.6,3.3).curveTo(-31.5,3.3,-30.8,2.7).curveTo(-30.2,2.2,-29.9,1.3).lineTo(-28.9,1.7).curveTo(-29.2,2.9,-30.1,3.6).curveTo(-31.2,4.4,-32.6,4.4).curveTo(-34.2,4.4,-35.4,3.2).closePath().moveTo(27.5,4.2).lineTo(27.5,-1.5).lineTo(28.5,-1.5).lineTo(28.5,-0.5).curveTo(29,-1.6,30.2,-1.6).lineTo(30.5,-1.5).lineTo(30.5,-0.4).lineTo(30.1,-0.4).curveTo(28.5,-0.4,28.5,1.3).lineTo(28.5,4.2).closePath().moveTo(18.1,4.2).lineTo(18.1,0.6).curveTo(18.1,-0.7,16.9,-0.7).curveTo(16.3,-0.7,15.9,-0.2).curveTo(15.6,0.2,15.6,0.8).lineTo(15.6,4.2).lineTo(14.5,4.2).lineTo(14.5,0.6).curveTo(14.5,-0.7,13.3,-0.7).curveTo(12.7,-0.7,12.3,-0.3).curveTo(12,0.1,12,0.8).lineTo(12,4.2).lineTo(10.9,4.2).lineTo(10.9,-1.5).lineTo(12,-1.5).lineTo(12,-0.7).curveTo(12.5,-1.6,13.6,-1.6).curveTo(14.9,-1.6,15.3,-0.6).curveTo(15.9,-1.6,17.2,-1.6).curveTo(18.1,-1.6,18.6,-1.1).curveTo(19.2,-0.5,19.2,0.5).lineTo(19.2,4.2).closePath().moveTo(3.8,4.2).lineTo(3.8,-1.5).lineTo(4.9,-1.5).lineTo(4.9,-0.5).curveTo(5.4,-1.6,6.6,-1.6).lineTo(6.9,-1.5).lineTo(6.9,-0.4).lineTo(6.4,-0.4).curveTo(4.9,-0.4,4.9,1.3).lineTo(4.9,4.2).closePath().moveTo(-6.4,4.2).lineTo(-6.4,-0.5).lineTo(-7.5,-0.5).lineTo(-7.5,-1.5).lineTo(-6.4,-1.5).lineTo(-6.4,-2.4).curveTo(-6.4,-3.3,-5.9,-3.9).curveTo(-5.3,-4.3,-4.6,-4.3).curveTo(-4,-4.3,-3.9,-4.2).lineTo(-3.9,-3.2).lineTo(-4.4,-3.3).curveTo(-5.3,-3.3,-5.3,-2.4).lineTo(-5.3,-1.5).lineTo(-3.9,-1.5).lineTo(-3.9,-0.5).lineTo(-5.3,-0.5).lineTo(-5.3,4.2).closePath().moveTo(-12,4.2).lineTo(-13.8,1.7).lineTo(-14.6,2.5).lineTo(-14.6,4.2).lineTo(-15.6,4.2).lineTo(-15.6,-4.3).lineTo(-14.6,-4.3).lineTo(-14.6,1).lineTo(-12.1,-1.5).lineTo(-10.6,-1.5).lineTo(-13,0.9).lineTo(-10.5,4.2).closePath().moveTo(-24.6,4.2).lineTo(-24.6,-1.5).lineTo(-23.6,-1.5).lineTo(-23.6,4.2).closePath().moveTo(-27.5,4.2).lineTo(-27.5,-4.3).lineTo(-26.4,-4.3).lineTo(-26.4,4.2).closePath().moveTo(-24.7,-3).curveTo(-24.9,-3.3,-24.9,-3.6).curveTo(-24.9,-3.9,-24.7,-4.2).curveTo(-24.4,-4.4,-24.1,-4.4).curveTo(-23.8,-4.4,-23.6,-4.2).curveTo(-23.4,-3.9,-23.4,-3.6).curveTo(-23.4,-3.3,-23.6,-3).curveTo(-23.8,-2.8,-24.1,-2.8).curveTo(-24.4,-2.8,-24.7,-3).closePath();
	this.shape_80.setTransform(58.75,458.725);

	this.timeline.addTween(cjs.Tween.get(this.shape_80).wait(285));

	// Register_btn
	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.beginFill().beginStroke("#000000").setStrokeStyle(1.5,1,1).moveTo(-33.6,-9.1).lineTo(33.7,-9.1).curveTo(37.4,-9.1,40,-6.5).curveTo(42.8,-3.8,42.8,-0).lineTo(42.8,0).curveTo(42.8,3.8,40,6.4).curveTo(37.4,9.1,33.7,9.1).lineTo(-33.6,9.1).curveTo(-37.4,9.1,-40.1,6.4).curveTo(-42.8,3.8,-42.8,0).lineTo(-42.8,-0).curveTo(-42.8,-3.8,-40.1,-6.5).curveTo(-37.4,-9.1,-33.6,-9.1).closePath();
	this.shape_81.setTransform(59.5,458.875);

	this.timeline.addTween(cjs.Tween.get(this.shape_81).wait(285));

	// BKG
	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.beginFill("#F26522").beginStroke().moveTo(-80,300).lineTo(-80,-300).lineTo(80,-300).lineTo(80,300).closePath();
	this.shape_82.setTransform(80,300);

	this.timeline.addTween(cjs.Tween.get(this.shape_82).wait(285));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.7,276.1,205.7,323.9);
// library properties:
lib.properties = {
	id: '56DC97A13D194E2C906C95BBEC24E126',
	width: 120,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Skyscraper_120x600/gh-pages/images/IMG01jpgcopy.jpg", id:"IMG01jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Skyscraper_120x600/gh-pages/images/IMG02jpgcopy.jpg", id:"IMG02jpgcopy"},
		{src:"https://raw.githubusercontent.com/thepropertyagency/FH-Skyscraper_120x600/gh-pages/images/IMG03.jpg", id:"IMG03"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['56DC97A13D194E2C906C95BBEC24E126'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;